import json
import logging
from datetime import datetime
from typing import Dict, Any

from PIL import Image

from config.database import DatabaseManager
from services.verification_service import VerificationService
from services.trocr_aadhaar_extractor import TrOCRBasedAadhaarExtractor

logger = logging.getLogger(__name__)


class AadhaarKYCService:
    """Aadhaar-only KYC service: extract -> verify -> store -> update KYC status."""

    def __init__(self):
        self.db = DatabaseManager()
        self.verifier = VerificationService()
        self.extractor = TrOCRBasedAadhaarExtractor()

    def extract_aadhaar(self, customer_id: str, image_path: str) -> Dict[str, Any]:
        """Extract Aadhaar fields and store extraction attempt (not verified yet)."""
        pil_img = Image.open(image_path)
        extraction = self.extractor.extract(pil_img)

        fields = extraction.get("fields", {})
        # Map to existing system key names
        extracted_data = {
            "id_number": fields.get("aadhaar_number"),
        }

        extracted_conf = extraction.get("confidence", {}).get("overall", 0.0) * 100.0

        # Persist extraction attempt
        self.db.save_aadhaar_kyc_attempt(
            customer_id=customer_id,
            file_path=image_path,
            extracted_json=json.dumps(extracted_data),
            extracted_raw_text=extraction.get("raw_text", ""),
            extracted_confidence=float(extracted_conf),
        )

        # Audit
        self.db.log_audit({
            "customer_id": customer_id,
            "action": "AADHAAR_EXTRACTED",
            "details": f"Aadhaar extracted with confidence {extracted_conf:.1f}"
        })

        # Make UI success depend on whether we extracted at least one meaningful field
        has_any = any(v for v in extracted_data.values())

        return {
            "success": bool(has_any),
            "document_type": "aadhaar",
            "extracted_fields": extracted_data,
            "confidence_score": extracted_conf,
            "raw_text": extraction.get("raw_text", ""),
            "debug": extraction.get("debug"),
        }

    def verify_aadhaar(self, customer_id: str, image_path: str,
                      extracted_fields: Dict[str, Any],
                      entered_fields: Dict[str, Any]) -> Dict[str, Any]:
        """Verify Aadhaar extracted fields against user-entered data and persist result."""

        # Aadhaar-number-only verification (Aadhaar-only phase)
        extracted_id = (extracted_fields.get('id_number') or '').replace(' ', '')
        entered_id = (entered_fields.get('id_number') or '').replace(' ', '')

        id_match = bool(extracted_id) and extracted_id == entered_id
        verification = {
            'field_matches': {
                'id_number': {
                    'extracted': extracted_fields.get('id_number'),
                    'entered': entered_fields.get('id_number'),
                    'match': id_match,
                    'score': 100.0 if id_match else 0.0
                }
            },
            'overall_match': id_match,
            'confidence_score': 100.0 if id_match else 0.0,
            'document_type': 'aadhaar'
        }

        verified = id_match
        verified_at = datetime.now().isoformat() if verified else None

        # Persist a verification attempt (store both extracted and entered)
        self.db.save_aadhaar_kyc_attempt(
            customer_id=customer_id,
            file_path=image_path,
            extracted_json=json.dumps(extracted_fields),
            extracted_raw_text="",
            extracted_confidence=float(verification.get("confidence_score", 0.0)),
            entered_json=json.dumps(entered_fields),
            match_json=json.dumps(verification),
            verified=verified,
            verified_at=verified_at,
        )

        # Update KYC status table (id_proof_status)
        self.verifier.update_kyc_status(
            customer_id=customer_id,
            document_type="id_proof",
            verification_result=verification,
            confidence_score=float(verification.get("confidence_score", 0.0)),
        )

        # Audit
        self.db.log_audit({
            "customer_id": customer_id,
            "action": "AADHAAR_VERIFIED" if verified else "AADHAAR_VERIFICATION_FAILED",
            "details": f"Aadhaar verification {'passed' if verified else 'failed'} score={verification.get('confidence_score', 0.0):.1f}"
        })

        return {
            "success": verified,
            "verification": verification,
            "verified_at": verified_at,
        }
