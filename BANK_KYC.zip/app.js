import React, { useState } from 'react';
import { Upload, CheckCircle, XCircle, AlertCircle, FileText, User, Mail, Phone, MapPin, Hash, Shield } from 'lucide-react';

const KYCVerificationApp = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    address: '',
    idNumber: '',
    dob: ''
  });
  const [uploadedDoc, setUploadedDoc] = useState(null);
  const [extractedData, setExtractedData] = useState(null);
  const [otp, setOtp] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [verificationResult, setVerificationResult] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [auditLog, setAuditLog] = useState([]);

  const addToAuditLog = (action) => {
    const timestamp = new Date().toLocaleString();
    setAuditLog(prev => [...prev, { timestamp, action }]);
  };

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setUploadedDoc(file);
      addToAuditLog(`Document uploaded: ${file.name}`);
      simulateOCRExtraction(file);
    }
  };

  // Simulate OCR extraction using ML models (Tesseract.js, AWS Textract, Google Vision API in production)
  const simulateOCRExtraction = (file) => {
    setIsProcessing(true);
    addToAuditLog('Starting AI/OCR document processing');
    
    setTimeout(() => {
      // Simulated extracted data from document
      const extracted = {
        fullName: 'John Michael Doe',
        idNumber: 'ABC123456789',
        dob: '1990-05-15',
        address: '123 Main Street, Mumbai, Maharashtra'
      };
      
      setExtractedData(extracted);
      setIsProcessing(false);
      addToAuditLog('Document extraction completed successfully');
    }, 2500);
  };

  const generateOTP = () => {
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(otp);
    addToAuditLog(`OTP generated and sent to ${formData.phone}`);
    alert(`OTP sent to your phone: ${otp} (Demo Mode)`);
  };

  const verifyOTP = () => {
    if (otp === generatedOtp) {
      addToAuditLog('OTP verified successfully');
      return true;
    }
    addToAuditLog('OTP verification failed');
    return false;
  };

  const verifyDocuments = () => {
    setIsProcessing(true);
    
    setTimeout(() => {
      const nameMatch = calculateSimilarity(formData.fullName, extractedData.fullName);
      const idMatch = formData.idNumber === extractedData.idNumber;
      const dobMatch = formData.dob === extractedData.dob;
      const addressMatch = calculateSimilarity(formData.address, extractedData.address);

      const result = {
        nameMatch,
        idMatch,
        dobMatch,
        addressMatch,
        overallScore: (nameMatch + (idMatch ? 100 : 0) + (dobMatch ? 100 : 0) + addressMatch) / 4,
        status: null
      };

      result.status = result.overallScore >= 80 ? 'approved' : 
                     result.overallScore >= 60 ? 'review' : 'rejected';

      setVerificationResult(result);
      setIsProcessing(false);
      addToAuditLog(`Verification completed - Status: ${result.status.toUpperCase()}`);
    }, 2000);
  };

  const calculateSimilarity = (str1, str2) => {
    const s1 = str1.toLowerCase().trim();
    const s2 = str2.toLowerCase().trim();
    
    if (s1 === s2) return 100;
    
    const words1 = s1.split(/\s+/);
    const words2 = s2.split(/\s+/);
    let matches = 0;
    
    words1.forEach(word => {
      if (words2.some(w => w.includes(word) || word.includes(w))) {
        matches++;
      }
    });
    
    return Math.round((matches / Math.max(words1.length, words2.length)) * 100);
  };

  const handleNextStep = () => {
    if (step === 2 && !uploadedDoc) {
      alert('Please upload a document first');
      return;
    }
    if (step === 3 && !verifyOTP()) {
      alert('Invalid OTP. Please try again.');
      return;
    }
    if (step === 4) {
      verifyDocuments();
      return;
    }
    setStep(step + 1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-800">Banking KYC Verification</h1>
              <p className="text-gray-600 mt-1">Secure AI-Powered Document Verification System</p>
            </div>
            <Shield className="w-12 h-12 text-indigo-600" />
          </div>
        </div>

        {/* Progress Steps */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-6">
          <div className="flex items-center justify-between">
            {[1, 2, 3, 4, 5].map((s) => (
              <div key={s} className="flex items-center">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                  step >= s ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-600'
                }`}>
                  {s}
                </div>
                {s < 5 && <div className={`w-20 h-1 ${step > s ? 'bg-indigo-600' : 'bg-gray-200'}`} />}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-3 text-xs text-gray-600">
            <span>Register</span>
            <span>Upload</span>
            <span>OTP</span>
            <span>Verify</span>
            <span>Complete</span>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-lg shadow-lg p-8">
          {/* Step 1: Customer Registration */}
          {step === 1 && (
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <User className="mr-2" /> Customer Registration
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                  <input
                    type="text"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="Enter your full name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="your.email@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="+91 XXXXX XXXXX"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Date of Birth</label>
                  <input
                    type="date"
                    name="dob"
                    value={formData.dob}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">ID Number (Aadhaar/PAN)</label>
                  <input
                    type="text"
                    name="idNumber"
                    value={formData.idNumber}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="Enter ID number"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Address</label>
                  <input
                    type="text"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="Complete address"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Document Upload */}
          {step === 2 && (
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <Upload className="mr-2" /> Upload KYC Documents
              </h2>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-indigo-500 transition-colors">
                <input
                  type="file"
                  onChange={handleFileUpload}
                  accept=".pdf,.jpg,.jpeg,.png"
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload" className="cursor-pointer">
                  <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-lg font-medium text-gray-700 mb-2">
                    Click to upload or drag and drop
                  </p>
                  <p className="text-sm text-gray-500">PDF, JPG, PNG (Max 10MB)</p>
                </label>
              </div>
              
              {uploadedDoc && (
                <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-green-800 font-medium">✓ Uploaded: {uploadedDoc.name}</p>
                </div>
              )}

              {isProcessing && (
                <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-blue-800 font-medium">🔄 Processing document with AI/OCR...</p>
                </div>
              )}

              {extractedData && (
                <div className="mt-6 p-4 bg-indigo-50 border border-indigo-200 rounded-lg">
                  <h3 className="font-bold text-indigo-900 mb-3">Extracted Information (AI/OCR):</h3>
                  <div className="space-y-2 text-sm">
                    <p><span className="font-medium">Name:</span> {extractedData.fullName}</p>
                    <p><span className="font-medium">ID Number:</span> {extractedData.idNumber}</p>
                    <p><span className="font-medium">DOB:</span> {extractedData.dob}</p>
                    <p><span className="font-medium">Address:</span> {extractedData.address}</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step 3: OTP Verification */}
          {step === 3 && (
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <Shield className="mr-2" /> OTP Authentication
              </h2>
              <div className="max-w-md mx-auto text-center">
                <p className="text-gray-600 mb-6">
                  We'll send a One-Time Password to your registered phone number for security verification.
                </p>
                {!generatedOtp ? (
                  <button
                    onClick={generateOTP}
                    className="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-colors"
                  >
                    Generate OTP
                  </button>
                ) : (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Enter OTP</label>
                    <input
                      type="text"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value)}
                      maxLength="6"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg text-center text-2xl tracking-widest focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                      placeholder="000000"
                    />
                    <p className="text-sm text-gray-500 mt-2">
                      OTP sent to {formData.phone}
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Step 4: Verification */}
          {step === 4 && !verificationResult && (
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Document Verification</h2>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <h3 className="font-bold text-gray-700 mb-2">Entered Details</h3>
                    <div className="text-sm space-y-1">
                      <p>Name: {formData.fullName}</p>
                      <p>ID: {formData.idNumber}</p>
                      <p>DOB: {formData.dob}</p>
                      <p>Address: {formData.address}</p>
                    </div>
                  </div>
                  <div className="p-4 bg-indigo-50 rounded-lg">
                    <h3 className="font-bold text-indigo-700 mb-2">Extracted from Document</h3>
                    <div className="text-sm space-y-1">
                      <p>Name: {extractedData?.fullName}</p>
                      <p>ID: {extractedData?.idNumber}</p>
                      <p>DOB: {extractedData?.dob}</p>
                      <p>Address: {extractedData?.address}</p>
                    </div>
                  </div>
                </div>
                {isProcessing && (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
                    <p className="text-gray-600">Verifying documents with AI...</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Step 5: Results */}
          {step === 5 && verificationResult && (
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Verification Results</h2>
              <div className={`p-6 rounded-lg mb-6 ${
                verificationResult.status === 'approved' ? 'bg-green-50 border border-green-200' :
                verificationResult.status === 'review' ? 'bg-yellow-50 border border-yellow-200' :
                'bg-red-50 border border-red-200'
              }`}>
                <div className="flex items-center justify-center mb-4">
                  {verificationResult.status === 'approved' ? (
                    <CheckCircle className="w-16 h-16 text-green-600" />
                  ) : verificationResult.status === 'review' ? (
                    <AlertCircle className="w-16 h-16 text-yellow-600" />
                  ) : (
                    <XCircle className="w-16 h-16 text-red-600" />
                  )}
                </div>
                <h3 className={`text-2xl font-bold text-center mb-2 ${
                  verificationResult.status === 'approved' ? 'text-green-800' :
                  verificationResult.status === 'review' ? 'text-yellow-800' :
                  'text-red-800'
                }`}>
                  {verificationResult.status === 'approved' ? 'Verification Successful!' :
                   verificationResult.status === 'review' ? 'Manual Review Required' :
                   'Verification Failed'}
                </h3>
                <p className="text-center text-gray-600 mb-4">
                  Overall Match Score: {verificationResult.overallScore.toFixed(1)}%
                </p>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <span className="font-medium">Name Match:</span>
                  <span className={verificationResult.nameMatch >= 80 ? 'text-green-600' : 'text-red-600'}>
                    {verificationResult.nameMatch}%
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <span className="font-medium">ID Number Match:</span>
                  <span className={verificationResult.idMatch ? 'text-green-600' : 'text-red-600'}>
                    {verificationResult.idMatch ? '100%' : '0%'}
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <span className="font-medium">DOB Match:</span>
                  <span className={verificationResult.dobMatch ? 'text-green-600' : 'text-red-600'}>
                    {verificationResult.dobMatch ? '100%' : '0%'}
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <span className="font-medium">Address Match:</span>
                  <span className={verificationResult.addressMatch >= 60 ? 'text-green-600' : 'text-red-600'}>
                    {verificationResult.addressMatch}%
                  </span>
                </div>
              </div>

              {verificationResult.status === 'approved' && (
                <div className="bg-indigo-50 p-4 rounded-lg">
                  <p className="text-indigo-900 font-medium">✓ Your account is ready to be activated!</p>
                  <p className="text-sm text-indigo-700 mt-1">You can now proceed with account opening.</p>
                </div>
              )}
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8">
            {step > 1 && step < 5 && (
              <button
                onClick={() => setStep(step - 1)}
                className="px-6 py-2 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-50"
              >
                Previous
              </button>
            )}
            {step < 4 && (
              <button
                onClick={handleNextStep}
                className="ml-auto px-6 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700"
              >
                {step === 3 ? 'Verify OTP' : 'Next'}
              </button>
            )}
            {step === 4 && !verificationResult && !isProcessing && (
              <button
                onClick={handleNextStep}
                className="ml-auto px-6 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700"
              >
                Start Verification
              </button>
            )}
            {step === 5 && (
              <button
                onClick={() => {
                  setStep(1);
                  setFormData({fullName: '', email: '', phone: '', address: '', idNumber: '', dob: ''});
                  setUploadedDoc(null);
                  setExtractedData(null);
                  setVerificationResult(null);
                }}
                className="ml-auto px-6 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700"
              >
                New Application
              </button>
            )}
          </div>
        </div>

        {/* Audit Log */}
        {auditLog.length > 0 && (
          <div className="bg-white rounded-lg shadow-lg p-6 mt-6">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Audit Trail</h3>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {auditLog.map((log, index) => (
                <div key={index} className="text-sm p-2 bg-gray-50 rounded flex justify-between">
                  <span className="text-gray-700">{log.action}</span>
                  <span className="text-gray-500">{log.timestamp}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default KYCVerificationApp;