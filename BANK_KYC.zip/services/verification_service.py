import re
import json
import logging
from datetime import datetime
from fuzzywuzzy import fuzz, process
from config.database import DatabaseManager
from services.document_extractor import DocumentExtractor

logger = logging.getLogger(__name__)

class VerificationService:
    def __init__(self):
        self.db = DatabaseManager()
        self.document_extractor = DocumentExtractor()
        
        # Verification thresholds
        self.thresholds = {
            'name_similarity': 80,
            'exact_match': 100,
            'address_similarity': 75,
            'overall_confidence': 70
        }
    
    def verify_document_with_user_data(self, extracted_data, user_entered_data, document_type):
        """Verify extracted document data against user-entered data"""
        try:
            verification_result = {
                'overall_match': False,
                'field_matches': {},
                'confidence_score': 0.0,
                'issues': [],
                'suggestions': []
            }
            
            total_score = 0
            max_score = 0
            field_count = 0
            
            # Verify name
            if 'name' in extracted_data and 'name' in user_entered_data:
                name_match = self.verify_name(
                    extracted_data['name'], 
                    user_entered_data['name']
                )
                verification_result['field_matches']['name'] = name_match
                total_score += name_match['score']
                max_score += 100
                field_count += 1
                
                if not name_match['is_match']:
                    verification_result['issues'].append(f"Name mismatch: Document shows '{extracted_data['name']}', entered '{user_entered_data['name']}'")
            
            # Verify ID number (exact match required)
            if 'id_number' in extracted_data and 'id_number' in user_entered_data:
                id_match = self.verify_id_number(
                    extracted_data['id_number'], 
                    user_entered_data['id_number']
                )
                verification_result['field_matches']['id_number'] = id_match
                total_score += id_match['score']
                max_score += 100
                field_count += 1
                
                if not id_match['is_match']:
                    verification_result['issues'].append("ID number does not match")
            
            # Verify date of birth
            if 'date_of_birth' in extracted_data and 'date_of_birth' in user_entered_data:
                dob_match = self.verify_date_of_birth(
                    extracted_data['date_of_birth'], 
                    user_entered_data['date_of_birth']
                )
                verification_result['field_matches']['date_of_birth'] = dob_match
                total_score += dob_match['score']
                max_score += 100
                field_count += 1
                
                if not dob_match['is_match']:
                    verification_result['issues'].append("Date of birth does not match")
            
            # Verify address (for address proof documents)
            if document_type == 'address_proof' and 'address' in extracted_data and 'address' in user_entered_data:
                address_match = self.verify_address(
                    extracted_data['address'], 
                    user_entered_data['address']
                )
                verification_result['field_matches']['address'] = address_match
                total_score += address_match['score']
                max_score += 100
                field_count += 1
                
                if not address_match['is_match']:
                    verification_result['issues'].append("Address does not match sufficiently")
            
            # Calculate overall confidence
            if max_score > 0:
                verification_result['confidence_score'] = (total_score / max_score) * 100
            
            # Determine overall match
            verification_result['overall_match'] = (
                verification_result['confidence_score'] >= self.thresholds['overall_confidence'] and
                len(verification_result['issues']) == 0
            )
            
            # Add suggestions
            if verification_result['overall_match']:
                verification_result['suggestions'].append("Document verification successful")
            else:
                verification_result['suggestions'].extend([
                    "Review and correct any mismatched information",
                    "Ensure document is clear and all text is readable",
                    "Verify that the uploaded document belongs to you"
                ])
            
            return verification_result
            
        except Exception as e:
            logger.error(f"Verification error: {e}")
            return {
                'overall_match': False,
                'field_matches': {},
                'confidence_score': 0.0,
                'issues': [f"Verification failed: {str(e)}"],
                'suggestions': ["Please try uploading the document again"]
            }
    
    def verify_name(self, extracted_name, entered_name):
        """Verify name using fuzzy matching"""
        try:
            # Clean names for comparison
            extracted_clean = self.clean_name(extracted_name)
            entered_clean = self.clean_name(entered_name)
            
            # Calculate similarity scores
            ratio = fuzz.ratio(extracted_clean.lower(), entered_clean.lower())
            token_sort_ratio = fuzz.token_sort_ratio(extracted_clean.lower(), entered_clean.lower())
            token_set_ratio = fuzz.token_set_ratio(extracted_clean.lower(), entered_clean.lower())
            
            # Use the best score
            best_score = max(ratio, token_sort_ratio, token_set_ratio)
            
            is_match = best_score >= self.thresholds['name_similarity']
            
            return {
                'is_match': is_match,
                'score': best_score,
                'similarity_ratio': ratio,
                'extracted_value': extracted_name,
                'entered_value': entered_name,
                'cleaned_extracted': extracted_clean,
                'cleaned_entered': entered_clean
            }
            
        except Exception as e:
            logger.error(f"Name verification error: {e}")
            return {'is_match': False, 'score': 0, 'error': str(e)}
    
    def verify_id_number(self, extracted_id, entered_id):
        """Verify ID number (exact match required)"""
        try:
            # Clean ID numbers
            extracted_clean = re.sub(r'[^A-Z0-9]', '', extracted_id.upper())
            entered_clean = re.sub(r'[^A-Z0-9]', '', entered_id.upper())
            
            is_match = extracted_clean == entered_clean
            score = 100 if is_match else 0
            
            return {
                'is_match': is_match,
                'score': score,
                'extracted_value': extracted_id,
                'entered_value': entered_id,
                'cleaned_extracted': extracted_clean,
                'cleaned_entered': entered_clean
            }
            
        except Exception as e:
            logger.error(f"ID verification error: {e}")
            return {'is_match': False, 'score': 0, 'error': str(e)}
    
    def verify_date_of_birth(self, extracted_dob, entered_dob):
        """Verify date of birth"""
        try:
            # Normalize date formats
            extracted_normalized = self.normalize_date(extracted_dob)
            entered_normalized = self.normalize_date(entered_dob)
            
            is_match = extracted_normalized == entered_normalized
            score = 100 if is_match else 0
            
            return {
                'is_match': is_match,
                'score': score,
                'extracted_value': extracted_dob,
                'entered_value': entered_dob,
                'normalized_extracted': extracted_normalized,
                'normalized_entered': entered_normalized
            }
            
        except Exception as e:
            logger.error(f"DOB verification error: {e}")
            return {'is_match': False, 'score': 0, 'error': str(e)}
    
    def verify_address(self, extracted_address, entered_address):
        """Verify address using fuzzy matching"""
        try:
            # Clean addresses
            extracted_clean = self.clean_address(extracted_address)
            entered_clean = self.clean_address(entered_address)
            
            # Calculate similarity
            similarity = fuzz.token_set_ratio(extracted_clean.lower(), entered_clean.lower())
            
            is_match = similarity >= self.thresholds['address_similarity']
            
            return {
                'is_match': is_match,
                'score': similarity,
                'similarity_ratio': similarity,
                'extracted_value': extracted_address,
                'entered_value': entered_address,
                'cleaned_extracted': extracted_clean,
                'cleaned_entered': entered_clean
            }
            
        except Exception as e:
            logger.error(f"Address verification error: {e}")
            return {'is_match': False, 'score': 0, 'error': str(e)}
    
    def clean_name(self, name):
        """Clean name for comparison"""
        if not name:
            return ""
        
        # Remove common prefixes and suffixes
        name = re.sub(r'^(Mr\.?|Mrs\.?|Ms\.?|Dr\.?)\s*', '', name, flags=re.IGNORECASE)
        name = re.sub(r'\s*(Jr\.?|Sr\.?|III|II)$', '', name, flags=re.IGNORECASE)
        
        # Remove extra whitespace and special characters
        name = re.sub(r'[^A-Za-z\s]', '', name)
        name = ' '.join(name.split())
        
        return name.strip()
    
    def clean_address(self, address):
        """Clean address for comparison"""
        if not address:
            return ""
        
        # Remove common variations
        address = re.sub(r'\b(Street|St\.?|Road|Rd\.?|Avenue|Ave\.?|Lane|Ln\.?)\b', 'ST', address, flags=re.IGNORECASE)
        address = re.sub(r'\b(Apartment|Apt\.?|Unit)\b', 'APT', address, flags=re.IGNORECASE)
        
        # Remove extra whitespace and normalize
        address = re.sub(r'\s+', ' ', address)
        address = re.sub(r'[^\w\s]', ' ', address)
        
        return ' '.join(address.split())
    
    def normalize_date(self, date_string):
        """Normalize date format"""
        if not date_string:
            return ""
        
        # Extract numbers from date string
        numbers = re.findall(r'\d+', date_string)
        
        if len(numbers) >= 3:
            day, month, year = numbers[0], numbers[1], numbers[2]
            
            # Handle 2-digit years
            if len(year) == 2:
                year = '19' + year if int(year) > 50 else '20' + year
            
            # Normalize to DD-MM-YYYY format
            return f"{day.zfill(2)}-{month.zfill(2)}-{year}"
        
        return date_string
    
    def update_kyc_status(self, customer_id, document_type, verification_result, confidence_score):
        """Update KYC status based on verification result"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                # Determine status
                status = 'verified' if verification_result['overall_match'] else 'failed'
                
                # Update document-specific status
                if document_type == 'id_proof':
                    cursor.execute("""
                        UPDATE kyc_status 
                        SET id_proof_status = ?, last_updated = CURRENT_TIMESTAMP
                        WHERE customer_id = ?
                    """, (status, customer_id))
                elif document_type == 'address_proof':
                    cursor.execute("""
                        UPDATE kyc_status 
                        SET address_proof_status = ?, last_updated = CURRENT_TIMESTAMP
                        WHERE customer_id = ?
                    """, (status, customer_id))
                elif document_type == 'photo':
                    cursor.execute("""
                        UPDATE kyc_status 
                        SET photo_status = ?, last_updated = CURRENT_TIMESTAMP
                        WHERE customer_id = ?
                    """, (status, customer_id))
                
                # Calculate overall completion
                cursor.execute("""
                    SELECT id_proof_status, address_proof_status, photo_status
                    FROM kyc_status WHERE customer_id = ?
                """, (customer_id,))
                
                statuses = cursor.fetchone()
                if statuses:
                    verified_count = sum(1 for s in statuses if s == 'verified')
                    completion_percentage = (verified_count / 3) * 100
                    
                    overall_status = 'completed' if verified_count == 3 else 'in_progress' if verified_count > 0 else 'incomplete'
                    
                    cursor.execute("""
                        UPDATE kyc_status 
                        SET overall_status = ?, completion_percentage = ?, verification_score = ?
                        WHERE customer_id = ?
                    """, (overall_status, completion_percentage, confidence_score, customer_id))
                
                conn.commit()
                
                # Log audit
                self.db.log_audit({
                    'customer_id': customer_id,
                    'action': 'KYC_STATUS_UPDATED',
                    'details': f'{document_type} verification: {status}, confidence: {confidence_score}'
                })
                
        except Exception as e:
            logger.error(f"KYC status update error: {e}")
    
    def get_kyc_status(self, customer_id):
        """Get current KYC status for customer"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT * FROM kyc_status WHERE customer_id = ?
                """, (customer_id,))
                
                status = cursor.fetchone()
                if status:
                    return {
                        'customer_id': status[1],
                        'overall_status': status[2],
                        'id_proof_status': status[3],
                        'address_proof_status': status[4],
                        'photo_status': status[5],
                        'verification_score': status[6],
                        'completion_percentage': status[7],
                        'last_updated': status[8]
                    }
                return None
                
        except Exception as e:
            logger.error(f"KYC status retrieval error: {e}")
            return None