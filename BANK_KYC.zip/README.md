# Banking KYC Document Upload & Verification Application

A comprehensive Streamlit-based banking KYC (Know Your Customer) application with AI-powered document extraction, verification, and OTP authentication.

## 🚀 Features

### Core Features
- **🔐 Secure Authentication**: Customer registration and login with encrypted passwords
- **📱 OTP Verification**: Two-factor authentication for document verification
- **🤖 AI-Powered OCR**: Automatic data extraction from uploaded documents using Tesseract
- **✅ Smart Verification**: Fuzzy matching algorithms for name, address, and ID verification
- **📊 Real-time Dashboard**: Live KYC status tracking and progress monitoring
- **📋 Audit Trail**: Comprehensive logging for compliance and regulatory requirements

### Document Processing
- **📄 Multi-format Support**: PDF, JPG, PNG, JPEG document upload
- **🔍 Document Validation**: Format checking and completeness verification
- **📸 Image Preprocessing**: Advanced OCR preprocessing for better text extraction
- **💯 Confidence Scoring**: ML-based confidence assessment for extracted data

### Security & Compliance
- **🔒 Bank-grade Security**: Encrypted data storage and secure file handling
- **📊 Compliance Reports**: Exportable reports for regulatory requirements
- **🕒 Activity Logging**: Complete audit trail of all user actions
- **🛡️ Data Protection**: Secure customer information handling

## 📁 Project Structure

```
banking-kyc-app/
├── main.py                     # Main Streamlit application
├── requirements.txt            # Python dependencies
├── README.md                   # Documentation
├── config/
│   └── database.py            # Database configuration and models
├── services/
│   ├── auth_service.py        # Authentication and OTP services
│   ├── document_extractor.py  # AI/OCR document extraction
│   ├── verification_service.py # Document verification logic
│   └── audit_service.py       # Audit logging and reporting
├── pages/
│   ├── authentication.py      # Login/registration pages
│   ├── dashboard.py           # Main dashboard
│   ├── document_upload.py     # Document upload and processing
│   └── reports.py             # Reports and analytics
├── uploads/                   # Document storage directory
└── data/                      # SQLite database storage
```

## 🛠️ Installation & Setup

### Prerequisites
- Python 3.8 or higher
- Tesseract OCR engine

### Install Tesseract
#### Windows:
1. Download from: https://github.com/UB-Mannheim/tesseract/wiki
2. Install and add to PATH

#### Mac:
```bash
brew install tesseract
```

#### Linux:
```bash
sudo apt-get install tesseract-ocr
```

### Install Dependencies
```bash
pip install -r requirements.txt
```

### Create Required Directories
```bash
mkdir uploads data
```

## 🚀 Running the Application

```bash
streamlit run main.py
```

The application will be available at `http://localhost:8501`

## 📚 Usage Guide

### 1. Customer Registration
- Navigate to the registration tab
- Fill in personal information (name, email, phone, password)
- Accept terms and conditions
- Submit registration

### 2. Login
- Use registered email and password
- Access the dashboard upon successful authentication

### 3. Document Upload
- Select document type (ID Proof, Address Proof, Photo ID)
- Upload clear, high-quality images
- AI extracts data automatically
- Enter manual verification details
- Complete OTP verification

### 4. Verification Process
- AI extracts data from documents using OCR
- System performs fuzzy matching against entered data
- Confidence scores calculated for verification
- OTP verification for security
- Real-time status updates

### 5. Dashboard Monitoring
- Track KYC completion progress
- View document verification status
- Access next steps and requirements
- Monitor verification scores

### 6. Reports & Analytics
- View comprehensive KYC summary
- Access document history
- Export PDF and CSV reports
- Review activity audit logs

## 🤖 AI/ML Integration

### Document Extraction Models
The application supports integration with various OCR and ML services:

#### Current Implementation (Demo)
- **Tesseract OCR**: Open-source text extraction
- **OpenCV**: Image preprocessing and enhancement
- **Custom ML Pipeline**: Pattern matching and data extraction

#### Production-Ready Integrations
```python
# AWS Textract
import boto3
textract = boto3.client('textract')

# Google Cloud Vision API
from google.cloud import vision
client = vision.ImageAnnotatorClient()

# Azure Form Recognizer
from azure.cognitiveservices.vision.computervision import ComputerVisionClient

# Paddle OCR
import paddleocr
ocr = paddleocr.PaddleOCR()
```

## 🔧 Configuration

### Environment Variables
Create a `.env` file for production configuration:

```env
# Database
DB_PATH=data/kyc_bank.db

# Security
SECRET_KEY=your-secret-key
ENCRYPTION_KEY=your-encryption-key

# OCR Service (Production)
OCR_SERVICE=aws_textract  # or google_vision, azure_form_recognizer
AWS_ACCESS_KEY_ID=your-aws-key
AWS_SECRET_ACCESS_KEY=your-aws-secret

# SMS/Email Service (Production)
SMS_PROVIDER=twilio
TWILIO_ACCOUNT_SID=your-twilio-sid
TWILIO_AUTH_TOKEN=your-twilio-token
TWILIO_PHONE_NUMBER=your-twilio-phone

EMAIL_PROVIDER=sendgrid
SENDGRID_API_KEY=your-sendgrid-key
```

## 📊 Document Requirements

### Accepted Document Types

#### ID Proof (Any one)
- ✅ Aadhaar Card
- ✅ PAN Card
- ✅ Passport
- ✅ Driving License
- ✅ Voter ID

#### Address Proof (Any one)
- ✅ Utility Bill (Electricity/Water/Gas)
- ✅ Bank Statement
- ✅ Rental Agreement
- ✅ Aadhaar Card

#### Photo ID
- ✅ Clear photograph
- ✅ Passport size
- ✅ Recent (within 6 months)

### Upload Guidelines
- 📸 Clear, well-lit photographs
- 📄 All text should be readable
- 🔍 No blur or shadows
- 📐 Document should be flat and straight
- ✅ All corners visible
- 📱 Maximum file size: 10MB

## 🔒 Security Features

- **Password Encryption**: Bcrypt hashing for secure password storage
- **Session Management**: Secure session handling
- **OTP Authentication**: Time-based one-time passwords
- **Data Encryption**: Sensitive data encryption at rest
- **Audit Logging**: Complete activity tracking
- **Input Validation**: Comprehensive input sanitization
- **File Security**: Secure file upload and storage

## 📈 Monitoring & Analytics

### KYC Metrics
- Customer registration trends
- Document verification rates
- Average processing time
- Completion percentages
- Confidence score distributions

### Compliance Reports
- Regulatory compliance dashboards
- Audit trail exports
- Customer verification summaries
- Document status reports
- Activity analytics

## 🚀 Production Deployment

### Docker Deployment
```dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

# Install Tesseract
RUN apt-get update && apt-get install -y tesseract-ocr

COPY . .
EXPOSE 8501

CMD ["streamlit", "run", "main.py", "--server.port=8501", "--server.address=0.0.0.0"]
```

### Cloud Deployment Options
- **AWS**: ECS, Lambda, or EC2
- **Google Cloud**: Cloud Run or Compute Engine
- **Azure**: Container Instances or App Service
- **Heroku**: Direct deployment with buildpacks

### Scaling Considerations
- **Database**: Migrate to PostgreSQL/MySQL for production
- **File Storage**: Use cloud storage (S3, GCS, Azure Blob)
- **OCR Service**: Implement cloud-based OCR APIs
- **Load Balancing**: Use multiple application instances
- **Caching**: Implement Redis for session management

## 🔧 Customization

### Adding New Document Types
```python
# In services/document_extractor.py
document_patterns = {
    'new_document_type': {
        'patterns': {
            'field_name': [r'regex_pattern_1', r'regex_pattern_2'],
            # Add more fields
        },
        'required_fields': ['field_name']
    }
}
```

### Custom Verification Logic
```python
# In services/verification_service.py
def custom_verification_method(self, extracted_data, user_data):
    # Implement custom verification logic
    return verification_result
```

## 🧪 Testing

### Unit Tests
```bash
python -m pytest tests/
```

### Test Coverage
```bash
python -m pytest --cov=services tests/
```

### Load Testing
```bash
locust -f tests/load_test.py
```

## 📞 Support

- **📧 Email**: support@bankingkyc.com
- **📞 Phone**: 1800-XXX-XXXX (24/7)
- **💬 Chat**: Live chat available 9 AM - 6 PM
- **📚 Docs**: [Documentation Portal](https://docs.bankingkyc.com)

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 🙏 Acknowledgments

- **Streamlit**: For the amazing web framework
- **Tesseract**: For open-source OCR capabilities
- **OpenCV**: For image processing utilities
- **SQLite**: For lightweight database solution
- **FuzzyWuzzy**: For fuzzy string matching

---

**Built with ❤️ for secure and efficient KYC verification**