import re
import logging
from dataclasses import dataclass
from typing import Dict, Any, Optional, Tuple, List

import torch
import numpy as np
import cv2
from PIL import Image
from transformers import TrOCRProcessor, VisionEncoderDecoderModel

logger = logging.getLogger(__name__)


@dataclass
class AadhaarExtraction:
    aadhaar_number: Optional[str] = None


class TrOCRBasedAadhaarExtractor:
    """Aadhaar extractor using TrOCR (microsoft/trocr-base-printed).

    Notes:
    - Image-only for now (JPG/PNG/etc.).
    - This extractor returns best-effort fields + confidences.
    - Uses GPU automatically if available.
    """

    MODEL_NAME = "microsoft/trocr-base-printed"

    def __init__(self, device: Optional[str] = None):
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        self.device = torch.device(device)

        self.processor = TrOCRProcessor.from_pretrained(self.MODEL_NAME)
        self.model = VisionEncoderDecoderModel.from_pretrained(self.MODEL_NAME)
        self.model.to(self.device)
        self.model.eval()

    def extract(self, pil_image: Image.Image) -> Dict[str, Any]:
        """Extract Aadhaar fields from an image.

        TrOCR works best on cropped text-lines/blocks. So we:
        1) propose text regions,
        2) run TrOCR on top crops,
        3) merge the text and parse fields.
        """
        raw_text, ocr_conf, debug = self._ocr_by_regions(pil_image)
        fields = self._parse_aadhaar_id_only(raw_text)

        # Basic confidence logic: start from OCR confidence and penalize missing fields
        per_field_conf: Dict[str, float] = {}
        required = ["aadhaar_number"]
        for key in required:
            val = fields.get(key)
            if val:
                per_field_conf[key] = min(0.99, max(0.45, float(ocr_conf)))
            else:
                per_field_conf[key] = 0.0

        overall = sum(per_field_conf.values()) / len(required)

        # IMPORTANT: treat partial extraction as success
        # We want the UI to show whatever we extracted and allow user verification.
        has_any_field = bool(fields.get('aadhaar_number'))
        return {
            "success": bool(has_any_field),
            "document_type": "aadhaar",
            "raw_text": raw_text,
            "fields": fields,
            "confidence": {
                "ocr": float(ocr_conf),
                "fields": per_field_conf,
                "overall": float(overall),
            },
            "debug": debug,
        }

    def _ocr_single_crop(self, pil_image: Image.Image, max_length: int = 96) -> Tuple[str, float]:
        """Run TrOCR on a crop and approximate confidence."""
        pixel_values = self.processor(images=pil_image.convert("RGB"), return_tensors="pt").pixel_values
        pixel_values = pixel_values.to(self.device)

        with torch.no_grad():
            generated = self.model.generate(
                pixel_values,
                max_length=max_length,
                return_dict_in_generate=True,
                output_scores=True,
            )

        text = self.processor.batch_decode(generated.sequences, skip_special_tokens=True)[0].strip()

        conf = 0.7
        try:
            step_scores = generated.scores
            if step_scores:
                max_probs = []
                for s in step_scores[:32]:
                    probs = torch.softmax(s[0], dim=-1)
                    max_probs.append(float(torch.max(probs).item()))
                if max_probs:
                    conf = float(sum(max_probs) / len(max_probs))
                    conf = max(0.2, min(conf, 0.99))
        except Exception as e:
            logger.debug(f"Could not compute TrOCR confidence: {e}")

        return text, conf

    def _ocr_by_regions(self, pil_image: Image.Image) -> Tuple[str, float, Dict[str, Any]]:
        """Detect text-like regions and run TrOCR per region.

        This dramatically improves results vs running TrOCR on the whole card.
        """
        # Convert to OpenCV image
        rgb = np.array(pil_image.convert('RGB'))
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)

        # Preprocess for text region detection
        # 1) normalize contrast
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        gray = clahe.apply(gray)

        # 2) binarize
        thr = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                    cv2.THRESH_BINARY_INV, 35, 15)

        # 3) connect text into lines/blocks
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (25, 3))
        morph = cv2.morphologyEx(thr, cv2.MORPH_CLOSE, kernel, iterations=2)

        # Find contours
        contours, _ = cv2.findContours(morph, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        H, W = gray.shape[:2]
        boxes = []
        for c in contours:
            x, y, w, h = cv2.boundingRect(c)
            # Filter tiny regions (very relaxed for screenshots/small text)
            if w < W * 0.02 or h < 8:
                continue
            if w > W * 0.995 and h > H * 0.95:
                continue
            boxes.append((x, y, x + w, y + h))

        # If contour-based detection finds nothing usable, try MSER fallback
        if not boxes:
            mser = cv2.MSER_create()
            regions, _ = mser.detectRegions(gray)
            for region in regions:
                x, y, w, h = cv2.boundingRect(region)
                if w < W * 0.02 or h < 8:
                    continue
                # Avoid extremely large regions
                if w > W * 0.995 and h > H * 0.95:
                    continue
                boxes.append((x, y, x + w, y + h))

        # Sort in reading order (top-to-bottom, then left-to-right)
        boxes = sorted(boxes, key=lambda b: (b[1], b[0]))

        # Take top N regions (more regions to increase recall)
        max_regions = 40
        boxes = boxes[:max_regions]

        crop_debug: List[Dict[str, Any]] = []

        found_aadhaar_text = None
        found_aadhaar_bbox = None

        for (x1, y1, x2, y2) in boxes:
            # Add padding
            pad_x = int(0.02 * W)
            pad_y = int(0.01 * H)
            xx1 = max(0, x1 - pad_x)
            yy1 = max(0, y1 - pad_y)
            xx2 = min(W, x2 + pad_x)
            yy2 = min(H, y2 + pad_y)

            crop = pil_image.crop((xx1, yy1, xx2, yy2))

            # Increase crop size for OCR (TrOCR likes larger text)
            crop = crop.resize((crop.size[0] * 3, crop.size[1] * 3))

            t, c = self._ocr_single_crop(crop, max_length=128)
            t = t.strip()
            # Filter obvious noise (TrOCR sometimes outputs ':' or repeated symbols)
            if t:
                alnum = re.sub(r"[^A-Za-z0-9]", "", t)
                non_alnum_ratio = len(re.sub(r"[A-Za-z0-9]", "", t)) / max(1, len(t))
                if len(alnum) < 3 or re.fullmatch(r"[:\-_=\.]+", t) or non_alnum_ratio > 0.7:
                    t = ""
            crop_debug.append({
                'bbox': [int(xx1), int(yy1), int(xx2), int(yy2)],
                'y': int(yy1),
                'text': t,
                'conf': float(c),
            })

            # EARLY STOP: If we already found an Aadhaar number pattern, stop scanning more crops.
            if t:
                t2 = t.replace('O','0').replace('o','0').replace('I','1').replace('l','1').replace('S','5')
                if re.search(r"\b\d{4}\s*\d{4}\s*\d{4}\b", t2):
                    found_aadhaar_text = t
                    found_aadhaar_bbox = [int(xx1), int(yy1), int(xx2), int(yy2)]
                    break

        # Since we only need Aadhaar number, if early-stop found it, return quickly
        if found_aadhaar_text:
            debug = {
                'regions_detected': len(contours),
                'regions_used': len(boxes),
                'crops_with_text': sum(1 for d in crop_debug if d['text']),
                'found_aadhaar_bbox': found_aadhaar_bbox,
                'found_aadhaar_text': (found_aadhaar_text or '')[:120],
                'strategy': 'contour/mser early-stop'
            }
            avg_conf = float(sum([d.get('conf', 0.0) for d in crop_debug if d.get('text')]) / max(1, sum(1 for d in crop_debug if d.get('text'))))
            return found_aadhaar_text, avg_conf if avg_conf else 0.6, debug

        # Second pass: scan a few wide horizontal strips in the lower half (Aadhaar number is commonly there)
        strip_debug = []
        pil_w, pil_h = pil_image.size
        strips = [
            (0, int(pil_h*0.55), pil_w, int(pil_h*0.75)),
            (0, int(pil_h*0.65), pil_w, int(pil_h*0.85)),
            (0, int(pil_h*0.75), pil_w, pil_h),
        ]
        for (sx1, sy1, sx2, sy2) in strips:
            crop = pil_image.crop((sx1, sy1, sx2, sy2)).resize((pil_w*2, int((sy2-sy1)*2)))
            t, c = self._ocr_single_crop(crop, max_length=128)
            t = (t or '').strip()
            t2 = t.replace('O','0').replace('o','0').replace('I','1').replace('l','1').replace('S','5')
            strip_debug.append({'bbox':[sx1,sy1,sx2,sy2], 'text': t[:80], 'conf': float(c)})
            if re.search(r"\b\d{4}\s*\d{4}\s*\d{4}\b", t2):
                debug = {
                    'regions_detected': len(contours),
                    'regions_used': len(boxes),
                    'crops_with_text': sum(1 for d in crop_debug if d['text']),
                    'strategy': 'strip-scan',
                    'strip_samples': strip_debug
                }
                return t, float(c), debug

        # Identify the likely Aadhaar-number crop (kept for debug/ranking)
        aadhaar_y = None
        for d in crop_debug:
            tt = (d.get('text') or '')
            if re.search(r"\b\d{4}\s*\d{4}\s*\d{4}\b", tt.replace('O','0').replace('I','1').replace('l','1')):
                aadhaar_y = d.get('y')
                break

        # Rank crops: prefer ones likely containing Aadhaar fields
        def score_crop(d: Dict[str, Any]) -> float:
            t = (d.get('text') or '').strip()
            if not t:
                return -1e9
            tl = t.lower()

            # Hard reject obviously irrelevant patterns
            if any(k in tl for k in ['total amount', 'amount', 'gst', 'invoice', 'receipt', 'sr:']):
                return -1e6

            score = float(d.get('conf', 0.0))

            # Prefer crops above Aadhaar number for name/dob/gender
            if aadhaar_y is not None and d.get('y', 0) < aadhaar_y:
                score += 0.2

            # keywords
            if re.search(r"\b(male|female)\b", tl):
                score += 0.9
            if 'dob' in tl or 'birth' in tl or re.search(r"\b\d{2}[/-]\d{2}[/-]\d{4}\b", t):
                score += 1.0

            # Aadhaar number crop: strongly boost
            if re.search(r"\b\d{4}\s*\d{4}\s*\d{4}\b", t.replace('O','0').replace('I','1').replace('l','1')):
                score += 2.0

            # mild preference for mid/lower part (but not extreme) to reduce header junk
            y_norm = (d.get('y', 0) / max(1, H))
            score += (0.25 - abs(y_norm - 0.65)) * 0.2

            return score

        ranked = sorted(crop_debug, key=score_crop, reverse=True)
        top_texts = [d['text'] for d in ranked[:25] if d.get('text') and score_crop(d) > -1e5]

        merged = "\n".join(top_texts).strip()
        confs = [d.get('conf', 0.0) for d in ranked[:25] if d.get('text') and score_crop(d) > -1e5]

        debug = {
            'regions_detected': len(contours),
            'regions_used': len(boxes),
            'crops_with_text': sum(1 for d in crop_debug if d['text']),
            'top_ranked_samples': [{
                'bbox': d['bbox'],
                'y': d.get('y'),
                'conf': d.get('conf'),
                'text': (d.get('text') or '')[:80]
            } for d in ranked[:12]],
        }

        if not merged:
            # fallback to full image OCR (last resort) - upscale image first
            up = pil_image.resize((pil_image.size[0] * 2, pil_image.size[1] * 2))
            t, c = self._ocr_single_crop(up, max_length=256)
            debug['fallback_full_image'] = True
            debug['fallback_text'] = t[:120]
            return t, c, debug

        avg_conf = float(sum(confs) / len(confs)) if confs else 0.5
        return merged, avg_conf, debug

    def _parse_aadhaar_id_only(self, text: str) -> Dict[str, Optional[str]]:
        """Parse Aadhaar fields from OCR text using heuristics.

        Region-based OCR gives us multiple lines; use line context to extract fields.
        """
        raw = text or ""
        cleaned = self._normalize_whitespace(raw)
        aadhaar_number = self._extract_aadhaar_number(cleaned)
        return {"aadhaar_number": aadhaar_number}

    @staticmethod
    def _extract_name_from_lines(lines: List[str], full_text: str) -> Optional[str]:
        """Try to extract name using line context.

        Common Aadhaar layout:
        - Name appears near DOB/Gender lines.
        - We prefer a line with 2-4 words, mostly alphabetic.
        """
        blacklist = {
            "government", "india", "aadhaar", "dob", "d0b", "year", "birth",
            "male", "female", "unique", "identification", "authority",
            "address", "total", "amount", "gst", "invoice", "receipt", "card",
            "sr", "rs", "payment", "transaction"
        }

        def looks_like_name(line: str) -> bool:
            words = [w for w in re.split(r"\s+", line) if w]
            if len(words) < 2 or len(words) > 5:
                return False
            alpha_words = 0
            for w in words:
                ww = re.sub(r"[^A-Za-z]", "", w)
                if len(ww) >= 2:
                    alpha_words += 1
            if alpha_words < 2:
                return False
            if any(w.lower() in blacklist for w in words):
                return False
            if re.search(r"\d", line):
                return False
            return True

        # Prefer lines just above a DOB/Gender line
        for i, line in enumerate(lines):
            if re.search(r"\b(\d{2}[/-]\d{2}[/-]\d{4}|19\d{2}|20\d{2})\b", line) or re.search(r"\b(MALE|FEMALE|Male|Female|male|female)\b", line):
                # look a few lines above
                for j in range(max(0, i - 3), i):
                    cand = lines[j]
                    if looks_like_name(cand):
                        return ' '.join(cand.split()).title()

        # Otherwise pick the first best-looking name line
        for line in lines:
            if looks_like_name(line):
                return ' '.join(line.split()).title()

        # final fallback: old token heuristic
        return TrOCRBasedAadhaarExtractor._extract_name(full_text, dob=None, gender=None)

    @staticmethod
    def _normalize_whitespace(s: str) -> str:
        return re.sub(r"\s+", " ", s).strip()

    @staticmethod
    def _extract_aadhaar_number(s: str) -> Optional[str]:
        # Correct common OCR confusions for numeric sequences
        s2 = s.replace('O', '0').replace('o', '0').replace('I', '1').replace('l', '1').replace('S', '5')
        m = re.search(r"\b(\d{4})\s*(\d{4})\s*(\d{4})\b", s2)
        if not m:
            return None
        return f"{m.group(1)} {m.group(2)} {m.group(3)}"

    @staticmethod
    def _extract_dob(s: str) -> Optional[str]:
        # Aadhaar often has DOB: DD/MM/YYYY or Year of Birth: YYYY
        m = re.search(r"\b(\d{2}[/-]\d{2}[/-]\d{4})\b", s)
        if m:
            return m.group(1).replace("-", "/")

        m = re.search(r"\b(19\d{2}|20\d{2})\b", s)
        if m:
            # year only
            return f"01/01/{m.group(1)}"
        return None

    @staticmethod
    def _extract_gender(s: str) -> Optional[str]:
        m = re.search(r"\b(MALE|FEMALE|Male|Female|male|female|M|F)\b", s)
        if not m:
            return None
        val = m.group(1).lower()
        if val in ("m", "male"):
            return "Male"
        if val in ("f", "female"):
            return "Female"
        return None

    @staticmethod
    def _extract_name(s: str, dob: Optional[str], gender: Optional[str]) -> Optional[str]:
        # Heuristic: choose the first line-ish token group that looks like a name.
        # Remove obvious non-name tokens.
        blacklist = {
            "government", "india", "aadhaar", "dob", "year", "birth", "male", "female",
            "unique", "identification", "authority"
        }

        # Split into chunks; TrOCR returns mostly whitespace-separated tokens.
        tokens = [t for t in re.split(r"\s+", s) if t]

        # Remove aadhaar number tokens and dob tokens
        filtered = []
        for t in tokens:
            if re.fullmatch(r"\d{4}", t) or re.fullmatch(r"\d{2}[/-]\d{2}[/-]\d{4}", t):
                continue
            if t.lower() in blacklist:
                continue
            # Keep alpha-ish tokens
            if re.fullmatch(r"[A-Za-z]{2,}", t) or re.fullmatch(r"[A-Za-z]{2,}\.", t):
                filtered.append(t)

        if len(filtered) < 2:
            return None

        # Take first 2-4 tokens as name candidate
        candidate = " ".join(filtered[:4])
        candidate = re.sub(r"[^A-Za-z\s\.]", "", candidate)
        candidate = " ".join(candidate.split()).title()

        # Require at least two parts
        if len(candidate.split()) < 2:
            return None
        return candidate
