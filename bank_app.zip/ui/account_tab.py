
import streamlit as st
from services.account_service import open_account

def account_tab():
    st.subheader("Open Bank Account")

    reg = st.text_input("Registered Number")
    mobile = st.text_input("Mobile Number")

    if st.button("Open Account"):
        success, result = open_account(reg)
        if success:
            st.success(f"Account opened successfully. Account No: {result}")
        else:
            if result == "KYC_NOT_DONE":
                st.error("Please complete KYC first")
            else:
                st.warning("Account already exists")
