import pandas as pd
import json
from datetime import datetime, timedelta
import logging
from config.database import DatabaseManager
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter, A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
import io

logger = logging.getLogger(__name__)

class AuditService:
    def __init__(self):
        self.db = DatabaseManager()
    
    def get_audit_logs(self, customer_id=None, date_from=None, date_to=None, action_type=None, limit=100):
        """Retrieve audit logs with filters"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                # Build query with filters
                query = "SELECT * FROM audit_logs WHERE 1=1"
                params = []
                
                if customer_id:
                    query += " AND customer_id = ?"
                    params.append(customer_id)
                
                if date_from:
                    query += " AND timestamp >= ?"
                    params.append(date_from)
                
                if date_to:
                    query += " AND timestamp <= ?"
                    params.append(date_to)
                
                if action_type:
                    query += " AND action = ?"
                    params.append(action_type)
                
                query += " ORDER BY timestamp DESC LIMIT ?"
                params.append(limit)
                
                cursor.execute(query, params)
                logs = cursor.fetchall()
                
                # Convert to list of dictionaries
                columns = ['id', 'customer_id', 'action', 'details', 'ip_address', 'user_agent', 'timestamp']
                return [dict(zip(columns, log)) for log in logs]
                
        except Exception as e:
            logger.error(f"Error retrieving audit logs: {e}")
            return []
    
    def get_kyc_statistics(self, date_from=None, date_to=None):
        """Get KYC statistics for reporting"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                # Total customers
                cursor.execute("SELECT COUNT(*) FROM customers")
                total_customers = cursor.fetchone()[0]
                
                # KYC status breakdown
                cursor.execute("""
                    SELECT overall_status, COUNT(*) as count
                    FROM kyc_status
                    GROUP BY overall_status
                """)
                status_breakdown = dict(cursor.fetchall())
                
                # Document verification stats
                cursor.execute("""
                    SELECT 
                        SUM(CASE WHEN id_proof_status = 'verified' THEN 1 ELSE 0 END) as id_verified,
                        SUM(CASE WHEN address_proof_status = 'verified' THEN 1 ELSE 0 END) as address_verified,
                        SUM(CASE WHEN photo_status = 'verified' THEN 1 ELSE 0 END) as photo_verified
                    FROM kyc_status
                """)
                doc_stats = cursor.fetchone()
                
                # Average verification score
                cursor.execute("SELECT AVG(verification_score) FROM kyc_status WHERE verification_score > 0")
                avg_score = cursor.fetchone()[0] or 0
                
                # Recent registrations (last 30 days)
                thirty_days_ago = (datetime.now() - timedelta(days=30)).isoformat()
                cursor.execute("SELECT COUNT(*) FROM customers WHERE created_at >= ?", (thirty_days_ago,))
                recent_registrations = cursor.fetchone()[0]
                
                return {
                    'total_customers': total_customers,
                    'status_breakdown': status_breakdown,
                    'document_stats': {
                        'id_verified': doc_stats[0] or 0,
                        'address_verified': doc_stats[1] or 0,
                        'photo_verified': doc_stats[2] or 0
                    },
                    'avg_verification_score': round(avg_score, 2),
                    'recent_registrations': recent_registrations
                }
                
        except Exception as e:
            logger.error(f"Error retrieving KYC statistics: {e}")
            return {}
    
    def get_customer_kyc_report(self, customer_id):
        """Generate comprehensive KYC report for a customer"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                # Customer information
                cursor.execute("SELECT * FROM customers WHERE customer_id = ?", (customer_id,))
                customer = cursor.fetchone()
                
                if not customer:
                    return None
                
                # KYC status
                cursor.execute("SELECT * FROM kyc_status WHERE customer_id = ?", (customer_id,))
                kyc_status = cursor.fetchone()
                
                # Documents
                cursor.execute("SELECT * FROM documents WHERE customer_id = ?", (customer_id,))
                documents = cursor.fetchall()
                
                # Audit trail
                audit_logs = self.get_audit_logs(customer_id=customer_id, limit=50)
                
                report = {
                    'customer_info': {
                        'customer_id': customer[1],
                        'name': customer[2],
                        'email': customer[3],
                        'phone': customer[4],
                        'status': customer[6],
                        'created_at': customer[7],
                        'updated_at': customer[8]
                    },
                    'kyc_status': {
                        'overall_status': kyc_status[2] if kyc_status else 'incomplete',
                        'id_proof_status': kyc_status[3] if kyc_status else 'pending',
                        'address_proof_status': kyc_status[4] if kyc_status else 'pending',
                        'photo_status': kyc_status[5] if kyc_status else 'pending',
                        'verification_score': kyc_status[6] if kyc_status else 0,
                        'completion_percentage': kyc_status[7] if kyc_status else 0,
                        'last_updated': kyc_status[8] if kyc_status else None
                    },
                    'documents': [],
                    'audit_trail': audit_logs
                }
                
                # Process documents
                for doc in documents:
                    doc_info = {
                        'document_type': doc[2],
                        'file_name': doc[3],
                        'verification_status': doc[5],
                        'confidence_score': doc[6],
                        'uploaded_at': doc[7],
                        'verified_at': doc[8]
                    }
                    
                    # Parse extracted data if available
                    if doc[4]:  # extracted_data
                        try:
                            doc_info['extracted_data'] = json.loads(doc[4])
                        except:
                            doc_info['extracted_data'] = {}
                    
                    report['documents'].append(doc_info)
                
                return report
                
        except Exception as e:
            logger.error(f"Error generating customer KYC report: {e}")
            return None
    
    def export_audit_logs_csv(self, filters=None):
        """Export audit logs to CSV format"""
        try:
            # Get logs with filters
            logs = self.get_audit_logs(
                customer_id=filters.get('customer_id') if filters else None,
                date_from=filters.get('date_from') if filters else None,
                date_to=filters.get('date_to') if filters else None,
                action_type=filters.get('action_type') if filters else None,
                limit=filters.get('limit', 1000) if filters else 1000
            )
            
            if not logs:
                return None
            
            # Create DataFrame
            df = pd.DataFrame(logs)
            
            # Convert to CSV
            csv_buffer = io.StringIO()
            df.to_csv(csv_buffer, index=False)
            csv_content = csv_buffer.getvalue()
            
            return csv_content
            
        except Exception as e:
            logger.error(f"Error exporting audit logs to CSV: {e}")
            return None
    
    def generate_kyc_report_pdf(self, customer_id):
        """Generate PDF report for customer KYC"""
        try:
            report_data = self.get_customer_kyc_report(customer_id)
            
            if not report_data:
                return None
            
            # Create PDF buffer
            buffer = io.BytesIO()
            doc = SimpleDocTemplate(buffer, pagesize=A4)
            
            # Get styles
            styles = getSampleStyleSheet()
            title_style = styles['Title']
            heading_style = styles['Heading2']
            normal_style = styles['Normal']
            
            # Build content
            content = []
            
            # Title
            content.append(Paragraph("KYC Verification Report", title_style))
            content.append(Spacer(1, 20))
            
            # Customer Information
            content.append(Paragraph("Customer Information", heading_style))
            customer_info = report_data['customer_info']
            
            customer_table_data = [
                ['Customer ID:', customer_info['customer_id']],
                ['Name:', customer_info['name']],
                ['Email:', customer_info['email']],
                ['Phone:', customer_info['phone']],
                ['Registration Date:', customer_info['created_at']],
                ['Status:', customer_info['status']]
            ]
            
            customer_table = Table(customer_table_data, colWidths=[2*72, 4*72])
            customer_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), colors.grey),
                ('TEXTCOLOR', (0, 0), (0, -1), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
                ('BACKGROUND', (1, 0), (1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            content.append(customer_table)
            content.append(Spacer(1, 20))
            
            # KYC Status
            content.append(Paragraph("KYC Verification Status", heading_style))
            kyc_status = report_data['kyc_status']
            
            kyc_table_data = [
                ['Overall Status:', kyc_status['overall_status'].upper()],
                ['ID Proof:', kyc_status['id_proof_status'].title()],
                ['Address Proof:', kyc_status['address_proof_status'].title()],
                ['Photo ID:', kyc_status['photo_status'].title()],
                ['Verification Score:', f"{kyc_status['verification_score']}/100"],
                ['Completion:', f"{kyc_status['completion_percentage']}%"]
            ]
            
            kyc_table = Table(kyc_table_data, colWidths=[2*72, 4*72])
            kyc_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), colors.grey),
                ('TEXTCOLOR', (0, 0), (0, -1), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
                ('FONTSIZE', (0, 0), (-1, -1), 10),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
                ('BACKGROUND', (1, 0), (1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            content.append(kyc_table)
            content.append(Spacer(1, 20))
            
            # Documents
            if report_data['documents']:
                content.append(Paragraph("Uploaded Documents", heading_style))
                
                doc_table_data = [['Document Type', 'Status', 'Confidence', 'Upload Date']]
                
                for doc in report_data['documents']:
                    doc_table_data.append([
                        doc['document_type'].replace('_', ' ').title(),
                        doc['verification_status'].title(),
                        f"{doc['confidence_score']:.1f}%",
                        doc['uploaded_at']
                    ])
                
                doc_table = Table(doc_table_data, colWidths=[1.5*72, 1.5*72, 1.5*72, 1.5*72])
                doc_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, -1), 10),
                    ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                
                content.append(doc_table)
                content.append(Spacer(1, 20))
            
            # Footer
            content.append(Spacer(1, 30))
            content.append(Paragraph("Report generated on: " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"), normal_style))
            content.append(Paragraph("This report is for internal use and contains confidential information.", normal_style))
            
            # Build PDF
            doc.build(content)
            
            # Get PDF data
            buffer.seek(0)
            pdf_data = buffer.getvalue()
            buffer.close()
            
            return pdf_data
            
        except Exception as e:
            logger.error(f"Error generating PDF report: {e}")
            return None
    
    def get_compliance_report(self, date_from=None, date_to=None):
        """Generate compliance report for regulatory requirements"""
        try:
            stats = self.get_kyc_statistics(date_from, date_to)
            
            # Get recent activities for compliance
            audit_logs = self.get_audit_logs(
                date_from=date_from,
                date_to=date_to,
                limit=1000
            )
            
            # Categorize activities
            activities_by_type = {}
            for log in audit_logs:
                action = log['action']
                if action not in activities_by_type:
                    activities_by_type[action] = 0
                activities_by_type[action] += 1
            
            # Calculate compliance metrics
            total_customers = stats.get('total_customers', 0)
            completed_kyc = stats.get('status_breakdown', {}).get('completed', 0)
            
            compliance_rate = (completed_kyc / total_customers * 100) if total_customers > 0 else 0
            
            return {
                'period': {
                    'from': date_from,
                    'to': date_to
                },
                'statistics': stats,
                'activities_summary': activities_by_type,
                'compliance_metrics': {
                    'total_customers': total_customers,
                    'completed_kyc': completed_kyc,
                    'compliance_rate': round(compliance_rate, 2),
                    'pending_verification': stats.get('status_breakdown', {}).get('in_progress', 0),
                    'failed_verification': stats.get('status_breakdown', {}).get('incomplete', 0)
                },
                'generated_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error generating compliance report: {e}")
            return {}