import streamlit as st
st.title("KYC Upload Demo")
st.write("Backend connected successfully")