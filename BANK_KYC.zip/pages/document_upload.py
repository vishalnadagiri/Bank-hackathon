import streamlit as st
import os
import json
from PIL import Image
import io
from datetime import datetime
from services.enhanced_ml_extractor import EnhancedMLExtractor
from services.verification_service import VerificationService
from services.auth_service import OTPService
from config.database import DatabaseManager

def save_uploaded_file(uploaded_file, customer_id, document_type):
    """Save uploaded file to disk"""
    try:
        # Create uploads directory
        upload_dir = f"uploads/{customer_id}/{document_type}"
        os.makedirs(upload_dir, exist_ok=True)
        
        # Generate unique filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_extension = uploaded_file.name.split('.')[-1]
        filename = f"{document_type}_{timestamp}.{file_extension}"
        file_path = os.path.join(upload_dir, filename)
        
        # Save file
        with open(file_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        
        return file_path, filename
        
    except Exception as e:
        st.error(f"Error saving file: {e}")
        return None, None

def show_document_requirements(document_type):
    """Display document requirements and guidelines"""
    requirements = {
        'id_proof': {
            'title': '🆔 ID Proof Requirements',
            'accepted': ['Aadhaar Card', 'PAN Card', 'Passport', 'Driving License', 'Voter ID'],
            'guidelines': [
                '📸 Clear, well-lit photograph',
                '📄 All text should be readable',
                '🔍 No blur or shadows',
                '📐 Document should be flat and straight',
                '✅ All corners visible'
            ]
        },
        'address_proof': {
            'title': '🏠 Address Proof Requirements',
            'accepted': ['Utility Bill', 'Bank Statement', 'Rental Agreement', 'Aadhaar Card'],
            'guidelines': [
                '📅 Document should be recent (within 3 months)',
                '📸 Complete document visible',
                '📄 Name and address clearly readable',
                '🔍 High resolution image',
                '✅ Official letterhead/logo visible'
            ]
        },
        'photo': {
            'title': '📷 Photo ID Requirements',
            'accepted': ['Passport size photo', 'Recent photograph'],
            'guidelines': [
                '👤 Clear face visibility',
                '🌟 Good lighting',
                '📐 Straight pose, looking at camera',
                '🎯 Plain background preferred',
                '📅 Recent photo (within 6 months)'
            ]
        }
    }
    
    req = requirements.get(document_type, {})
    
    if req:
        with st.expander(f"{req['title']} - Click to view", expanded=True):
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**Accepted Documents:**")
                for doc in req['accepted']:
                    st.write(f"✅ {doc}")
            
            with col2:
                st.markdown("**Photo Guidelines:**")
                for guideline in req['guidelines']:
                    st.write(guideline)

def show_extraction_results(extracted_data, confidence_score, validation_result):
    """Display extracted data and validation results"""
    st.subheader("🤖 AI Extraction Results")
    
    # Confidence score
    confidence_color = "🟢" if confidence_score >= 80 else "🟡" if confidence_score >= 60 else "🔴"
    st.markdown(f"**Extraction Confidence:** {confidence_color} {confidence_score:.1f}%")
    
    # Progress bar for confidence
    st.progress(confidence_score / 100)
    
    if extracted_data:
        st.markdown("**📋 Extracted Information:**")
        
        # Display extracted data in a nice format
        for field, value in extracted_data.items():
            if value:
                field_display = field.replace('_', ' ').title()
                st.text_input(f"{field_display}", value=str(value), disabled=True, key=f"extracted_{field}")
    
    # Validation results
    if validation_result:
        st.markdown("**🔍 Document Validation:**")
        
        if validation_result['is_valid']:
            st.success("✅ Document format appears to be correct")
        else:
            st.warning("⚠️ Document validation issues detected:")
            for issue in validation_result['issues']:
                st.write(f"❌ {issue}")
            
            if validation_result['suggestions']:
                st.info("💡 Suggestions:")
                for suggestion in validation_result['suggestions']:
                    st.write(f"💡 {suggestion}")

def show_manual_entry_form(document_type, extracted_data=None):
    """Show manual entry form for verification"""
    st.subheader("✍️ Enter Your Information")
    st.write("Please enter your details to verify against the extracted information")
    
    user_data = {}
    
    if document_type == 'id_proof':
        col1, col2 = st.columns(2)
        with col1:
            user_data['name'] = st.text_input(
                "Full Name*", 
                value=extracted_data.get('name', '') if extracted_data else '',
                placeholder="Enter your full name as per ID"
            )
            user_data['id_number'] = st.text_input(
                "ID Number*",
                value=extracted_data.get('id_number', '') if extracted_data else '',
                placeholder="Enter ID number"
            )
        with col2:
            user_data['date_of_birth'] = st.text_input(
                "Date of Birth (DD-MM-YYYY)",
                value=extracted_data.get('date_of_birth', '') if extracted_data else '',
                placeholder="DD-MM-YYYY"
            )
            user_data['address'] = st.text_area(
                "Address",
                value=extracted_data.get('address', '') if extracted_data else '',
                placeholder="Enter your address"
            )
    
    elif document_type == 'address_proof':
        col1, col2 = st.columns(2)
        with col1:
            user_data['name'] = st.text_input(
                "Full Name*",
                value=extracted_data.get('name', '') if extracted_data else '',
                placeholder="Enter your full name"
            )
            user_data['address'] = st.text_area(
                "Complete Address*",
                value=extracted_data.get('address', '') if extracted_data else '',
                placeholder="Enter your complete address"
            )
        with col2:
            user_data['pincode'] = st.text_input(
                "PIN Code",
                value=extracted_data.get('pincode', '') if extracted_data else '',
                placeholder="Enter 6-digit PIN code"
            )
    
    return user_data

def perform_verification(extracted_data, user_data, document_type, customer_id):
    """Perform document verification"""
    verification_service = VerificationService()
    
    st.subheader("🔐 Document Verification")
    
    # Show comparison
    st.write("**📊 Data Comparison:**")
    
    comparison_data = []
    for field in user_data.keys():
        if field in extracted_data:
            comparison_data.append({
                'Field': field.replace('_', ' ').title(),
                'Extracted': extracted_data.get(field, 'Not found'),
                'Entered': user_data.get(field, 'Not provided')
            })
    
    if comparison_data:
        import pandas as pd
        df = pd.DataFrame(comparison_data)
        st.table(df)
    
    # Perform verification
    with st.spinner("🔍 Verifying document..."):
        verification_result = verification_service.verify_document_with_user_data(
            extracted_data, user_data, document_type
        )
    
    # Display results
    if verification_result['overall_match']:
        st.success(f"✅ Document verification successful! Confidence: {verification_result['confidence_score']:.1f}%")
        
        # Show field matches
        st.write("**✅ Field Verification Results:**")
        for field, result in verification_result['field_matches'].items():
            if result['is_match']:
                st.success(f"✅ {field.replace('_', ' ').title()}: Match ({result['score']:.1f}%)")
            else:
                st.error(f"❌ {field.replace('_', ' ').title()}: No match ({result['score']:.1f}%)")
    else:
        st.error(f"❌ Document verification failed. Confidence: {verification_result['confidence_score']:.1f}%")
        
        # Show issues
        if verification_result['issues']:
            st.write("**⚠️ Issues found:**")
            for issue in verification_result['issues']:
                st.error(f"❌ {issue}")
        
        # Show suggestions
        if verification_result['suggestions']:
            st.write("**💡 Suggestions:**")
            for suggestion in verification_result['suggestions']:
                st.info(f"💡 {suggestion}")
    
    return verification_result

def show_document_upload():
    """Main document upload page"""
    if not st.session_state.get('authenticated', False):
        st.error("❌ Please login to upload documents")
        return
    
    customer_data = st.session_state.get('customer_data', {})
    customer_id = customer_data.get('customer_id', '')
    
    st.title("📤 Document Upload & Verification")
    st.write("Upload your KYC documents for AI-powered verification")
    
    # Back button
    if st.button("← Back to Dashboard", key="back_to_dashboard_upload"):
        st.session_state.current_page = 'dashboard'
        st.rerun()
    
    # Document type selection
    st.subheader("1️⃣ Select Document Type")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🆔 ID Proof", type="secondary", use_container_width=True, key="select_id_proof"):
            st.session_state.selected_doc_type = 'id_proof'
    
    with col2:
        if st.button("🏠 Address Proof", type="secondary", use_container_width=True, key="select_address_proof"):
            st.session_state.selected_doc_type = 'address_proof'
    
    with col3:
        if st.button("📷 Photo ID", type="secondary", use_container_width=True, key="select_photo_id"):
            st.session_state.selected_doc_type = 'photo'
    
    # Show selected document type
    if 'selected_doc_type' in st.session_state:
        doc_type = st.session_state.selected_doc_type
        
        st.markdown("---")
        st.subheader(f"2️⃣ Upload {doc_type.replace('_', ' ').title()}")
        
        # Show requirements
        show_document_requirements(doc_type)
        
        # File upload
        uploaded_file = st.file_uploader(
            f"Choose {doc_type.replace('_', ' ')} file",
            type=['png', 'jpg', 'jpeg', 'pdf'],
            help="Supported formats: PNG, JPG, JPEG, PDF (Max size: 10MB)"
        )
        
        if uploaded_file is not None:
            # Display uploaded file
            st.success(f"✅ File uploaded: {uploaded_file.name}")
            
            # Show image preview
            if uploaded_file.type.startswith('image'):
                image = Image.open(uploaded_file)
                st.image(image, caption="Uploaded Document", width=400)
                
                # Process document
                if st.button("🤖 Process Document with AI", type="primary", key="process_ai"):
                    with st.spinner("🔄 Processing document with AI..."):
                        # Save file
                        file_path, filename = save_uploaded_file(uploaded_file, customer_id, doc_type)
                        
                        if file_path:
                            # Extract data
                            extractor = EnhancedMLExtractor()
                            extraction_result = extractor.extract_document_data(image, doc_type)
                            
                            if extraction_result['success']:
                                st.session_state.extraction_result = extraction_result
                                st.session_state.file_path = file_path
                                st.session_state.filename = filename
                                
                                # Show extraction results
                                show_extraction_results(
                                    extraction_result['extracted_data'],
                                    extraction_result['confidence_score'],
                                    extraction_result.get('validation', {})
                                )
                                
                                st.markdown("---")
                                
                                # Manual entry form
                                user_data = show_manual_entry_form(doc_type, extraction_result['extracted_data'])
                                
                                # Verification button
                                if st.button("🔐 Verify Document", type="primary", key="verify_document"):
                                    # Check if required fields are filled
                                    required_fields = ['name'] if doc_type == 'photo' else ['name', 'id_number' if doc_type == 'id_proof' else 'address']
                                    
                                    missing_fields = [field for field in required_fields if not user_data.get(field)]
                                    
                                    if missing_fields:
                                        st.error(f"❌ Please fill required fields: {', '.join(missing_fields)}")
                                    else:
                                        # Perform verification
                                        verification_result = perform_verification(
                                            extraction_result['extracted_data'],
                                            user_data,
                                            doc_type,
                                            customer_id
                                        )
                                        
                                        if verification_result['overall_match']:
                                            st.markdown("---")
                                            st.subheader("3️⃣ OTP Verification")
                                            
                                            # OTP verification
                                            from pages.authentication import show_otp_verification
                                            otp_verified = show_otp_verification(customer_id, "document_verification")
                                            
                                            if otp_verified or st.session_state.get('otp_verified', False):
                                                # Save to database
                                                db = DatabaseManager()
                                                
                                                doc_data = {
                                                    'customer_id': customer_id,
                                                    'document_type': doc_type,
                                                    'file_name': filename,
                                                    'file_path': file_path,
                                                    'extracted_data': json.dumps(extraction_result['extracted_data']),
                                                    'verification_status': 'verified',
                                                    'confidence_score': verification_result['confidence_score']
                                                }
                                                
                                                db.save_document(doc_data)
                                                
                                                # Update KYC status
                                                verification_service = VerificationService()
                                                verification_service.update_kyc_status(
                                                    customer_id, doc_type, verification_result, 
                                                    verification_result['confidence_score']
                                                )
                                                
                                                st.success("🎉 Document successfully verified and saved!")
                                                
                                                if st.button("📊 Go to Dashboard", key="goto_dashboard_success"):
                                                    # Clear session variables
                                                    for key in list(st.session_state.keys()):
                                                        if key.startswith(('selected_doc_type', 'extraction_result', 'otp_')):
                                                            del st.session_state[key]
                                                    
                                                    st.session_state.current_page = 'dashboard'
                                                    st.rerun()
                            else:
                                st.error(f"❌ {extraction_result['message']}")
                        else:
                            st.error("❌ Failed to save uploaded file")
            
            elif uploaded_file.type == 'application/pdf':
                st.info("📄 PDF document uploaded")
                st.warning("⚠️ PDF processing is not implemented in this demo. Please upload an image file.")
    
    else:
        st.info("👆 Please select a document type to continue")
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style='text-align: center; color: gray;'>
        🤖 AI-Powered Document Processing | 🔒 Secure Upload | 📱 OTP Verification
    </div>
    """, unsafe_allow_html=True)