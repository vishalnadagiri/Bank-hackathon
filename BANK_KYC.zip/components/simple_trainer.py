#!/usr/bin/env python3
"""
Simple but Effective Document Training System
Focus on reliability and results over complexity
"""

import streamlit as st
import cv2
import numpy as np
from PIL import Image
import pytesseract
import re
import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class SimpleTrainer:
    def __init__(self):
        self.training_data = {}
        
    def simple_training_interface(self, image, fields_to_extract, session_key="simple_train"):
        """
        Ultra-simple training interface that actually works
        """
        st.subheader("✨ Simple Document Training")
        st.markdown("**Step 1:** See what the system can extract")
        st.markdown("**Step 2:** Tell us what each piece of text actually means")
        
        # Initialize session state
        if f"{session_key}_extracted_text" not in st.session_state:
            st.session_state[f"{session_key}_extracted_text"] = None
        if f"{session_key}_training_data" not in st.session_state:
            st.session_state[f"{session_key}_training_data"] = {}
        
        col1, col2 = st.columns([1, 1])
        
        with col1:
            st.subheader("📄 Your Document")
            st.image(image, use_column_width=True)
            
            # Extract text button
            if st.button("🔍 Extract All Text", key=f"{session_key}_extract", type="primary"):
                with st.spinner("Extracting text..."):
                    extracted_text = self._extract_all_text_segments(image)
                    st.session_state[f"{session_key}_extracted_text"] = extracted_text
                    st.rerun()
        
        with col2:
            st.subheader("🎯 Text Found in Document")
            
            if st.session_state[f"{session_key}_extracted_text"]:
                text_segments = st.session_state[f"{session_key}_extracted_text"]
                
                st.success(f"✅ Found {len(text_segments)} text pieces")
                
                # Show each text segment with field assignment
                st.markdown("**👆 Click on what each text represents:**")
                
                training_data = {}
                
                for i, text_piece in enumerate(text_segments):
                    if len(text_piece.strip()) > 1:  # Only show meaningful text
                        
                        # Create a unique key for this text piece
                        text_key = f"text_{i}_{session_key}"
                        
                        # Show the text
                        st.markdown(f"**Text found:** `{text_piece}`")
                        
                        # Let user select what this text represents
                        field_options = ["Not a field"] + fields_to_extract
                        selected_field = st.selectbox(
                            "This text is:",
                            field_options,
                            key=text_key,
                            index=0
                        )
                        
                        if selected_field != "Not a field":
                            training_data[selected_field] = text_piece
                        
                        st.markdown("---")
                
                # Save training data
                if training_data:
                    st.session_state[f"{session_key}_training_data"] = training_data
                    
                    st.subheader("📝 Your Training Data")
                    for field, value in training_data.items():
                        st.write(f"**{field.title()}:** {value}")
                    
                    if st.button("💾 Save This Training", key=f"{session_key}_save", type="primary"):
                        return {
                            'success': True,
                            'training_data': training_data,
                            'method': 'simple_text_mapping'
                        }
            
            else:
                st.info("👆 Click 'Extract All Text' to start training")
        
        return None
    
    def _extract_all_text_segments(self, image):
        """
        Extract all meaningful text segments from the document
        """
        try:
            # Convert PIL to numpy if needed
            if isinstance(image, Image.Image):
                img_array = np.array(image)
            else:
                img_array = image
                image = Image.fromarray(img_array)
            
            # Try multiple OCR configurations to get all text
            all_text_pieces = []
            
            # Configuration 1: Word-level extraction
            try:
                data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
                
                for i, text in enumerate(data['text']):
                    if int(data['conf'][i]) > 30 and len(text.strip()) > 1:
                        clean_text = text.strip()
                        if clean_text and clean_text not in all_text_pieces:
                            all_text_pieces.append(clean_text)
            except:
                pass
            
            # Configuration 2: Line-level extraction
            try:
                line_text = pytesseract.image_to_string(image, config='--psm 6')
                lines = line_text.split('\n')
                
                for line in lines:
                    line = line.strip()
                    if len(line) > 1:
                        # Split line into words and phrases
                        words = line.split()
                        
                        # Add individual words
                        for word in words:
                            word = word.strip()
                            if len(word) > 1 and word not in all_text_pieces:
                                all_text_pieces.append(word)
                        
                        # Add full line if it has multiple words
                        if len(words) > 1 and line not in all_text_pieces:
                            all_text_pieces.append(line)
            except:
                pass
            
            # Configuration 3: Single word extraction
            try:
                word_text = pytesseract.image_to_string(image, config='--psm 8')
                if word_text.strip() and word_text.strip() not in all_text_pieces:
                    all_text_pieces.append(word_text.strip())
            except:
                pass
            
            # Clean and filter text pieces
            cleaned_pieces = []
            for text in all_text_pieces:
                # Remove special characters for filtering but keep original
                clean_for_filter = re.sub(r'[^\w\s]', '', text).strip()
                
                # Keep if it's meaningful
                if (len(clean_for_filter) >= 2 and 
                    not clean_for_filter.isdigit() or 
                    len(clean_for_filter) >= 4):  # Keep longer numbers
                    
                    if text not in cleaned_pieces:
                        cleaned_pieces.append(text)
            
            # Sort by length (longer texts first, might be more informative)
            cleaned_pieces.sort(key=len, reverse=True)
            
            # Limit to first 20 pieces to avoid overwhelming the user
            return cleaned_pieces[:20]
            
        except Exception as e:
            logger.error(f"Text extraction error: {e}")
            return []
    
    def smart_field_guesser(self, image, fields_to_extract):
        """
        Smart system that tries to guess which text belongs to which field
        """
        st.subheader("🧠 Smart Field Detector")
        st.markdown("Let the system try to automatically match text to fields")
        
        if st.button("🤖 Auto-Match Fields", type="primary"):
            with st.spinner("Analyzing document..."):
                
                # Extract text
                full_text = pytesseract.image_to_string(image)
                
                # Smart patterns for common fields
                smart_patterns = {
                    'name': [
                        r'(?:Name|NAME|नाम)[:\s]*([A-Za-z\s\.]{2,40})',
                        r'([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',  # Capitalized names
                    ],
                    'employee_id': [
                        r'(?:Employee|EMP|Staff)[:\s]*(?:ID|No|Number)[:\s]*([A-Z0-9]{3,15})',
                        r'(EMP[0-9]{3,10})',
                        r'([A-Z]{2,4}[0-9]{3,8})',
                    ],
                    'id_number': [
                        r'(?:ID|Card|Identity)[:\s]*(?:No|Number)[:\s]*([A-Z0-9]{6,20})',
                        r'([A-Z]{5}[0-9]{4}[A-Z])',  # PAN format
                        r'([0-9]{12})',  # Aadhaar format
                        r'([A-Z]{3}[0-9]{7})',  # Voter ID format
                    ],
                    'department': [
                        r'(?:Department|Dept|Division)[:\s]*([A-Za-z\s]{3,25})',
                        r'(ENGINEERING|MARKETING|FINANCE|HR|HUMAN\s+RESOURCES|SALES|IT|INFORMATION\s+TECHNOLOGY|OPERATIONS|ADMIN|ADMINISTRATION)',
                    ],
                    'designation': [
                        r'(?:Designation|Position|Title|Role)[:\s]*([A-Za-z\s]{3,30})',
                        r'(MANAGER|ENGINEER|ANALYST|EXECUTIVE|DIRECTOR|OFFICER|ASSISTANT|SUPERVISOR|LEAD|SENIOR|JUNIOR)',
                    ],
                    'date_of_birth': [
                        r'(?:DOB|Date of Birth|Birth Date|Born)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})',
                        r'([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})',
                    ],
                    'issue_date': [
                        r'(?:Issue|Issued|Date of Issue)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})',
                        r'(?:Valid from|From)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})',
                    ],
                    'expiry_date': [
                        r'(?:Expiry|Expires|Valid until|Valid till)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})',
                        r'(?:Until|Till)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})',
                    ],
                    'gender': [
                        r'(?:Gender|Sex)[:\s]*([MF]|Male|Female|पुरुष|महिला)',
                        r'(Male|Female|M|F)',
                    ],
                    'phone': [
                        r'(?:Phone|Mobile|Tel|Contact)[:\s]*([0-9\+\-\s]{10,15})',
                        r'([0-9]{10})',
                        r'(\+91[0-9]{10})',
                    ]
                }
                
                auto_matches = {}
                
                for field in fields_to_extract:
                    if field in smart_patterns:
                        for pattern in smart_patterns[field]:
                            try:
                                match = re.search(pattern, full_text, re.IGNORECASE | re.MULTILINE)
                                if match:
                                    matched_text = match.group(1) if len(match.groups()) > 0 else match.group(0)
                                    auto_matches[field] = matched_text.strip()
                                    break
                            except:
                                continue
                
                if auto_matches:
                    st.success(f"🎉 Auto-detected {len(auto_matches)} fields!")
                    
                    st.subheader("🎯 Auto-Detected Fields")
                    
                    # Let user review and modify auto-detected fields
                    final_data = {}
                    
                    for field, detected_value in auto_matches.items():
                        st.write(f"**{field.title()}:**")
                        
                        # Allow user to edit the detected value
                        corrected_value = st.text_input(
                            f"Detected: {detected_value}",
                            value=detected_value,
                            key=f"auto_{field}",
                            help=f"Edit if the detection is wrong"
                        )
                        
                        final_data[field] = corrected_value
                    
                    if st.button("✅ Accept Auto-Detection", type="primary"):
                        return {
                            'success': True,
                            'training_data': final_data,
                            'method': 'smart_auto_detection'
                        }
                
                else:
                    st.error("❌ Could not auto-detect any fields")
                    st.info("💡 Try the manual text mapping method above")
        
        return None

def simple_training_page():
    """
    Simple training page that focuses on getting results
    """
    st.title("✨ Simple Document Training")
    st.markdown("Train the system on your documents - the easy way!")
    
    # File upload
    uploaded_file = st.file_uploader(
        "📁 Upload a document to train on",
        type=['jpg', 'jpeg', 'png', 'bmp'],
        help="Upload a clear image of your document"
    )
    
    if uploaded_file:
        image = Image.open(uploaded_file)
        
        # Fields selection
        st.subheader("📋 What fields do you want to extract?")
        
        common_fields = st.multiselect(
            "Select fields to extract:",
            ["name", "employee_id", "id_number", "department", "designation", 
             "date_of_birth", "issue_date", "expiry_date", "gender", "phone", "email"],
            default=["name", "employee_id", "department"],
            help="Choose the fields you want the system to learn"
        )
        
        # Custom fields
        custom_fields_text = st.text_input(
            "Additional fields (comma-separated):",
            placeholder="badge_number, clearance_level, reporting_manager",
            help="Add any custom fields specific to your documents"
        )
        
        # Parse custom fields
        custom_fields = []
        if custom_fields_text:
            custom_fields = [field.strip() for field in custom_fields_text.split(',') if field.strip()]
        
        all_fields = common_fields + custom_fields
        
        if all_fields:
            st.success(f"🎯 Will train on: {', '.join(all_fields)}")
            
            trainer = SimpleTrainer()
            
            # Method selection
            training_method = st.radio(
                "Choose training method:",
                ["🧠 Smart Auto-Detection (Recommended)", "✨ Simple Text Mapping"],
                help="Auto-detection tries to find fields automatically. Text mapping lets you manually assign text to fields."
            )
            
            result = None
            
            if training_method == "🧠 Smart Auto-Detection (Recommended)":
                result = trainer.smart_field_guesser(image, all_fields)
            else:
                result = trainer.simple_training_interface(image, all_fields)
            
            # Process training result
            if result and result['success']:
                st.balloons()
                st.success("🎉 Training completed successfully!")
                
                st.subheader("📊 Training Summary")
                st.write(f"**Method:** {result['method']}")
                st.write(f"**Fields trained:** {len(result['training_data'])}")
                
                for field, value in result['training_data'].items():
                    st.write(f"- **{field}:** {value}")
                
                # Save option
                if st.button("💾 Save This Training Model", type="primary"):
                    # Here you would save the training data
                    st.success("✅ Training model saved! You can now use it to extract data from similar documents.")
        
        else:
            st.warning("⚠️ Please select at least one field to extract")

if __name__ == "__main__":
    simple_training_page()