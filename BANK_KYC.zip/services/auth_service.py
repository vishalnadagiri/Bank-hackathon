import bcrypt
import secrets
import uuid
from datetime import datetime, timedelta
import json
import logging
from config.database import DatabaseManager

logger = logging.getLogger(__name__)

class AuthService:
    def __init__(self):
        self.db = DatabaseManager()
    
    def generate_customer_id(self):
        """Generate unique customer ID"""
        return f"CUST_{uuid.uuid4().hex[:8].upper()}"
    
    def hash_password(self, password):
        """Hash password using bcrypt"""
        return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    def verify_password(self, password, hashed):
        """Verify password against hash"""
        return bcrypt.checkpw(password.encode('utf-8'), hashed.encode('utf-8'))
    
    def register_customer(self, name, email, phone, password):
        """Register new customer"""
        try:
            # Check if customer already exists
            existing_customer = self.db.get_customer(email=email)
            if existing_customer:
                return {"success": False, "message": "Customer already exists with this email"}
            
            # Create new customer
            customer_id = self.generate_customer_id()
            password_hash = self.hash_password(password)
            
            customer_data = {
                'customer_id': customer_id,
                'name': name,
                'email': email,
                'phone': phone,
                'password_hash': password_hash
            }
            
            self.db.create_customer(customer_data)
            
            # Log audit
            self.db.log_audit({
                'customer_id': customer_id,
                'action': 'CUSTOMER_REGISTERED',
                'details': f'Customer {name} registered with email {email}'
            })
            
            return {"success": True, "customer_id": customer_id, "message": "Registration successful"}
            
        except Exception as e:
            logger.error(f"Registration error: {e}")
            return {"success": False, "message": "Registration failed"}
    
    def authenticate_customer(self, email, password):
        """Authenticate customer login"""
        try:
            customer = self.db.get_customer(email=email)
            if not customer:
                return {"success": False, "message": "Invalid credentials"}
            
            if self.verify_password(password, customer[5]):  # password_hash is at index 5
                # Log audit
                self.db.log_audit({
                    'customer_id': customer[1],  # customer_id is at index 1
                    'action': 'LOGIN_SUCCESS',
                    'details': f'Customer {customer[2]} logged in'
                })
                
                return {
                    "success": True,
                    "customer_data": {
                        "customer_id": customer[1],
                        "name": customer[2],
                        "email": customer[3],
                        "phone": customer[4],
                        "status": customer[6]
                    }
                }
            else:
                # Log failed login
                self.db.log_audit({
                    'customer_id': customer[1],
                    'action': 'LOGIN_FAILED',
                    'details': 'Invalid password attempt'
                })
                return {"success": False, "message": "Invalid credentials"}
                
        except Exception as e:
            logger.error(f"Authentication error: {e}")
            return {"success": False, "message": "Authentication failed"}

class OTPService:
    def __init__(self):
        self.db = DatabaseManager()
    
    def generate_otp(self):
        """Generate 6-digit OTP"""
        return ''.join([str(secrets.randbelow(10)) for _ in range(6)])
    
    def send_otp(self, customer_id, purpose="verification"):
        """Generate and 'send' OTP (simulated)"""
        try:
            otp_code = self.generate_otp()
            expires_at = datetime.now() + timedelta(minutes=10)  # 10 minutes expiry
            
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                
                # Invalidate existing OTPs for this customer and purpose
                cursor.execute("""
                    UPDATE otp_records 
                    SET used = TRUE 
                    WHERE customer_id = ? AND purpose = ? AND used = FALSE
                """, (customer_id, purpose))
                
                # Insert new OTP
                cursor.execute("""
                    INSERT INTO otp_records (customer_id, otp_code, purpose, expires_at)
                    VALUES (?, ?, ?, ?)
                """, (customer_id, otp_code, purpose, expires_at))
                
                conn.commit()
            
            # Log audit
            self.db.log_audit({
                'customer_id': customer_id,
                'action': 'OTP_GENERATED',
                'details': f'OTP generated for {purpose}'
            })
            
            # In production, integrate with SMS/Email service
            # For demo, we'll return the OTP
            return {"success": True, "otp": otp_code, "message": "OTP sent successfully"}
            
        except Exception as e:
            logger.error(f"OTP generation error: {e}")
            return {"success": False, "message": "Failed to send OTP"}
    
    def verify_otp(self, customer_id, otp_code, purpose="verification"):
        """Verify OTP"""
        try:
            with self.db.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT * FROM otp_records 
                    WHERE customer_id = ? AND otp_code = ? AND purpose = ? 
                    AND used = FALSE AND expires_at > CURRENT_TIMESTAMP
                    ORDER BY created_at DESC LIMIT 1
                """, (customer_id, otp_code, purpose))
                
                otp_record = cursor.fetchone()
                
                if otp_record:
                    # Mark OTP as used
                    cursor.execute("""
                        UPDATE otp_records 
                        SET used = TRUE 
                        WHERE id = ?
                    """, (otp_record[0],))
                    
                    conn.commit()
                    
                    # Log audit
                    self.db.log_audit({
                        'customer_id': customer_id,
                        'action': 'OTP_VERIFIED',
                        'details': f'OTP verified for {purpose}'
                    })
                    
                    return {"success": True, "message": "OTP verified successfully"}
                else:
                    # Log failed verification
                    self.db.log_audit({
                        'customer_id': customer_id,
                        'action': 'OTP_FAILED',
                        'details': f'Invalid OTP attempt for {purpose}'
                    })
                    return {"success": False, "message": "Invalid or expired OTP"}
                    
        except Exception as e:
            logger.error(f"OTP verification error: {e}")
            return {"success": False, "message": "OTP verification failed"}