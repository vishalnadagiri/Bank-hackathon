#!/usr/bin/env python3
"""
Document Training Interface for Custom OCR Training
"""

import streamlit as st
import os
from PIL import Image
import json
from pathlib import Path
from services.document_trainer import DocumentTrainer
from services.document_extractor import DocumentExtractor
import logging

logger = logging.getLogger(__name__)

def document_training_page():
    """Main document training interface"""
    
    # Page config removed - handled by main app
    
    st.title("🧠 Custom Document Training System")
    st.markdown("Train the OCR system on your specific documents to extract custom fields")
    
    # Initialize trainer
    if 'trainer' not in st.session_state:
        st.session_state.trainer = DocumentTrainer()
    
    trainer = st.session_state.trainer
    
    # Sidebar for navigation
    st.sidebar.title("Training Options")
    training_mode = st.sidebar.selectbox(
        "Select Training Mode",
        ["🎯 New Training Session", "📊 Use Trained Models", "📈 Training Status", "🧪 Test Extraction"],
        key="training_mode"
    )
    
    if training_mode == "🎯 New Training Session":
        new_training_session(trainer)
    elif training_mode == "📊 Use Trained Models":
        use_trained_models(trainer)
    elif training_mode == "📈 Training Status":
        training_status(trainer)
    elif training_mode == "🧪 Test Extraction":
        test_extraction(trainer)

def new_training_session(trainer):
    """Create a new training session"""
    st.header("🎯 Start New Training Session")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📋 Document Configuration")
        
        # Document type name
        document_type = st.text_input(
            "Document Type Name",
            placeholder="e.g., employee_id, company_license, custom_certificate",
            help="Give a unique name to your document type",
            key="doc_type_name"
        )
        
        # Fields to extract
        st.markdown("**Fields to Extract:**")
        
        # Predefined common fields
        common_fields = st.multiselect(
            "Common Fields",
            ["name", "id_number", "employee_id", "date_of_birth", "department", 
             "designation", "phone", "email", "address", "issue_date", "expiry_date"],
            help="Select common fields that apply to your document",
            key="common_fields"
        )
        
        # Custom fields
        custom_fields_text = st.text_area(
            "Additional Custom Fields (one per line)",
            placeholder="badge_number\nreporting_manager\nclearance_level",
            help="Add any custom fields specific to your document type",
            key="custom_fields"
        )
        
        # Parse custom fields
        custom_fields = []
        if custom_fields_text:
            custom_fields = [field.strip() for field in custom_fields_text.split('\n') if field.strip()]
        
        all_fields = common_fields + custom_fields
        
        if st.button("🚀 Start Training Session", type="primary", disabled=not document_type or not all_fields, key="start_session"):
            session_id, session_info = trainer.start_training_session(document_type, all_fields)
            st.session_state.current_session = session_id
            st.session_state.session_fields = all_fields
            st.success(f"✅ Training session started: {session_id}")
            st.rerun()
    
    with col2:
        st.subheader("📝 Training Guidelines")
        st.info("""
        **How to Train Effectively:**
        
        1. **Use 3-5 sample documents** of the same type
        2. **Ensure good image quality** (clear, well-lit, straight)
        3. **Consistent document format** for best results
        4. **Label fields accurately** - the system learns from your labels
        5. **Include variations** if your documents have different layouts
        """)
        
        st.warning("""
        **Important Notes:**
        - Documents should be the same type (e.g., all employee IDs)
        - Make sure all required fields are visible in each document
        - Higher quality images = better training results
        """)
    
    # Training samples section
    if 'current_session' in st.session_state:
        add_training_samples(trainer)

def add_training_samples(trainer):
    """Interface for adding training samples"""
    st.header("📸 Add Training Documents")
    
    session_id = st.session_state.current_session
    fields = st.session_state.session_fields
    
    st.info(f"**Current Session:** {session_id}")
    st.info(f"**Fields to Extract:** {', '.join(fields)}")
    
    # File upload
    uploaded_file = st.file_uploader(
        "Upload Document Image",
        type=['jpg', 'jpeg', 'png', 'bmp'],
        help="Upload a clear image of your document",
        key=f"upload_{session_id}"
    )
    
    if uploaded_file:
        # Display uploaded image
        image = Image.open(uploaded_file)
        
        col1, col2 = st.columns([1, 1])
        
        with col1:
            st.subheader("📄 Uploaded Document")
            st.image(image, use_column_width=True)
            
            # Quick OCR preview
            if st.button("👁️ Preview OCR Text", key="preview_ocr"):
                with st.spinner("Extracting text..."):
                    extractor = DocumentExtractor()
                    preview_text = extractor.extract_text_from_image(image)
                    st.text_area("Extracted Text Preview", preview_text, height=150)
        
        with col2:
            st.subheader("🏷️ Field Labeling Method")
            
            labeling_method = st.radio(
                "Choose labeling method:",
                ["🎯 Interactive Annotation", "✍️ Manual Text Entry"],
                help="Interactive annotation provides better training data",
                key=f"labeling_method_{session_id}"
            )
            
            field_values = {}
            
            if labeling_method == "🎯 Interactive Annotation":
                # Choose annotation system
                annotation_system = st.radio(
                    "Select annotation method:",
                    ["🎯 Smart Annotator (Recommended)", "🖊️ Drawable Canvas (Experimental)"],
                    help="Smart Annotator works reliably and has multiple methods. Drawable Canvas may have compatibility issues.",
                    key=f"annotation_system_{session_id}"
                )
                
                if annotation_system == "🖊️ Drawable Canvas (Experimental)":
                    st.warning("⚠️ Drawable Canvas has compatibility issues with your Streamlit version. Using Smart Annotator instead.")
                    annotation_system = "🎯 Smart Annotator (Recommended)"
                
                annotation_result = None
                
                if annotation_system == "🎯 Smart Annotator (Recommended)":
                    from components.simple_annotator import SimpleAnnotator
                    
                    annotator = SimpleAnnotator()
                    annotation_result = annotator.annotate_document_simple(
                        image,
                        fields,
                        session_key=f"simple_{session_id}"
                    )
                
                else:  # Drawable Canvas
                    try:
                        from components.interactive_annotator import InteractiveAnnotator
                        
                        st.info("🖊️ **Drawable Canvas:** Draw rectangles directly on the document")
                        
                        annotator = InteractiveAnnotator()
                        annotation_result = annotator.annotate_document_interactive(
                            image, 
                            fields, 
                            session_key=f"drawable_{session_id}"
                        )
                        
                    except Exception as e:
                        st.error(f"Drawable Canvas error: {e}")
                        st.info("💡 Use Smart Annotator instead - it's more reliable!")
                        
                        # Fallback to simple annotator
                        from components.simple_annotator import SimpleAnnotator
                        annotator = SimpleAnnotator()
                        annotation_result = annotator.annotate_document_simple(
                            image,
                            fields,
                            session_key=f"fallback_{session_id}"
                        )
                
                if annotation_result and annotation_result['success']:
                    st.success(f"✅ Annotated {annotation_result['annotation_count']} fields!")
                    
                    # Convert annotation data to field_values format
                    for field_name, field_data in annotation_result['training_data'].items():
                        field_values[field_name] = {
                            'value': field_data['value'],
                            'coordinates': field_data['coordinates'],
                            'confidence': field_data['confidence']
                        }
                    
                    # Show extracted values
                    st.subheader("📝 Annotated Field Values")
                    for field_name, field_data in field_values.items():
                        st.write(f"**{field_name.title()}:** {field_data['value']}")
            
            else:  # Manual text entry
                st.markdown("Enter the actual values as they appear in the document:")
                
                # Create input fields for each field
                for field in fields:
                    field_value = st.text_input(
                        f"{field.replace('_', ' ').title()}:",
                        key=f"field_{field}_{session_id}",
                        help=f"Enter the {field} as it appears in the document"
                    )
                    if field_value:
                        field_values[field] = field_value
            
            # Save training sample
            col_save, col_finish = st.columns(2)
            
            with col_save:
                if st.button("💾 Add This Sample", type="primary", 
                           disabled=len(field_values) < len(fields), key="add_sample"):
                    # Save uploaded file
                    upload_dir = Path("uploads/training")
                    upload_dir.mkdir(parents=True, exist_ok=True)
                    
                    file_path = upload_dir / f"{session_id}_{uploaded_file.name}"
                    with open(file_path, "wb") as f:
                        f.write(uploaded_file.getbuffer())
                    
                    # Add to training
                    success = trainer.add_training_document(session_id, file_path, field_values)
                    
                    if success:
                        st.success("✅ Training sample added successfully!")
                        # Count existing samples
                        session_dir = Path("data/training") / session_id
                        sample_count = len(list(session_dir.glob("sample_*.json"))) if session_dir.exists() else 0
                        st.info(f"Total samples in session: {sample_count}")
                    else:
                        st.error("❌ Failed to add training sample")
            
            with col_finish:
                if st.button("🎓 Finish Training", type="secondary", key="finish_training"):
                    with st.spinner("Learning patterns from samples..."):
                        result = trainer.learn_patterns_from_samples(session_id)
                        
                        if result['success']:
                            st.success("🎉 Training completed successfully!")
                            st.balloons()
                            
                            # Show learned patterns
                            st.subheader("📚 Learned Patterns")
                            for field, patterns in result['learned_patterns'].items():
                                with st.expander(f"Patterns for {field}"):
                                    st.write(f"**Regex Patterns:** {patterns['regex_patterns']}")
                                    st.write(f"**Context Patterns:** {patterns['context_patterns'][:3]}")  # Show first 3
                            
                            # Clear session
                            if 'current_session' in st.session_state:
                                del st.session_state.current_session
                            if 'session_fields' in st.session_state:
                                del st.session_state.session_fields
                                
                        else:
                            st.error(f"❌ Training failed: {result['message']}")

def use_trained_models(trainer):
    """Interface for using trained models"""
    st.header("📊 Use Trained Models")
    
    # Get available document types
    status = trainer.get_training_status()
    available_types = status['available_document_types']
    
    if not available_types:
        st.warning("No trained document types available. Please train a model first.")
        return
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("📄 Upload Document for Extraction")
        
        selected_type = st.selectbox(
            "Select Document Type",
            available_types,
            help="Choose the document type that matches your uploaded document",
            key="selected_doc_type"
        )
        
        uploaded_file = st.file_uploader(
            "Upload Document",
            type=['jpg', 'jpeg', 'png', 'bmp'],
            key="extract_upload"
        )
        
        if uploaded_file and selected_type:
            image = Image.open(uploaded_file)
            st.image(image, use_column_width=True)
            
            if st.button("🔍 Extract Data", type="primary", key="extract_data"):
                with st.spinner("Extracting data using enhanced patterns..."):
                    result = trainer.extract_using_custom_patterns(image, selected_type)
                    
                    with col2:
                        st.subheader("📋 Extraction Results")
                        
                        if result['success']:
                            st.success(f"✅ Extraction successful! Confidence: {result['confidence_score']:.1f}%")
                            
                            # Display extracted data
                            st.subheader("📝 Extracted Fields")
                            for field, value in result['extracted_data'].items():
                                confidence = result['field_scores'].get(field, 0) * 100
                                st.write(f"**{field.replace('_', ' ').title()}:** {value}")
                                st.progress(confidence / 100, f"Confidence: {confidence:.0f}%")
                            
                            # Export options
                            st.subheader("💾 Export Data")
                            export_format = st.radio("Export Format", ["JSON", "CSV"], key="export_format")
                            
                            if export_format == "JSON":
                                json_data = json.dumps(result['extracted_data'], indent=2)
                                st.download_button(
                                    "📥 Download JSON",
                                    json_data,
                                    f"extracted_data_{selected_type}.json",
                                    "application/json"
                                )
                            else:
                                # CSV format
                                csv_data = "\n".join([f"{k},{v}" for k, v in result['extracted_data'].items()])
                                st.download_button(
                                    "📥 Download CSV",
                                    csv_data,
                                    f"extracted_data_{selected_type}.csv",
                                    "text/csv"
                                )
                        else:
                            st.error(f"❌ Extraction failed: {result['message']}")

def training_status(trainer):
    """Show training status and management"""
    st.header("📈 Training Status & Management")
    
    status = trainer.get_training_status()
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Statistics")
        st.metric("Trained Document Types", status['total_trained_types'])
        
        if status['available_document_types']:
            st.subheader("📋 Available Document Types")
            for doc_type in status['available_document_types']:
                st.write(f"• **{doc_type}**")
    
    with col2:
        st.subheader("📝 Recent Training History")
        if status['training_history']:
            for session in status['training_history']:
                with st.expander(f"Session: {session['session_id'][:20]}..."):
                    st.write(f"**Document Type:** {session['document_type']}")
                    st.write(f"**Samples:** {session['samples_count']}")
                    st.write(f"**Trained:** {session['learned_at']}")
        else:
            st.info("No training history available")

def test_extraction(trainer):
    """Test extraction capabilities"""
    st.header("🧪 Test Extraction")
    st.markdown("Upload any document to test both standard and custom extraction")
    
    uploaded_file = st.file_uploader("Upload Test Document", type=['jpg', 'jpeg', 'png', 'bmp'], key="test_upload")
    
    if uploaded_file:
        image = Image.open(uploaded_file)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📄 Test Document")
            st.image(image, use_column_width=True)
        
        with col2:
            st.subheader("🔍 Extraction Results")
            
            # Test standard extraction
            if st.button("🔍 Standard ID Extraction", key="test_standard"):
                extractor = DocumentExtractor()
                result = extractor.extract_document_data(image, 'id_proof')
                
                st.write("**Standard Extraction:**")
                if result['success']:
                    for field, value in result['extracted_data'].items():
                        st.write(f"• {field}: {value}")
                else:
                    st.write("No data extracted with standard patterns")
            
            # Test custom extraction
            status = trainer.get_training_status()
            if status['available_document_types']:
                selected_custom = st.selectbox("Test Custom Extraction", status['available_document_types'], key="test_custom_select")
                
                if st.button("🎯 Enhanced Extraction", key="test_custom"):
                    result = trainer.extract_using_custom_patterns(image, selected_custom)
                    
                    st.write("**Enhanced Extraction:**")
                    if result['success']:
                        st.success(f"✅ Extraction successful! Confidence: {result['confidence_score']:.1f}%")
                        for field, value in result['extracted_data'].items():
                            confidence = result['field_scores'].get(field, 0) * 100
                            st.write(f"• **{field}**: {value} (confidence: {confidence:.0f}%)")
                        
                        # Show extraction method used
                        method = result.get('extraction_method', 'custom_trained')
                        if method == 'enhanced_patterns':
                            st.info("🔧 Used enhanced fallback patterns (same as debugger)")
                        else:
                            st.info("🎯 Used trained custom patterns")
                    else:
                        st.error(f"❌ {result.get('message', 'No data extracted')}")

if __name__ == "__main__":
    document_training_page()