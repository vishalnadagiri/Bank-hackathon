
from database.db import get_connection

def is_kyc_done(registered_no):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT kyc_done FROM customers WHERE registered_no=?", (registered_no,))
    res = cursor.fetchone()
    conn.close()
    return res and res[0] == 1

def update_kyc(registered_no, doc_path):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE customers SET kyc_done=1, kyc_doc_path=? WHERE registered_no=?", (doc_path, registered_no))
    conn.commit()
    conn.close()
