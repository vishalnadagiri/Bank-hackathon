
import streamlit as st
from services.registration_service import register_user

def register_tab():
    st.subheader("New User Registration")

    data = {
        "first_name": st.text_input("First Name"),
        "last_name": st.text_input("Last Name"),
        "mobile": st.text_input("Mobile Number"),
        "aadhaar": st.text_input("Aadhaar Number"),
        "dob": st.date_input("Date of Birth")
    }

    if st.button("Register"):
        success, result = register_user(data)
        if success:
            st.success(f"Registered Successfully! Your ID: {result}")
        else:
            st.warning(f"Already registered. Your ID: {result}")
