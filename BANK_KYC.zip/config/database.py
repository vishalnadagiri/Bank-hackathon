import sqlite3
import os
from datetime import datetime
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self, db_path="data/kyc_bank.db"):
        self.db_path = db_path
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.init_database()
    
    def get_connection(self):
        """Get database connection"""
        return sqlite3.connect(self.db_path)
    
    def init_database(self):
        """Initialize database tables"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Customer table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS customers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customer_id TEXT UNIQUE NOT NULL,
                    name TEXT NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    phone TEXT NOT NULL,
                    password_hash TEXT NOT NULL,
                    status TEXT DEFAULT 'pending',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Documents table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS documents (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customer_id TEXT NOT NULL,
                    document_type TEXT NOT NULL,
                    file_name TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    extracted_data TEXT,
                    verification_status TEXT DEFAULT 'pending',
                    confidence_score REAL DEFAULT 0.0,
                    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    verified_at TIMESTAMP,
                    FOREIGN KEY (customer_id) REFERENCES customers (customer_id)
                )
            """)
            
            # OTP table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS otp_records (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customer_id TEXT NOT NULL,
                    otp_code TEXT NOT NULL,
                    purpose TEXT NOT NULL,
                    expires_at TIMESTAMP NOT NULL,
                    used BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (customer_id) REFERENCES customers (customer_id)
                )
            """)
            
            # Audit log table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS audit_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customer_id TEXT,
                    action TEXT NOT NULL,
                    details TEXT,
                    ip_address TEXT,
                    user_agent TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # KYC status table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS kyc_status (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customer_id TEXT UNIQUE NOT NULL,
                    overall_status TEXT DEFAULT 'incomplete',
                    id_proof_status TEXT DEFAULT 'pending',
                    address_proof_status TEXT DEFAULT 'pending',
                    photo_status TEXT DEFAULT 'pending',
                    verification_score REAL DEFAULT 0.0,
                    completion_percentage REAL DEFAULT 0.0,
                    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (customer_id) REFERENCES customers (customer_id)
                )
            """)

            # Aadhaar KYC table (Aadhaar-only phase)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS aadhaar_kyc (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    customer_id TEXT NOT NULL,
                    file_path TEXT NOT NULL,
                    extracted_json TEXT,
                    extracted_raw_text TEXT,
                    extracted_confidence REAL DEFAULT 0.0,
                    entered_json TEXT,
                    match_json TEXT,
                    verified BOOLEAN DEFAULT FALSE,
                    verified_at TIMESTAMP,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (customer_id) REFERENCES customers (customer_id)
                )
            """)
            
            conn.commit()
            logger.info("Database initialized successfully")
    
    def create_customer(self, customer_data):
        """Create new customer"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO customers (customer_id, name, email, phone, password_hash)
                VALUES (?, ?, ?, ?, ?)
            """, (customer_data['customer_id'], customer_data['name'], 
                  customer_data['email'], customer_data['phone'], customer_data['password_hash']))
            
            # Initialize KYC status
            cursor.execute("""
                INSERT INTO kyc_status (customer_id)
                VALUES (?)
            """, (customer_data['customer_id'],))
            
            conn.commit()
            return cursor.lastrowid
    
    def get_customer(self, email=None, customer_id=None):
        """Get customer by email or customer_id"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            if email:
                cursor.execute("SELECT * FROM customers WHERE email = ?", (email,))
            elif customer_id:
                cursor.execute("SELECT * FROM customers WHERE customer_id = ?", (customer_id,))
            else:
                return None
            return cursor.fetchone()
    
    def save_document(self, doc_data):
        """Save document information"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO documents (customer_id, document_type, file_name, file_path, 
                                     extracted_data, verification_status, confidence_score)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (doc_data['customer_id'], doc_data['document_type'], doc_data['file_name'],
                  doc_data['file_path'], doc_data['extracted_data'], 
                  doc_data['verification_status'], doc_data['confidence_score']))
            conn.commit()
            return cursor.lastrowid

    # Aadhaar KYC helpers
    def save_aadhaar_kyc_attempt(self, *, customer_id: str, file_path: str,
                                extracted_json: str, extracted_raw_text: str,
                                extracted_confidence: float,
                                entered_json: str = None, match_json: str = None,
                                verified: bool = False, verified_at: str = None) -> int:
        """Save an Aadhaar KYC attempt (extraction + optional verification)."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO aadhaar_kyc (
                    customer_id, file_path, extracted_json, extracted_raw_text,
                    extracted_confidence, entered_json, match_json, verified, verified_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    customer_id, file_path, extracted_json, extracted_raw_text,
                    extracted_confidence, entered_json, match_json,
                    1 if verified else 0, verified_at
                )
            )
            conn.commit()
            return cursor.lastrowid

    def get_latest_verified_aadhaar(self, customer_id: str):
        """Get latest verified Aadhaar KYC record."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT id, customer_id, file_path, extracted_json, extracted_confidence,
                       entered_json, match_json, verified, verified_at, created_at
                FROM aadhaar_kyc
                WHERE customer_id = ? AND verified = 1
                ORDER BY verified_at DESC, created_at DESC
                LIMIT 1
                """,
                (customer_id,)
            )
            return cursor.fetchone()

    def get_aadhaar_history(self, customer_id: str, limit: int = 10):
        """Get recent Aadhaar KYC attempts."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT id, file_path, extracted_confidence, verified, verified_at, created_at
                FROM aadhaar_kyc
                WHERE customer_id = ?
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (customer_id, limit)
            )
            return cursor.fetchall()
    
    def log_audit(self, audit_data):
        """Log audit trail"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO audit_logs (customer_id, action, details, ip_address, user_agent)
                VALUES (?, ?, ?, ?, ?)
            """, (audit_data['customer_id'], audit_data['action'], 
                  audit_data['details'], audit_data.get('ip_address'), 
                  audit_data.get('user_agent')))
            conn.commit()