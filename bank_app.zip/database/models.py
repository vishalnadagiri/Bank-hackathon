
from database.db import get_connection

def create_tables():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        registered_no TEXT UNIQUE,
        first_name TEXT,
        last_name TEXT,
        mobile TEXT,
        aadhaar TEXT,
        dob TEXT,
        kyc_done INTEGER DEFAULT 0,
        kyc_doc_path TEXT,
        account_no TEXT,
        ifsc_code TEXT,
        csn_no TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    conn.commit()
    conn.close()
