import streamlit as st
import os
import sys
from datetime import datetime
import logging

# Add project root to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import pages and services
from pages.authentication import show_authentication_page
from pages.dashboard import show_dashboard
from pages.document_upload import show_document_upload
from pages.reports import show_reports_page
from config.database import DatabaseManager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Page configuration - Always show sidebar
st.set_page_config(
    page_title="Banking KYC Portal",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better UI
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #1f4e79, #2c5f8a);
        color: white;
        padding: 1rem;
        border-radius: 10px;
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .success-box {
        background-color: #d4edda;
        border: 1px solid #c3e6cb;
        color: #155724;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
    }
    
    .warning-box {
        background-color: #fff3cd;
        border: 1px solid #ffeaa7;
        color: #856404;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
    }
    
    .error-box {
        background-color: #f8d7da;
        border: 1px solid #f5c6cb;
        color: #721c24;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
    }
    
    .info-box {
        background-color: #d1ecf1;
        border: 1px solid #bee5eb;
        color: #0c5460;
        padding: 1rem;
        border-radius: 8px;
        margin: 1rem 0;
    }
    
    .sidebar-content {
        background-color: #f8f9fa;
        padding: 1rem;
        border-radius: 8px;
        margin-bottom: 1rem;
    }
    
    .metric-card {
        background: white;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        margin: 0.5rem 0;
        text-align: center;
    }
    
    .footer {
        text-align: center;
        color: #6c757d;
        padding: 2rem 0;
        border-top: 1px solid #dee2e6;
        margin-top: 3rem;
    }
    
    /* Hide Streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    
    /* Always show sidebar - force visibility */
    .css-1d391kg {
        width: 300px !important;
        display: block !important;
        visibility: visible !important;
    }
    
    /* Hide ALL sidebar toggle/collapse elements */
    .css-1y4p8pa {
        display: none !important;
    }
    
    [data-testid="collapsedControl"] {
        display: none !important;
    }
    
    /* Hide the default Streamlit sidebar toggle */
    button[kind="header"] {
        display: none !important;
    }
    
    /* Hide sidebar toggle in header */
    .css-14xtw13.e8zbici0 {
        display: none !important;
    }
    
    /* Force hide any toggle buttons */
    [aria-label*="Close sidebar"], [aria-label*="Open sidebar"] {
        display: none !important;
    }
    
    /* Enhanced navigation buttons */
    .stButton > button {
        width: 100%;
        border-radius: 8px;
        border: 2px solid #1f4e79;
        padding: 0.75rem 1rem;
        margin: 0.5rem 0;
        background: linear-gradient(135deg, #1f4e79 0%, #2c5f8a 100%);
        color: white !important;
        font-weight: 600;
        font-size: 1rem;
        box-shadow: 0 2px 4px rgba(31, 78, 121, 0.3);
        transition: all 0.3s ease;
    }
    
    .stButton > button:hover {
        background: linear-gradient(135deg, #2c5f8a 0%, #1f4e79 100%);
        border-color: #2c5f8a;
        color: white !important;
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(31, 78, 121, 0.4);
    }
    
    .stButton > button:active {
        background: #1a3d5c;
        color: white !important;
        transform: translateY(0px);
        box-shadow: 0 2px 4px rgba(31, 78, 121, 0.5);
    }
    
    /* Primary buttons special styling */
    .stButton > button[kind="primary"] {
        background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
        border-color: #28a745;
        color: white !important;
    }
    
    .stButton > button[kind="primary"]:hover {
        background: linear-gradient(135deg, #20c997 0%, #28a745 100%);
        color: white !important;
    }
    
    /* Secondary buttons */
    .stButton > button[kind="secondary"] {
        background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
        border-color: #6c757d;
        color: white !important;
    }
    
    .stButton > button[kind="secondary"]:hover {
        background: linear-gradient(135deg, #495057 0%, #6c757d 100%);
        color: white !important;
    }
</style>
""", unsafe_allow_html=True)

def initialize_session_state():
    """Initialize session state variables"""
    if 'authenticated' not in st.session_state:
        st.session_state.authenticated = False
    
    if 'current_page' not in st.session_state:
        st.session_state.current_page = 'auth'
    
    if 'customer_data' not in st.session_state:
        st.session_state.customer_data = {}
    

def show_sidebar():
    """Display sidebar navigation"""
    with st.sidebar:
        st.markdown("""
        <div class='sidebar-content'>
            <h2 style='color: #1f4e79; text-align: center;'>🏦 Banking KYC</h2>
            <p style='text-align: center; color: #666;'>Secure Document Verification</p>
        </div>
        """, unsafe_allow_html=True)
        
        if st.session_state.get('authenticated', False):
            customer_data = st.session_state.get('customer_data', {})
            
            # User info
            st.markdown("### 👤 Customer Info")
            st.write(f"**Name:** {customer_data.get('name', 'N/A')}")
            st.write(f"**ID:** {customer_data.get('customer_id', 'N/A')}")
            st.write(f"**Status:** {customer_data.get('status', 'N/A').title()}")
            
            st.markdown("---")
            
            # Navigation - User pages
            st.markdown("### 🧭 Navigation")
            
            # User-accessible pages only
            user_pages = {
                'dashboard': '🏠 Dashboard',
                'upload': '📤 Upload Documents', 
                'reports': '📊 My Reports'
            }
            
            for page_key, page_name in user_pages.items():
                if st.button(page_name, key=f"nav_{page_key}", use_container_width=True):
                    st.session_state.current_page = page_key
                    st.rerun()
            
            # Admin-only section (hidden unless admin)
            if st.session_state.get('is_admin', False):
                st.markdown("---")
                st.markdown("### 👑 Admin Tools")
                
                admin_pages = {
                    'admin': '👑 Admin Panel',
                    'admin': '👑 Admin Panel'
                }
                
                for page_key, page_name in admin_pages.items():
                    if st.button(page_name, key=f"admin_{page_key}", use_container_width=True):
                        st.session_state.current_page = page_key
                        st.rerun()
            else:
                # Show admin access button for non-admin users
                st.markdown("---")
                if st.button("🔑 Admin Access", use_container_width=True, key="request_admin"):
                    st.warning("🔒 Admin access required. Please contact your administrator.")
            
            
            st.markdown("---")
            
            # Quick actions
            st.markdown("### ⚡ Quick Actions")
            
            if st.button("🔄 Refresh Status", use_container_width=True, key="refresh_status"):
                st.rerun()
            
            # Admin toggle (for demo purposes - in production this would be based on user roles)
            if st.button("🔑 Toggle Admin Mode", use_container_width=True, key="toggle_admin", help="Demo: Toggle admin access"):
                st.session_state.is_admin = not st.session_state.get('is_admin', False)
                st.success(f"Admin mode: {'Enabled' if st.session_state.is_admin else 'Disabled'}")
                st.rerun()
            
            if st.button("🚪 Logout", use_container_width=True, type="secondary", key="logout_main"):
                # Clear session
                for key in list(st.session_state.keys()):
                    if key.startswith(('authenticated', 'customer_data', 'current_page', 'is_admin')):
                        del st.session_state[key]
                st.rerun()
            
            st.markdown("---")
            
            # Help section
            with st.expander("❓ Need Help?", expanded=False):
                st.markdown("""
                **📞 Support Hotline:**
                1800-XXX-XXXX (24/7)
                
                **📧 Email Support:**
                kyc-support@bank.com
                
                **💬 Live Chat:**
                Available 9 AM - 6 PM
                
                **📚 Documentation:**
                Visit our help center
                """)
        
        else:
            # Guest user sidebar
            st.markdown("### 🔐 Authentication Required")
            st.info("Please login or register to access the KYC portal")
            
            st.markdown("---")
            
            # Features preview
            st.markdown("### ✨ Features")
            st.markdown("""
            🤖 **AI-Powered OCR**
            Automatic data extraction from documents
            
            🔒 **Secure Verification**
            Multi-step OTP authentication
            
            📊 **Real-time Tracking**
            Live status updates and progress
            
            📋 **Compliance Ready**
            Regulatory compliant audit trails
            
            📱 **Mobile Friendly**
            Works on all devices
            """)
        
        st.markdown("---")
        
        # System info
        st.markdown("### ℹ️ System Info")
        st.caption(f"Version: 1.0.0")
        st.caption(f"Last Updated: {datetime.now().strftime('%Y-%m-%d')}")
        st.caption("🔒 Bank-grade Security")



def show_header():
    """Display clean page header without toggle buttons"""
    current_page = st.session_state.get('current_page', 'auth')
    
    page_info = {
        'auth': {'title': 'Authentication', 'icon': '🔐', 'desc': 'Login or register for KYC verification'},
        'dashboard': {'title': 'Dashboard', 'icon': '🏠', 'desc': 'Your KYC verification overview'},
        'upload': {'title': 'Document Upload', 'icon': '📤', 'desc': 'Upload and verify your documents'},
        'admin': {'title': 'Admin Panel', 'icon': '👑', 'desc': 'Administrative controls and settings'},
        'reports': {'title': 'Reports & Analytics', 'icon': '📊', 'desc': 'View your verification reports'},
        'training': {'title': 'Document Training', 'icon': '🎯', 'desc': 'Train ML models with document samples'},
        'ml_extractor': {'title': 'ML Extractor', 'icon': '🤖', 'desc': 'Advanced ML-powered document extraction'},
        'hybrid_ai': {'title': 'Hybrid AI Demo', 'icon': '🧠', 'desc': 'CNN + Transformer + LLM demonstration'},
        'debugger': {'title': 'OCR Debugger', 'icon': '🔧', 'desc': 'Debug and test OCR extraction'}
    }
    
    info = page_info.get(current_page, {'title': 'Banking KYC', 'icon': '🏦', 'desc': 'Secure document verification'})
    
    # Clean header with status
    col_header, col_status = st.columns([4, 1])
    
    with col_header:
        st.markdown(f"""
        <div class='main-header'>
            <h1>{info['icon']} {info['title']}</h1>
            <p>{info['desc']}</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col_status:
        # Status indicator
        if st.session_state.get('authenticated', False):
            st.success("✅ Authenticated")
        else:
            st.info("❌ Guest")

def route_pages():
    """Route to appropriate page based on session state with admin access control"""
    current_page = st.session_state.get('current_page', 'auth')
    is_admin = st.session_state.get('is_admin', False)
    
    # Route to pages
    if current_page == 'auth' or not st.session_state.get('authenticated', False):
        show_authentication_page()
    elif current_page == 'dashboard':
        show_dashboard()
    elif current_page == 'upload':
        from pages.user_document_upload import user_document_upload_page
        user_document_upload_page()
    elif current_page == 'reports':
        show_reports_page()
    # Admin-only pages
    elif current_page == 'admin':
        if is_admin:
            from pages.admin_panel import admin_panel
            admin_panel()
        else:
            st.error("🔒 Access Denied: Admin privileges required")
            st.info("Please contact your administrator for access to this section.")
    # Admin-only tools removed for Aadhaar-only KYC phase
    # (Training/Debugger/ML Extractor can be re-enabled later)
    else:
        st.error("🔍 Page not found")
        if st.button("🏠 Go to Dashboard", key="goto_dashboard_main"):
            st.session_state.current_page = 'dashboard'
            st.rerun()

def show_footer():
    """Display footer"""
    st.markdown("""
    <div class='footer'>
        <hr>
        <h4>🏦 Banking KYC Portal</h4>
        <p>
            🔒 Secure • 🤖 AI-Powered • 📋 Compliant • 🌐 24/7 Available
        </p>
        <p style='font-size: 0.8em; color: #999;'>
            © 2024 Banking KYC Portal. All rights reserved. | 
            <a href='#' style='color: #007bff;'>Privacy Policy</a> | 
            <a href='#' style='color: #007bff;'>Terms of Service</a> | 
            <a href='#' style='color: #007bff;'>Contact Support</a>
        </p>
        <p style='font-size: 0.7em; color: #ccc;'>
            This is a demo application for KYC document verification using Streamlit and AI/ML technologies.
        </p>
    </div>
    """, unsafe_allow_html=True)

def initialize_database():
    """Initialize database on startup"""
    try:
        db = DatabaseManager()
        # st.success("✅ Database initialized successfully", icon="🗄️")
        return True
    except Exception as e:
        st.error(f"❌ Database initialization failed: {e}")
        st.error("Please check your database configuration and try again.")
        return False

def main():
    """Main application function"""
    try:
        # Initialize session state
        initialize_session_state()
        
        # Initialize database
        if not initialize_database():
            st.stop()
        
        
        # Show sidebar
        show_sidebar()
        
        # Show header
        show_header()
        
        # Route to appropriate page
        route_pages()
        
        # Show footer
        show_footer()
        
    except Exception as e:
        st.error(f"❌ Application error: {e}")
        st.error("Please refresh the page or contact support if the issue persists.")
        
        # Show error details in debug mode
        if st.checkbox("Show error details"):
            st.exception(e)

if __name__ == "__main__":
    main()