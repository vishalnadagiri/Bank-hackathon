
from database.db import get_connection
from utils.id_generator import generate_account_no, generate_ifsc, generate_csn

def open_account(registered_no):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT kyc_done, account_no FROM customers WHERE registered_no=?", (registered_no,))
    kyc_done, acc = cursor.fetchone()

    if not kyc_done:
        return False, "KYC_NOT_DONE"
    if acc:
        return False, "ACCOUNT_EXISTS"

    acc_no = generate_account_no()
    cursor.execute(
        "UPDATE customers SET account_no=?, ifsc_code=?, csn_no=? WHERE registered_no=?",
        (acc_no, generate_ifsc(), generate_csn(), registered_no)
    )
    conn.commit()
    conn.close()
    return True, acc_no
