import cv2
import numpy as np
from PIL import Image
import pytesseract
import re
import json
import logging
from datetime import datetime
import os
import platform

# Configure Tesseract path for Windows
if platform.system() == 'Windows':
    # Common Tesseract installation paths on Windows
    tesseract_paths = [
        r'C:\Program Files\Tesseract-OCR\tesseract.exe',
        r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
        r'C:\Users\{}\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'.format(os.environ.get('USERNAME', '')),
    ]
    
    for path in tesseract_paths:
        if os.path.exists(path):
            pytesseract.pytesseract.tesseract_cmd = path
            break

logger = logging.getLogger(__name__)

class DocumentExtractor:
    def __init__(self):
        # Initialize face detection for photo validation
        try:
            self.face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
        except:
            self.face_cascade = None
            logger.warning("Face detection cascade not available")
        
        # Enhanced document patterns with more specific validation
        self.document_patterns = {
            'id_proof': {
                'patterns': {
                    'name': [
                        r'Name[:\s]*([A-Za-z\s\.]+)',
                        r'Full Name[:\s]*([A-Za-z\s\.]+)',
                        r'(?:Name|NAAM|नाम)[:\s]*([A-Za-z\s\.]+)',
                        r'([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)'
                    ],
                    'id_number': [
                        # Aadhaar patterns
                        r'(?:Aadhaar|AADHAAR|आधार).*?([0-9]{4}\s*[0-9]{4}\s*[0-9]{4})',
                        r'([0-9]{12})',
                        # PAN patterns
                        r'PAN[:\s]*([A-Z]{5}[0-9]{4}[A-Z])',
                        r'([A-Z]{5}[0-9]{4}[A-Z])',
                        # Voter ID patterns
                        r'(?:Voter|EPIC)[:\s]*([A-Z]{3}[0-9]{7})',
                        # Driving License patterns
                        r'(?:DL|License)[:\s]*([A-Z]{2}[0-9]{13})',
                        # Generic ID patterns
                        r'(?:ID|Identity|Card).*?(?:No|Number)[:\s]*([A-Z0-9]{8,20})',
                    ],
                    'date_of_birth': [
                        r'(?:DOB|Date of Birth|Birth|जन्म)[:\s]*([0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{4})',
                        r'([0-9]{1,2}[/-][0-9]{1,2}[/-][0-9]{2,4})',
                        r'([0-9]{2}-[0-9]{2}-[0-9]{4})'
                    ],
                    'address': [
                        r'Address[:\s]*([A-Za-z0-9\s,.-]+)',
                        r'(?:Permanent|Current|पता)\s*Address[:\s]*([A-Za-z0-9\s,.-]+)',
                        r'(?:S/O|D/O|W/O)[:\s]*([A-Za-z\s]+)'
                    ],
                    'father_name': [
                        r'(?:Father|पिता)[:\s]*([A-Za-z\s]+)',
                        r'(?:S/O|Son of)[:\s]*([A-Za-z\s]+)'
                    ],
                    'gender': [
                        r'(?:Sex|Gender|लिंग)[:\s]*([MF]|Male|Female|पुरुष|महिला)',
                        r'(Male|Female|M|F)'
                    ]
                },
                'required_fields': ['name', 'id_number'],
                'optional_fields': ['date_of_birth', 'father_name', 'gender', 'address']
            },
            'address_proof': {
                'patterns': {
                    'name': [
                        r'Name[:\s]*([A-Za-z\s]+)',
                        r'([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)'
                    ],
                    'address': [
                        r'Address[:\s]*([A-Za-z0-9\s,.-]+)',
                        r'([A-Za-z0-9\s,.-]+(?:Street|Road|Lane|Avenue|Colony))',
                        r'([A-Za-z0-9\s,.-]+(?:PIN|Pincode)[:\s]*[0-9]{6})'
                    ],
                    'pincode': [
                        r'(?:PIN|Pincode|Pin)[:\s]*([0-9]{6})',
                        r'([0-9]{6})'
                    ]
                },
                'required_fields': ['name', 'address']
            }
        }
    
    def preprocess_image(self, image):
        """Preprocess image for better OCR results"""
        try:
            # Convert PIL Image to numpy array if needed
            if isinstance(image, Image.Image):
                image = np.array(image)
            
            # Convert to grayscale
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
            else:
                gray = image
            
            # Apply adaptive thresholding
            thresh = cv2.adaptiveThreshold(
                gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
            )
            
            # Noise removal
            kernel = np.ones((1, 1), np.uint8)
            opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=1)
            
            # Dilation
            kernel = np.ones((1, 1), np.uint8)
            dilation = cv2.dilate(opening, kernel, iterations=1)
            
            return dilation
            
        except Exception as e:
            logger.error(f"Image preprocessing error: {e}")
            return image
    
    def detect_photo_in_document(self, image):
        """Detect if there's a photo/face in the document"""
        try:
            if self.face_cascade is None:
                return {'has_photo': False, 'confidence': 0, 'message': 'Face detection not available'}
            
            # Convert PIL Image to numpy array if needed
            if isinstance(image, Image.Image):
                image_array = np.array(image)
            else:
                image_array = image
            
            # Convert to grayscale for face detection
            if len(image_array.shape) == 3:
                gray = cv2.cvtColor(image_array, cv2.COLOR_RGB2GRAY)
            else:
                gray = image_array
            
            # Detect faces
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(30, 30),
                flags=cv2.CASCADE_SCALE_IMAGE
            )
            
            has_photo = len(faces) > 0
            confidence = min(len(faces) * 0.3, 1.0)  # Basic confidence based on face count
            
            return {
                'has_photo': has_photo,
                'face_count': len(faces),
                'confidence': confidence,
                'faces': faces.tolist() if len(faces) > 0 else [],
                'message': f"Found {len(faces)} face(s)" if has_photo else "No faces detected"
            }
            
        except Exception as e:
            logger.error(f"Photo detection error: {e}")
            return {'has_photo': False, 'confidence': 0, 'message': f'Photo detection failed: {str(e)}'}
    
    def validate_document_shape_and_form(self, image):
        """Validate document shape, orientation, and overall form"""
        try:
            # Convert PIL Image to numpy array if needed
            if isinstance(image, Image.Image):
                image_array = np.array(image)
                height, width = image_array.shape[:2]
            else:
                height, width = image.shape[:2]
            
            validation_result = {
                'is_valid_shape': True,
                'issues': [],
                'suggestions': [],
                'dimensions': {'width': width, 'height': height},
                'aspect_ratio': width / height if height > 0 else 0
            }
            
            # Check minimum resolution
            if width < 300 or height < 200:
                validation_result['is_valid_shape'] = False
                validation_result['issues'].append('Document resolution too low')
                validation_result['suggestions'].append('Upload a higher resolution image (minimum 300x200)')
            
            # Check aspect ratio (most ID cards are landscape)
            aspect_ratio = width / height
            if aspect_ratio < 0.7 or aspect_ratio > 2.0:
                validation_result['issues'].append('Unusual document aspect ratio')
                validation_result['suggestions'].append('Ensure document is properly oriented and not cropped')
            
            # Check for excessive blur or poor quality
            if isinstance(image, Image.Image):
                gray = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2GRAY)
            else:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if len(image.shape) == 3 else image
            
            # Calculate image sharpness using Laplacian variance
            laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
            
            if laplacian_var < 100:  # Threshold for blur detection
                validation_result['issues'].append('Document appears blurry or out of focus')
                validation_result['suggestions'].append('Take a clearer, well-focused photo')
            
            # Check brightness and contrast
            mean_brightness = np.mean(gray)
            if mean_brightness < 50:
                validation_result['issues'].append('Document too dark')
                validation_result['suggestions'].append('Improve lighting when taking the photo')
            elif mean_brightness > 200:
                validation_result['issues'].append('Document too bright/overexposed')
                validation_result['suggestions'].append('Reduce lighting or avoid flash')
            
            # Overall validation
            if len(validation_result['issues']) > 0:
                validation_result['is_valid_shape'] = False
            
            return validation_result
            
        except Exception as e:
            logger.error(f"Shape validation error: {e}")
            return {
                'is_valid_shape': False,
                'issues': ['Shape validation failed'],
                'suggestions': ['Please try uploading the document again'],
                'message': str(e)
            }
    
    def extract_text_from_image(self, image):
        """Extract text from image using enhanced Tesseract OCR"""
        try:
            # Preprocess image
            processed_image = self.preprocess_image(image)
            
            # Multiple OCR configurations for better extraction
            configs = [
                r'--oem 3 --psm 6',  # Default config
                r'--oem 3 --psm 8',  # Single word
                r'--oem 3 --psm 7',  # Single text line
                r'--oem 3 --psm 11', # Sparse text
                r'--oem 3 --psm 13'  # Raw line
            ]
            
            extracted_texts = []
            
            for config in configs:
                try:
                    text = pytesseract.image_to_string(processed_image, config=config)
                    if text.strip():
                        extracted_texts.append(text.strip())
                except:
                    continue
            
            # Combine and deduplicate results
            if extracted_texts:
                # Use the longest extraction as primary
                best_text = max(extracted_texts, key=len)
                return best_text
            else:
                return ""
            
        except Exception as e:
            logger.error(f"OCR extraction error: {e}")
            return ""
    
    def extract_document_data(self, image, document_type):
        """Extract structured data from document with enhanced validation"""
        try:
            # First, validate document shape and form
            shape_validation = self.validate_document_shape_and_form(image)
            
            # Detect photo in document (for ID proofs)
            photo_detection = {'has_photo': False}
            if document_type == 'id_proof':
                photo_detection = self.detect_photo_in_document(image)
            
            # Extract raw text
            raw_text = self.extract_text_from_image(image)
            logger.info(f"Extracted text length: {len(raw_text)}")
            
            if not raw_text:
                return {
                    'success': False,
                    'message': 'No text could be extracted from the document',
                    'extracted_data': {},
                    'confidence_score': 0.0,
                    'shape_validation': shape_validation,
                    'photo_detection': photo_detection
                }
            
            # Get document patterns
            doc_patterns = self.document_patterns.get(document_type, {})
            patterns = doc_patterns.get('patterns', {})
            required_fields = doc_patterns.get('required_fields', [])
            optional_fields = doc_patterns.get('optional_fields', [])
            
            extracted_data = {}
            field_scores = {}
            
            # Extract data using enhanced patterns
            for field, pattern_list in patterns.items():
                best_match = None
                best_score = 0
                
                for pattern in pattern_list:
                    try:
                        match = re.search(pattern, raw_text, re.IGNORECASE | re.MULTILINE)
                        if match:
                            # Score based on pattern specificity and match quality
                            match_text = match.group(1).strip()
                            if len(match_text) > len(best_match or ""):
                                best_match = match_text
                                best_score = 0.9 if field in required_fields else 0.7
                    except Exception as e:
                        logger.debug(f"Pattern match error for {field}: {e}")
                        continue
                
                if best_match:
                    extracted_data[field] = best_match
                    field_scores[field] = best_score
                else:
                    field_scores[field] = 0.0
            
            # Clean extracted data
            extracted_data = self.clean_extracted_data(extracted_data, document_type)
            
            # Enhanced validation
            validation_result = self.validate_document_format(extracted_data, document_type)
            
            # Add photo validation for ID documents
            if document_type == 'id_proof':
                if not photo_detection['has_photo']:
                    validation_result['issues'].append("No photo detected in ID document")
                    validation_result['suggestions'].append("Ensure the document photo is clearly visible")
                    validation_result['is_valid'] = False
            
            # Calculate enhanced confidence score
            confidence_score = self.calculate_enhanced_confidence_score(
                extracted_data, required_fields, optional_fields, field_scores, 
                raw_text, shape_validation, photo_detection, document_type
            )
            
            return {
                'success': True,
                'extracted_data': extracted_data,
                'confidence_score': confidence_score,
                'raw_text': raw_text,
                'validation': validation_result,
                'shape_validation': shape_validation,
                'photo_detection': photo_detection,
                'message': 'Data extracted successfully with enhanced validation'
            }
            
        except Exception as e:
            logger.error(f"Document extraction error: {e}")
            return {
                'success': False,
                'message': f'Document extraction failed: {str(e)}',
                'extracted_data': {},
                'confidence_score': 0.0,
                'shape_validation': {'is_valid_shape': False, 'issues': ['Processing failed']},
                'photo_detection': {'has_photo': False, 'message': 'Detection failed'}
            }
    
    def clean_extracted_data(self, data, document_type):
        """Enhanced cleaning and formatting of extracted data"""
        cleaned_data = {}
        
        for key, value in data.items():
            if value:
                # Remove extra whitespace
                value = ' '.join(value.split())
                
                # Clean specific fields based on document type and field
                if key == 'name':
                    # Remove common prefixes/suffixes and clean
                    value = re.sub(r'^(Mr\.?|Mrs\.?|Ms\.?|Dr\.?|Shri|Smt\.?)\s*', '', value, flags=re.IGNORECASE)
                    value = re.sub(r'\s+(Jr\.?|Sr\.?|III?|IV?)$', '', value, flags=re.IGNORECASE)
                    # Remove numbers and special chars from name
                    value = re.sub(r'[0-9]', '', value)
                    value = re.sub(r'[^\w\s]', '', value)
                    value = value.title().strip()
                
                elif key == 'father_name':
                    # Similar cleaning as name
                    value = re.sub(r'^(Mr\.?|Mrs\.?|Ms\.?|Dr\.?|Shri|Smt\.?)\s*', '', value, flags=re.IGNORECASE)
                    value = re.sub(r'[0-9]', '', value)
                    value = re.sub(r'[^\w\s]', '', value)
                    value = value.title().strip()
                
                elif key == 'id_number':
                    # Smart cleaning based on ID type
                    if document_type == 'id_proof':
                        # Check if it's Aadhaar (12 digits)
                        aadhaar_match = re.search(r'([0-9]{4}\s*[0-9]{4}\s*[0-9]{4})', value)
                        if aadhaar_match:
                            value = re.sub(r'[^0-9]', '', aadhaar_match.group(1))
                        # Check if it's PAN (5 letters + 4 digits + 1 letter)
                        elif re.search(r'[A-Z]{5}[0-9]{4}[A-Z]', value.upper()):
                            value = re.sub(r'[^A-Z0-9]', '', value.upper())
                        else:
                            # Generic ID cleaning
                            value = re.sub(r'[^A-Z0-9]', '', value.upper())
                
                elif key == 'date_of_birth':
                    # Enhanced date cleaning and validation
                    value = re.sub(r'[\/\-\.]', '-', value)
                    # Try to parse and reformat date
                    try:
                        from datetime import datetime
                        for fmt in ['%d-%m-%Y', '%m-%d-%Y', '%Y-%m-%d']:
                            try:
                                parsed_date = datetime.strptime(value, fmt)
                                value = parsed_date.strftime('%d-%m-%Y')
                                break
                            except:
                                continue
                    except:
                        pass  # Keep original if parsing fails
                
                elif key == 'gender':
                    # Normalize gender values
                    value = value.upper()
                    if value in ['MALE', 'M', 'पुरुष']:
                        value = 'Male'
                    elif value in ['FEMALE', 'F', 'महिला']:
                        value = 'Female'
                
                elif key == 'address':
                    # Clean address
                    value = re.sub(r'\s+', ' ', value)  # Multiple spaces to single
                    value = value.strip()
                
                elif key == 'pincode':
                    # Extract only numbers and validate length
                    value = re.sub(r'[^0-9]', '', value)
                    if len(value) != 6:
                        # Try to find 6-digit pincode in the text
                        pincode_match = re.search(r'([0-9]{6})', value)
                        if pincode_match:
                            value = pincode_match.group(1)
                
                # Only add if value is meaningful after cleaning
                if len(value.strip()) > 0:
                    cleaned_data[key] = value.strip()
        
        return cleaned_data
    
    def calculate_enhanced_confidence_score(self, extracted_data, required_fields, optional_fields, 
                                          field_scores, raw_text, shape_validation, photo_detection, document_type):
        """Calculate enhanced confidence score with multiple factors"""
        try:
            total_score = 0
            max_score = 0
            
            # 1. Required fields score (40% weight)
            required_weight = 40
            for field in required_fields:
                max_score += required_weight / len(required_fields)
                if field in extracted_data and extracted_data[field]:
                    field_quality = self._assess_field_quality(field, extracted_data[field], document_type)
                    total_score += (required_weight / len(required_fields)) * field_scores.get(field, 0.5) * field_quality
            
            # 2. Optional fields score (20% weight)
            optional_weight = 20
            if optional_fields:
                for field in optional_fields:
                    max_score += optional_weight / len(optional_fields)
                    if field in extracted_data and extracted_data[field]:
                        field_quality = self._assess_field_quality(field, extracted_data[field], document_type)
                        total_score += (optional_weight / len(optional_fields)) * field_scores.get(field, 0.5) * field_quality
            else:
                max_score += optional_weight  # If no optional fields, add to max but not total
            
            # 3. Text quality score (15% weight)
            text_quality_weight = 15
            text_quality = min(len(raw_text) / 200, 1.0)  # Normalize by expected text length
            total_score += text_quality_weight * text_quality
            max_score += text_quality_weight
            
            # 4. Shape validation score (15% weight)
            shape_weight = 15
            if shape_validation.get('is_valid_shape', False):
                total_score += shape_weight
            max_score += shape_weight
            
            # 5. Photo detection score (10% weight for ID documents)
            photo_weight = 10
            if document_type == 'id_proof':
                if photo_detection.get('has_photo', False):
                    total_score += photo_weight * photo_detection.get('confidence', 0.5)
                max_score += photo_weight
            else:
                # For non-ID documents, redistribute this weight
                total_score += photo_weight * 0.8  # Give partial credit
                max_score += photo_weight
            
            # Normalize to percentage
            confidence_percentage = (total_score / max_score * 100) if max_score > 0 else 0
            return min(max(confidence_percentage, 0), 100)  # Clamp between 0-100
            
        except Exception as e:
            logger.error(f"Enhanced confidence calculation error: {e}")
            return 0.0
    
    def _assess_field_quality(self, field, value, document_type):
        """Assess the quality/validity of an extracted field"""
        try:
            if not value or len(value.strip()) == 0:
                return 0.0
            
            quality_score = 1.0  # Base score
            
            if field == 'name' or field == 'father_name':
                # Check if name contains reasonable characters
                if len(value) < 2:
                    quality_score *= 0.3
                elif re.search(r'[0-9]', value):  # Names shouldn't have numbers
                    quality_score *= 0.6
                elif len(value.split()) < 2:  # Prefer full names
                    quality_score *= 0.8
            
            elif field == 'id_number':
                # Validate based on common ID formats
                if re.match(r'^[0-9]{12}$', value):  # Aadhaar format
                    quality_score = 1.0
                elif re.match(r'^[A-Z]{5}[0-9]{4}[A-Z]$', value):  # PAN format
                    quality_score = 1.0
                elif re.match(r'^[A-Z]{3}[0-9]{7}$', value):  # Voter ID format
                    quality_score = 1.0
                elif len(value) >= 8:  # Generic ID minimum length
                    quality_score = 0.7
                else:
                    quality_score = 0.3
            
            elif field == 'date_of_birth':
                # Validate date format and reasonableness
                try:
                    from datetime import datetime
                    parsed_date = datetime.strptime(value, '%d-%m-%Y')
                    current_year = datetime.now().year
                    age = current_year - parsed_date.year
                    if 0 <= age <= 120:  # Reasonable age range
                        quality_score = 1.0
                    else:
                        quality_score = 0.4
                except:
                    quality_score = 0.5  # Date exists but format unclear
            
            elif field == 'pincode':
                # Validate pincode format (6 digits for India)
                if re.match(r'^[0-9]{6}$', value):
                    quality_score = 1.0
                else:
                    quality_score = 0.3
            
            return quality_score
            
        except Exception as e:
            logger.debug(f"Field quality assessment error for {field}: {e}")
            return 0.5  # Default moderate score on error
    
    def calculate_confidence_score(self, extracted_data, required_fields, field_scores, raw_text):
        """Calculate confidence score for extraction"""
        try:
            total_score = 0
            max_score = 0
            
            # Score based on required fields presence
            for field in required_fields:
                max_score += 30
                if field in extracted_data and extracted_data[field]:
                    total_score += 30 * field_scores.get(field, 0.5)
            
            # Score based on text quality
            text_quality_score = min(len(raw_text) / 100, 1.0) * 20
            total_score += text_quality_score
            max_score += 20
            
            # Score based on data format validation
            format_score = 0
            if 'id_number' in extracted_data:
                id_num = extracted_data['id_number']
                if len(id_num) >= 8:  # Minimum length check
                    format_score += 10
            
            if 'date_of_birth' in extracted_data:
                dob = extracted_data['date_of_birth']
                if re.match(r'[0-9]{1,2}-[0-9]{1,2}-[0-9]{4}', dob):
                    format_score += 10
            
            total_score += format_score
            max_score += 20
            
            # Normalize to percentage
            confidence_percentage = (total_score / max_score * 100) if max_score > 0 else 0
            return min(confidence_percentage, 100)
            
        except Exception as e:
            logger.error(f"Confidence calculation error: {e}")
            return 0.0
    
    def validate_document_format(self, extracted_data, document_type):
        """Validate if document is in expected format"""
        validation_result = {
            'is_valid': False,
            'issues': [],
            'suggestions': []
        }
        
        try:
            doc_config = self.document_patterns.get(document_type, {})
            required_fields = doc_config.get('required_fields', [])
            
            # Check required fields
            missing_fields = []
            for field in required_fields:
                if field not in extracted_data or not extracted_data[field]:
                    missing_fields.append(field)
            
            if missing_fields:
                validation_result['issues'].append(f"Missing required fields: {', '.join(missing_fields)}")
                validation_result['suggestions'].append("Ensure document is clear and all required information is visible")
            
            # Specific validations
            if document_type == 'id_proof':
                if 'id_number' in extracted_data:
                    id_num = extracted_data['id_number']
                    if len(id_num) < 8:
                        validation_result['issues'].append("ID number appears to be incomplete")
                        validation_result['suggestions'].append("Ensure ID number is clearly visible and not cut off")
            
            elif document_type == 'address_proof':
                if 'address' in extracted_data:
                    address = extracted_data['address']
                    if len(address) < 20:
                        validation_result['issues'].append("Address appears to be incomplete")
                        validation_result['suggestions'].append("Ensure complete address is visible in the document")
            
            # Overall validation
            validation_result['is_valid'] = len(validation_result['issues']) == 0
            
            if validation_result['is_valid']:
                validation_result['suggestions'].append("Document format appears to be correct")
            
            return validation_result
            
        except Exception as e:
            logger.error(f"Document validation error: {e}")
            validation_result['issues'].append("Validation failed due to processing error")
            return validation_result
    
    def extract_from_pdf(self, pdf_path):
        """Extract text from PDF document"""
        try:
            # For PDF processing, you might want to use libraries like:
            # - PyPDF2 or pdfplumber for text extraction
            # - pdf2image to convert PDF pages to images for OCR
            
            # This is a placeholder implementation
            # In production, implement proper PDF handling
            return {
                'success': False,
                'message': 'PDF processing not implemented in this demo',
                'extracted_data': {}
            }
            
        except Exception as e:
            logger.error(f"PDF extraction error: {e}")
            return {
                'success': False,
                'message': f'PDF extraction failed: {str(e)}',
                'extracted_data': {}
            }