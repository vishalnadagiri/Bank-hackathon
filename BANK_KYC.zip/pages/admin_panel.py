#!/usr/bin/env python3
"""
Admin Panel - Training, Debugging, and System Management
"""

import streamlit as st
import os
from pathlib import Path

def admin_panel():
    """Admin panel with password protection"""
    
    # Page config removed - handled by main app
    
    # Check admin authentication
    if not check_admin_auth():
        return
    
    st.title("👑 Banking KYC - Admin Panel")
    st.markdown("**System administration, training, and debugging tools**")
    
    # Admin navigation
    admin_section = st.selectbox(
        "Admin Section:",
        [
            "📊 System Overview",
            "🧠 Document Training",
            "🔧 OCR Debugger", 
            "📈 Analytics & Reports",
            "⚙️ System Configuration",
            "🗃️ Data Management"
        ],
        key="admin_nav"
    )
    
    if admin_section == "📊 System Overview":
        show_system_overview()
    elif admin_section == "🧠 Document Training":
        show_training_tools()
    elif admin_section == "🔧 OCR Debugger":
        show_debugging_tools()
    elif admin_section == "📈 Analytics & Reports":
        show_analytics()
    elif admin_section == "⚙️ System Configuration":
        show_configuration()
    elif admin_section == "🗃️ Data Management":
        show_data_management()

def check_admin_auth():
    """Simple admin authentication"""
    
    if 'admin_authenticated' not in st.session_state:
        st.session_state.admin_authenticated = False
    
    if not st.session_state.admin_authenticated:
        st.title("🔐 Admin Login")
        st.markdown("Enter admin credentials to access system management tools")
        
        with st.form("admin_login"):
            username = st.text_input("Username:")
            password = st.text_input("Password:", type="password")
            submit = st.form_submit_button("🔑 Login")
            
            if submit:
                # Simple authentication (replace with proper auth in production)
                if username == "admin" and password == "kyc_admin_2024":
                    st.session_state.admin_authenticated = True
                    st.success("✅ Admin access granted!")
                    st.rerun()
                else:
                    st.error("❌ Invalid credentials")
        
        st.info("**Default credentials:** admin / kyc_admin_2024")
        return False
    
    return True

def show_system_overview():
    """System overview dashboard"""
    st.header("📊 System Overview")
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Documents Processed", "1,234", "+45 today")
    with col2:
        st.metric("Success Rate", "89.2%", "+2.1% this week")
    with col3:
        st.metric("Active Users", "156", "+12 today")
    with col4:
        st.metric("System Health", "98.5%", "+0.5%")
    
    # System status
    st.subheader("🔧 System Status")
    
    services = [
        ("ML Document Extractor", "🟢", "Online"),
        ("PaddleOCR Service", "🟢", "Online"),
        ("Database", "🟢", "Online"),
        ("File Storage", "🟢", "Online"),
        ("OCR Debugger", "🟢", "Online")
    ]
    
    for service, status, desc in services:
        col_name, col_status = st.columns([3, 1])
        with col_name:
            st.write(f"**{service}:** {desc}")
        with col_status:
            st.write(status)
    
    # Quick actions
    st.subheader("⚡ Quick Actions")
    
    col_action1, col_action2, col_action3 = st.columns(3)
    
    with col_action1:
        if st.button("🔄 Restart ML Services", type="secondary"):
            st.success("ML services restarted successfully!")
    
    with col_action2:
        if st.button("🧹 Clear Cache", type="secondary"):
            st.success("System cache cleared!")
    
    with col_action3:
        if st.button("📊 Generate Report", type="secondary"):
            st.success("System report generated!")

def show_training_tools():
    """Document training tools"""
    st.header("🧠 Document Training Tools")
    
    # Import training components
    training_option = st.selectbox(
        "Training Method:",
        [
            "✨ Simple Training System",
            "🎯 Interactive Annotation", 
            "🤖 Batch Training",
            "📊 Training Analytics"
        ]
    )
    
    if training_option == "✨ Simple Training System":
        from components.simple_trainer import simple_training_page
        simple_training_page()
    
    elif training_option == "🎯 Interactive Annotation":
        from pages.document_training import document_training_page
        document_training_page()
    
    elif training_option == "🤖 Batch Training":
        st.subheader("🤖 Batch Training")
        st.info("Upload multiple documents for batch training")
        
        uploaded_files = st.file_uploader(
            "Upload training documents:",
            accept_multiple_files=True,
            type=['jpg', 'jpeg', 'png']
        )
        
        if uploaded_files:
            st.write(f"📁 {len(uploaded_files)} files uploaded")
            if st.button("🚀 Start Batch Training"):
                st.success("Batch training started!")
    
    elif training_option == "📊 Training Analytics":
        st.subheader("📊 Training Analytics")
        
        # Training stats
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("Trained Models", "12")
            st.metric("Training Samples", "456")
        
        with col2:
            st.metric("Avg Accuracy", "87.3%")
            st.metric("Last Training", "2 hours ago")

def show_debugging_tools():
    """OCR debugging tools"""
    st.header("🔧 OCR Debugging Tools")
    
    debug_option = st.selectbox(
        "Debug Tool:",
        [
            "🔍 OCR Quality Analyzer",
            "🖼️ Image Preprocessing Tester",
            "📊 Extraction Comparison",
            "🧪 Model Performance"
        ]
    )
    
    if debug_option == "🔍 OCR Quality Analyzer":
        from pages.ocr_debugger_page import ocr_debugger_page
        ocr_debugger_page()
    
    elif debug_option == "🖼️ Image Preprocessing Tester":
        st.info("Upload an image to test different preprocessing methods")
        
        uploaded_file = st.file_uploader("Test image:", type=['jpg', 'jpeg', 'png'])
        if uploaded_file:
            from PIL import Image
            image = Image.open(uploaded_file)
            st.image(image, caption="Original", width=300)
    
    elif debug_option == "📊 Extraction Comparison":
        st.subheader("📊 Model Comparison")
        st.info("Compare extraction results from different ML models")
        
        models = ["Enhanced OCR", "PaddleOCR", "EasyOCR", "Google Document AI"]
        for model in models:
            st.write(f"**{model}:** Ready for comparison")

def show_analytics():
    """Analytics and reports"""
    st.header("📈 Analytics & Reports")
    
    # Sample analytics data
    import pandas as pd
    import matplotlib.pyplot as plt
    
    # Extraction success rate over time
    st.subheader("📊 Extraction Success Rate")
    
    data = {
        'Date': pd.date_range('2024-01-01', periods=30),
        'Success_Rate': [85 + i * 0.1 + (i % 3) * 2 for i in range(30)]
    }
    df = pd.DataFrame(data)
    
    st.line_chart(df.set_index('Date'))
    
    # Document type distribution
    st.subheader("📋 Document Types Processed")
    
    doc_types = {
        'Aadhaar': 45,
        'PAN': 35,
        'Passport': 15,
        'Other': 5
    }
    
    st.bar_chart(doc_types)

def show_configuration():
    """System configuration"""
    st.header("⚙️ System Configuration")
    
    # ML Model Configuration
    st.subheader("🤖 ML Model Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        ocr_confidence = st.slider("OCR Confidence Threshold", 0.0, 1.0, 0.7)
        max_attempts = st.number_input("Max Extraction Attempts", 1, 10, 5)
        
    with col2:
        enable_paddleocr = st.checkbox("Enable PaddleOCR", True)
        enable_fallback = st.checkbox("Enable Fallback Models", True)
    
    # API Configuration
    st.subheader("🌐 API Configuration")
    
    with st.expander("Google Document AI"):
        api_key = st.text_input("API Key:", type="password")
        project_id = st.text_input("Project ID:")
    
    with st.expander("AWS Textract"):
        aws_key = st.text_input("AWS Access Key:", type="password")
        aws_secret = st.text_input("AWS Secret:", type="password")
    
    if st.button("💾 Save Configuration"):
        st.success("✅ Configuration saved successfully!")

def show_data_management():
    """Data management tools"""
    st.header("🗃️ Data Management")
    
    # Database stats
    st.subheader("📊 Database Statistics")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total Records", "5,432")
    with col2:
        st.metric("Storage Used", "2.3 GB")
    with col3:
        st.metric("Backup Status", "✅ Current")
    
    # Data operations
    st.subheader("🔧 Data Operations")
    
    col_op1, col_op2, col_op3 = st.columns(3)
    
    with col_op1:
        if st.button("📥 Export Data"):
            st.success("Data export initiated!")
    
    with col_op2:
        if st.button("🔄 Backup Database"):
            st.success("Database backup created!")
    
    with col_op3:
        if st.button("🧹 Cleanup Old Files"):
            st.success("Cleanup completed!")
    
    # File management
    st.subheader("📁 File Management")
    
    uploaded_files_count = len(list(Path("uploads").glob("*"))) if Path("uploads").exists() else 0
    st.write(f"**Uploaded Files:** {uploaded_files_count}")
    
    if st.button("🗑️ Clear Upload Directory"):
        st.warning("This will delete all uploaded files. Are you sure?")

if __name__ == "__main__":
    admin_panel()