#!/usr/bin/env python3
"""
Banking KYC Application Runner
Simple script to run the Streamlit application with proper configuration
"""

import os
import sys
import subprocess
import logging
from pathlib import Path

def setup_environment():
    """Setup required directories and environment"""
    # Create required directories
    directories = ['uploads', 'data', 'logs']
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        print(f"✅ Created directory: {directory}")
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('logs/kyc_app.log'),
            logging.StreamHandler()
        ]
    )
    
    print("✅ Environment setup complete")

def check_dependencies():
    """Check if all required dependencies are installed"""
    # Map package names to their import names
    package_import_map = {
        'streamlit': 'streamlit',
        'opencv-python': 'cv2',
        'Pillow': 'PIL',
        'pytesseract': 'pytesseract',
        'pandas': 'pandas',
        'numpy': 'numpy',
        'bcrypt': 'bcrypt',
        'fuzzywuzzy': 'fuzzywuzzy',
        'reportlab': 'reportlab'
    }
    
    missing_packages = []
    
    for package_name, import_name in package_import_map.items():
        try:
            __import__(import_name)
            print(f"✅ {package_name} - OK")
        except ImportError:
            missing_packages.append(package_name)
            print(f"❌ {package_name} - Missing")
    
    if missing_packages:
        print(f"\n⚠️  Missing packages: {', '.join(missing_packages)}")
        print("Please install with: pip install -r requirements.txt")
        return False
    
    print("✅ All dependencies installed")
    return True

def check_tesseract():
    """Check if Tesseract OCR is installed"""
    try:
        result = subprocess.run(['tesseract', '--version'], 
                              capture_output=True, text=True)
        if result.returncode == 0:
            print("✅ Tesseract OCR - OK")
            return True
        else:
            print("❌ Tesseract OCR - Not working properly")
            return False
    except FileNotFoundError:
        print("❌ Tesseract OCR - Not installed")
        print("Please install Tesseract OCR:")
        print("  Windows: https://github.com/UB-Mannheim/tesseract/wiki")
        print("  Mac: brew install tesseract")
        print("  Linux: sudo apt-get install tesseract-ocr")
        return False

def run_application():
    """Run the Streamlit application"""
    print("\n🚀 Starting Banking KYC Application...")
    print("📍 The application will be available at: http://localhost:8501")
    print("⏹️  Press Ctrl+C to stop the application")
    print("-" * 50)
    
    try:
        # Run Streamlit app
        subprocess.run([
            sys.executable, '-m', 'streamlit', 'run', 'main.py',
            '--server.port=8501',
            '--server.address=localhost',
            '--server.headless=false'
        ])
    except KeyboardInterrupt:
        print("\n\n⏹️  Application stopped by user")
    except Exception as e:
        print(f"\n❌ Error running application: {e}")

def main():
    """Main function"""
    print("🏦 Banking KYC Application Startup")
    print("=" * 40)
    
    # Setup environment
    setup_environment()
    
    # Check dependencies
    if not check_dependencies():
        print("\n❌ Dependency check failed. Please install missing packages.")
        sys.exit(1)
    
    # Check Tesseract
    if not check_tesseract():
        print("\n⚠️  Tesseract not found. OCR functionality will be limited.")
        print("⏭️  Continuing with limited OCR functionality...")
    
    # Run application
    run_application()

if __name__ == "__main__":
    main()