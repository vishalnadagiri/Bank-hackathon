
from database.db import get_connection

def login_user(registered_no, mobile):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM customers WHERE registered_no=? AND mobile=?", (registered_no, mobile))
    user = cursor.fetchone()
    conn.close()
    return user
