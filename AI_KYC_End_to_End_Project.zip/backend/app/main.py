from fastapi import FastAPI
app = FastAPI(title="KYC API")

@app.get("/")
def root():
    return {"status": "running"}