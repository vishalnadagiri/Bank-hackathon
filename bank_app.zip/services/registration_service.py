
from database.db import get_connection
from utils.id_generator import generate_registered_no

def register_user(data):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "SELECT registered_no FROM customers WHERE mobile=? AND aadhaar=?",
        (data["mobile"], data["aadhaar"])
    )
    existing = cursor.fetchone()
    if existing:
        return False, existing[0]

    reg_no = generate_registered_no()
    cursor.execute(
        "INSERT INTO customers (registered_no, first_name, last_name, mobile, aadhaar, dob) VALUES (?, ?, ?, ?, ?, ?)",
        (reg_no, data["first_name"], data["last_name"], data["mobile"], data["aadhaar"], str(data["dob"]))
    )
    conn.commit()
    conn.close()
    return True, reg_no
