import streamlit as st
import json
from datetime import datetime
from services.verification_service import VerificationService


def _inject_dashboard_styles() -> None:
    """Inject small theme-aware CSS for dashboard cards.

    Streamlit doesn't expose a stable theme API to Python at runtime, so we rely on
    CSS variables that are present in both light/dark themes.
    """
    st.markdown(
        """
        <style>
          :root {
            --rovo-card-bg: rgba(255, 255, 255, 0.8);
            --rovo-card-border: rgba(49, 51, 63, 0.10);
            --rovo-muted: rgba(49, 51, 63, 0.70);
            --rovo-shadow: 0 2px 10px rgba(0,0,0,0.06);
          }

          /* Streamlit uses these variables in both themes; when present, prefer them. */
          .rovo-card {
            /* Use Streamlit's "panel" background when available (works in light & dark themes). */
            background: var(--secondary-background-color, var(--rovo-card-bg));
            border: 1px solid var(--rovo-card-border);
            border-radius: 12px;
            padding: 16px;
            box-shadow: var(--rovo-shadow);
          }

          .rovo-card--soft {
            background: linear-gradient(90deg,
              rgba(0, 102, 204, 0.06) 0%,
              rgba(0, 102, 204, 0.02) 100%
            );
            border-left: 5px solid #0066cc;
          }

          .rovo-card__title {
            margin: 0;
            color: #0066cc;
          }

          .rovo-card__muted {
            color: var(--text-color, var(--rovo-muted));
            opacity: 0.75;
          }

          .rovo-status-card {
            text-align: center;
          }

          .rovo-status-card__icon {
            font-size: 24px;
            line-height: 1;
          }

          .rovo-status-card__label {
            font-weight: 600;
            margin: 8px 0 2px 0;
          }
        </style>
        """,
        unsafe_allow_html=True,
    )

def show_kyc_status_card(kyc_status):
    """Display KYC status card"""
    _inject_dashboard_styles()
    if not kyc_status:
        st.error("❌ Unable to load KYC status")
        return
    
    # Status colors
    status_colors = {
        'completed': '🟢',
        'verified': '✅',
        'in_progress': '🟡',
        'pending': '⏳',
        'failed': '❌',
        'incomplete': '⚪'
    }
    
    # Overall status
    overall_color = status_colors.get(kyc_status['overall_status'], '⚪')
    
    st.markdown(
        f"""
        <div class='rovo-card rovo-card--soft'>
            <h3 class='rovo-card__title'>{overall_color} KYC Status Overview</h3>
            <p style='margin: 6px 0; font-size: 18px;'>
                <strong>Overall Status:</strong> {kyc_status['overall_status'].title()}
            </p>
            <p style='margin: 6px 0;'>
                <strong>Completion:</strong> {kyc_status['completion_percentage']:.1f}%
            </p>
            <p style='margin: 6px 0;'>
                <strong>Verification Score:</strong> {kyc_status['verification_score']:.1f}/100
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )
    
    # Progress bar
    progress_value = kyc_status['completion_percentage'] / 100
    st.progress(progress_value)
    
    # Document status breakdown
    st.subheader("📄 Document Status")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        id_color = status_colors.get(kyc_status['id_proof_status'], '⚪')
        st.markdown(
            f"""
            <div class='rovo-card rovo-card--soft'>
                <div class='rovo-status-card__icon'>{id_color}</div>
                <div class='rovo-status-card__label'>ID Proof</div>
                <div class='rovo-card__muted'>{kyc_status['id_proof_status'].title()}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    with col2:
        address_color = status_colors.get(kyc_status['address_proof_status'], '⚪')
        st.markdown(
            f"""
            <div class='rovo-card rovo-card--soft'>
                <div class='rovo-status-card__icon'>{address_color}</div>
                <div class='rovo-status-card__label'>Address Proof</div>
                <div class='rovo-card__muted'>{kyc_status['address_proof_status'].title()}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    
    with col3:
        photo_color = status_colors.get(kyc_status['photo_status'], '⚪')
        st.markdown(
            f"""
            <div class='rovo-card rovo-card--soft'>
                <div class='rovo-status-card__icon'>{photo_color}</div>
                <div class='rovo-status-card__label'>Photo ID</div>
                <div class='rovo-card__muted'>{kyc_status['photo_status'].title()}</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

def show_next_steps(kyc_status):
    """Show next steps based on current status"""
    st.subheader("🎯 Next Steps")
    
    if kyc_status['overall_status'] == 'completed':
        st.success("🎉 **Congratulations!** Your KYC verification is complete.")
        st.info("You can now proceed with account opening and banking services.")
        
        if st.button("📋 Download KYC Certificate", type="primary", key="download_cert"):
            st.info("Certificate download would be implemented here")
        
    else:
        pending_docs = []
        
        if kyc_status['id_proof_status'] in ['pending', 'failed']:
            pending_docs.append("ID Proof")
        if kyc_status['address_proof_status'] in ['pending', 'failed']:
            pending_docs.append("Address Proof")
        if kyc_status['photo_status'] in ['pending', 'failed']:
            pending_docs.append("Photo ID")
        
        if pending_docs:
            st.warning(f"📝 **Required Actions:** Upload {', '.join(pending_docs)}")
            
            if st.button("📤 Upload Documents", type="primary", key="upload_docs_main"):
                st.session_state.current_page = 'upload'
                st.rerun()
        else:
            st.info("⏳ Your documents are under review. Please check back later.")

def show_customer_profile(customer_data):
    """Display customer profile information"""
    st.subheader("👤 Profile Information")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.text_input("Customer ID", value=customer_data['customer_id'], disabled=True)
        st.text_input("Full Name", value=customer_data['name'], disabled=True)
    
    with col2:
        st.text_input("Email", value=customer_data['email'], disabled=True)
        st.text_input("Phone", value=customer_data['phone'], disabled=True)
    
    st.text_input("Account Status", value=customer_data['status'].title(), disabled=True)

def show_recent_activity(customer_id):
    """Show recent activity/audit logs"""
    st.subheader("📊 Recent Activity")
    
    # This would fetch actual audit logs from database
    # For demo, showing sample data
    activities = [
        {
            'timestamp': '2024-01-15 14:30:25',
            'action': 'LOGIN_SUCCESS',
            'details': 'Customer logged in successfully'
        },
        {
            'timestamp': '2024-01-15 14:25:10',
            'action': 'DOCUMENT_UPLOADED',
            'details': 'ID Proof document uploaded'
        },
        {
            'timestamp': '2024-01-15 14:20:05',
            'action': 'OTP_VERIFIED',
            'details': 'OTP verified for document verification'
        },
        {
            'timestamp': '2024-01-14 16:45:30',
            'action': 'CUSTOMER_REGISTERED',
            'details': 'Customer registration completed'
        }
    ]
    
    for activity in activities:
        with st.expander(f"🕒 {activity['timestamp']} - {activity['action']}", expanded=False):
            st.write(activity['details'])

def show_help_support():
    """Show help and support information"""
    st.subheader("💡 Help & Support")
    
    with st.expander("📋 Required Documents", expanded=False):
        st.markdown("""
        **ID Proof (Any one):**
        - Aadhaar Card
        - PAN Card
        - Passport
        - Driving License
        - Voter ID
        
        **Address Proof (Any one):**
        - Utility Bill (Electricity/Water/Gas)
        - Bank Statement
        - Rental Agreement
        - Aadhaar Card
        
        **Photo ID:**
        - Clear photograph
        - Passport size
        - Recent (within 6 months)
        """)
    
    with st.expander("❓ Frequently Asked Questions", expanded=False):
        st.markdown("""
        **Q: How long does KYC verification take?**
        A: Typically 24-48 hours for document review and approval.
        
        **Q: What if my document is rejected?**
        A: You can re-upload with better quality or different document.
        
        **Q: Is my data secure?**
        A: Yes, we use bank-grade security with end-to-end encryption.
        
        **Q: Can I track my KYC status?**
        A: Yes, you can check real-time status on this dashboard.
        """)
    
    with st.expander("📞 Contact Support", expanded=False):
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("**Phone Support:**")
            st.write("📞 1800-XXX-XXXX (Toll Free)")
            st.write("⏰ 24/7 Available")
        with col2:
            st.markdown("**Email Support:**")
            st.write("📧 kyc-support@bank.com")
            st.write("⏰ Response within 4 hours")

def show_dashboard():
    """Main dashboard page"""
    if not st.session_state.get('authenticated', False):
        st.error("❌ Please login to access dashboard")
        if st.button("Go to Login", key="goto_login"):
            st.session_state.current_page = 'auth'
            st.rerun()
        return
    
    customer_data = st.session_state.get('customer_data', {})
    customer_id = customer_data.get('customer_id', '')
    
    # Page header
    st.title(f"🏦 Welcome, {customer_data.get('name', 'Customer')}!")
    st.write("Track your KYC verification status and manage your documents")
    
    # Navigation buttons
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("📤 Upload Documents", type="primary", key="upload_docs_action"):
            st.session_state.current_page = 'upload'
            st.rerun()
    
    with col2:
        if st.button("📋 My Aadhaar KYC", key="view_aadhaar"):
            st.session_state.current_page = 'upload'
            st.rerun()
    
    with col3:
        if st.button("📊 Reports", key="goto_reports"):
            st.session_state.current_page = 'reports'
            st.rerun()
    
    with col4:
        if st.button("🚪 Logout", key="logout_dashboard"):
            # Clear session
            for key in list(st.session_state.keys()):
                if key.startswith(('authenticated', 'customer_data', 'current_page')):
                    del st.session_state[key]
            st.rerun()
    
    st.markdown("---")
    
    # Get KYC status
    verification_service = VerificationService()
    kyc_status = verification_service.get_kyc_status(customer_id)
    
    # Main content
    col1, col2 = st.columns([2, 1])
    
    with col1:
        # KYC Status
        show_kyc_status_card(kyc_status)
        st.markdown("---")
        
        # Next steps
        if kyc_status:
            show_next_steps(kyc_status)
        
        st.markdown("---")
        
        # Recent activity
        show_recent_activity(customer_id)
    
    with col2:
        # Customer profile
        show_customer_profile(customer_data)
        st.markdown("---")

        # Aadhaar KYC (latest verified)
        from config.database import DatabaseManager
        db = DatabaseManager()
        latest = db.get_latest_verified_aadhaar(customer_id)
        st.subheader("🪪 Aadhaar KYC")
        if latest:
            try:
                extracted_json = json.loads(latest[3]) if latest[3] else {}
            except Exception:
                extracted_json = {}

            st.success("✅ Verified")
            st.write(f"**Verified At:** {latest[8]}")
            st.write(f"**Confidence:** {latest[4]:.1f}%")
            st.write(f"**Aadhaar:** {extracted_json.get('id_number', 'N/A')}")
            st.caption("(Aadhaar-only phase: only Aadhaar number is verified)")
        else:
            st.info("No verified Aadhaar record yet. Please upload & verify your Aadhaar.")

        # Recent attempts
        with st.expander("🕘 Aadhaar Attempt History", expanded=False):
            history = db.get_aadhaar_history(customer_id, limit=10)
            if not history:
                st.write("No attempts yet.")
            else:
                for row in history:
                    _id, file_path, conf, verified, verified_at, created_at = row
                    st.write(f"• {created_at} | verified={bool(verified)} | conf={conf:.1f}%")

        st.markdown("---")
        
        # Help & Support
        show_help_support()
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style='text-align: center; color: gray; padding: 20px;'>
        🔒 Your data is encrypted and secure | 🤖 AI-powered verification | 🏦 Bank-grade security
    </div>
    """, unsafe_allow_html=True)