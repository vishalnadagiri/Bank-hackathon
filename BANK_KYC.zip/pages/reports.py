import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import json
from services.audit_service import AuditService
from services.verification_service import VerificationService

def show_audit_logs(customer_id):
    """Display audit logs for customer"""
    audit_service = AuditService()
    
    st.subheader("📊 Activity Logs")
    
    # Filters
    col1, col2, col3 = st.columns(3)
    
    with col1:
        date_from = st.date_input("From Date", value=datetime.now() - timedelta(days=30))
    
    with col2:
        date_to = st.date_input("To Date", value=datetime.now())
    
    with col3:
        action_filter = st.selectbox(
            "Action Type",
            ["All", "LOGIN_SUCCESS", "DOCUMENT_UPLOADED", "OTP_VERIFIED", "KYC_STATUS_UPDATED", "CUSTOMER_REGISTERED"]
        )
    
    # Get logs
    logs = audit_service.get_audit_logs(
        customer_id=customer_id,
        date_from=date_from.isoformat() if date_from else None,
        date_to=date_to.isoformat() if date_to else None,
        action_type=action_filter if action_filter != "All" else None,
        limit=100
    )
    
    if logs:
        # Convert to DataFrame for better display
        df = pd.DataFrame(logs)
        df['timestamp'] = pd.to_datetime(df['timestamp']).dt.strftime('%Y-%m-%d %H:%M:%S')
        
        # Display in expandable format
        for _, log in df.iterrows():
            action_emoji = {
                'LOGIN_SUCCESS': '🔐',
                'DOCUMENT_UPLOADED': '📤',
                'OTP_VERIFIED': '📱',
                'KYC_STATUS_UPDATED': '✅',
                'CUSTOMER_REGISTERED': '👤',
                'LOGIN_FAILED': '❌'
            }.get(log['action'], '📝')
            
            with st.expander(f"{action_emoji} {log['timestamp']} - {log['action']}", expanded=False):
                st.write(f"**Details:** {log['details']}")
                if log.get('ip_address'):
                    st.write(f"**IP Address:** {log['ip_address']}")
    else:
        st.info("No audit logs found for the selected criteria")

def show_document_history(customer_id):
    """Display document upload history"""
    st.subheader("📄 Document History")
    
    # Get documents from database
    verification_service = VerificationService()
    
    with verification_service.db.get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT document_type, file_name, verification_status, confidence_score,
                   uploaded_at, verified_at, extracted_data
            FROM documents 
            WHERE customer_id = ?
            ORDER BY uploaded_at DESC
        """, (customer_id,))
        
        documents = cursor.fetchall()
    
    if documents:
        for doc in documents:
            doc_type = doc[0].replace('_', ' ').title()
            status_emoji = {
                'verified': '✅',
                'pending': '⏳',
                'failed': '❌'
            }.get(doc[2], '❓')
            
            with st.expander(f"{status_emoji} {doc_type} - {doc[1]}", expanded=False):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write(f"**Status:** {doc[2].title()}")
                    st.write(f"**Confidence:** {doc[3]:.1f}%")
                    st.write(f"**Uploaded:** {doc[4]}")
                
                with col2:
                    if doc[5]:
                        st.write(f"**Verified:** {doc[5]}")
                    else:
                        st.write("**Verified:** Not yet")
                
                # Show extracted data if available
                if doc[6]:
                    try:
                        extracted_data = json.loads(doc[6])
                        if extracted_data:
                            st.write("**Extracted Information:**")
                            for key, value in extracted_data.items():
                                if value:
                                    st.write(f"- **{key.replace('_', ' ').title()}:** {value}")
                    except:
                        pass
    else:
        st.info("No documents uploaded yet")

def show_kyc_summary(customer_id):
    """Display KYC verification summary"""
    verification_service = VerificationService()
    kyc_status = verification_service.get_kyc_status(customer_id)
    
    if not kyc_status:
        st.error("Unable to load KYC status")
        return
    
    st.subheader("📋 KYC Summary")
    
    # Create summary cards
    col1, col2 = st.columns(2)
    
    with col1:
        # Status chart
        st.markdown("**Document Status Overview**")
        
        status_data = {
            'ID Proof': kyc_status['id_proof_status'],
            'Address Proof': kyc_status['address_proof_status'],
            'Photo ID': kyc_status['photo_status']
        }
        
        for doc_type, status in status_data.items():
            status_color = {
                'verified': '🟢',
                'pending': '🟡',
                'failed': '🔴'
            }.get(status, '⚪')
            
            st.write(f"{status_color} **{doc_type}:** {status.title()}")
    
    with col2:
        st.markdown("**Verification Metrics**")
        st.metric("Overall Status", kyc_status['overall_status'].title())
        st.metric("Completion", f"{kyc_status['completion_percentage']:.1f}%")
        st.metric("Verification Score", f"{kyc_status['verification_score']:.1f}/100")
    
    # Progress timeline
    st.markdown("**Verification Timeline**")
    
    timeline_items = []
    
    # Registration
    timeline_items.append({
        'status': '✅ Completed',
        'title': 'Customer Registration',
        'description': 'Account created successfully'
    })
    
    # Document status
    if kyc_status['id_proof_status'] == 'verified':
        timeline_items.append({
            'status': '✅ Completed',
            'title': 'ID Proof Verification',
            'description': 'Identity document verified'
        })
    elif kyc_status['id_proof_status'] == 'pending':
        timeline_items.append({
            'status': '⏳ In Progress',
            'title': 'ID Proof Verification',
            'description': 'Document under review'
        })
    
    if kyc_status['address_proof_status'] == 'verified':
        timeline_items.append({
            'status': '✅ Completed',
            'title': 'Address Proof Verification',
            'description': 'Address document verified'
        })
    elif kyc_status['address_proof_status'] == 'pending':
        timeline_items.append({
            'status': '⏳ In Progress',
            'title': 'Address Proof Verification',
            'description': 'Document under review'
        })
    
    if kyc_status['photo_status'] == 'verified':
        timeline_items.append({
            'status': '✅ Completed',
            'title': 'Photo ID Verification',
            'description': 'Photo identity verified'
        })
    elif kyc_status['photo_status'] == 'pending':
        timeline_items.append({
            'status': '⏳ In Progress',
            'title': 'Photo ID Verification',
            'description': 'Photo under review'
        })
    
    # Account opening
    if kyc_status['overall_status'] == 'completed':
        timeline_items.append({
            'status': '✅ Completed',
            'title': 'KYC Verification Complete',
            'description': 'Ready for account opening'
        })
    else:
        timeline_items.append({
            'status': '⏳ Pending',
            'title': 'KYC Verification Complete',
            'description': 'Complete all document uploads'
        })
    
    for item in timeline_items:
        st.write(f"**{item['status']}** {item['title']}")
        st.write(f"└─ {item['description']}")
        st.write("")

def export_customer_report(customer_id, customer_name):
    """Export customer report"""
    audit_service = AuditService()
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("📄 Download PDF Report", type="primary", key="download_pdf_report"):
            with st.spinner("Generating PDF report..."):
                pdf_data = audit_service.generate_kyc_report_pdf(customer_id)
                
                if pdf_data:
                    st.download_button(
                        label="📥 Download PDF",
                        data=pdf_data,
                        file_name=f"KYC_Report_{customer_id}_{datetime.now().strftime('%Y%m%d')}.pdf",
                        mime="application/pdf"
                    )
                    st.success("✅ PDF report generated successfully!")
                else:
                    st.error("❌ Failed to generate PDF report")
    
    with col2:
        if st.button("📊 Download CSV Data", type="secondary", key="download_csv_data"):
            with st.spinner("Preparing CSV data..."):
                csv_data = audit_service.export_audit_logs_csv({
                    'customer_id': customer_id,
                    'limit': 500
                })
                
                if csv_data:
                    st.download_button(
                        label="📥 Download CSV",
                        data=csv_data,
                        file_name=f"Audit_Logs_{customer_id}_{datetime.now().strftime('%Y%m%d')}.csv",
                        mime="text/csv"
                    )
                    st.success("✅ CSV data prepared successfully!")
                else:
                    st.error("❌ Failed to prepare CSV data")

def show_reports_page():
    """Main reports page"""
    if not st.session_state.get('authenticated', False):
        st.error("❌ Please login to view reports")
        return
    
    customer_data = st.session_state.get('customer_data', {})
    customer_id = customer_data.get('customer_id', '')
    customer_name = customer_data.get('name', '')
    
    st.title("📊 KYC Reports & Analytics")
    st.write(f"Comprehensive verification reports for {customer_name}")
    
    # Back button
    if st.button("← Back to Dashboard", key="back_to_dashboard_reports"):
        st.session_state.current_page = 'dashboard'
        st.rerun()
    
    # Report tabs
    tab1, tab2, tab3, tab4 = st.tabs(["📋 KYC Summary", "📄 Documents", "📊 Activity Logs", "📥 Export"])
    
    with tab1:
        show_kyc_summary(customer_id)
    
    with tab2:
        show_document_history(customer_id)
    
    with tab3:
        show_audit_logs(customer_id)
    
    with tab4:
        st.subheader("📥 Export Reports")
        st.write("Download comprehensive reports for your records")
        
        export_customer_report(customer_id, customer_name)
        
        st.markdown("---")
        st.info("""
        **Report Contents:**
        - 📋 Complete KYC status and verification details
        - 📄 Document upload and verification history
        - 📊 Activity logs and audit trail
        - 🔒 Compliance-ready format for regulatory requirements
        """)
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style='text-align: center; color: gray;'>
        📊 Comprehensive Reporting | 🔒 Audit Trail | 📋 Compliance Ready
    </div>
    """, unsafe_allow_html=True)