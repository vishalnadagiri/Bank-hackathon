import streamlit as st
import re
from services.auth_service import AuthService, OTPService

def validate_email(email):
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_phone(phone):
    """Validate phone number format"""
    pattern = r'^[6-9]\d{9}$'
    return re.match(pattern, phone) is not None

def validate_password(password):
    """Validate password strength"""
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    if not re.search(r'[A-Z]', password):
        return False, "Password must contain at least one uppercase letter"
    if not re.search(r'[a-z]', password):
        return False, "Password must contain at least one lowercase letter"
    if not re.search(r'\d', password):
        return False, "Password must contain at least one number"
    return True, "Password is strong"

def show_registration_form():
    """Display customer registration form"""
    st.subheader("🏦 Customer Registration")
    st.write("Create your banking account to start KYC verification")
    
    auth_service = AuthService()
    
    with st.form("registration_form"):
        st.write("**Personal Information**")
        
        col1, col2 = st.columns(2)
        with col1:
            name = st.text_input("Full Name*", placeholder="Enter your full name")
            email = st.text_input("Email Address*", placeholder="Enter your email")
        
        with col2:
            phone = st.text_input("Phone Number*", placeholder="Enter 10-digit mobile number")
            password = st.text_input("Password*", type="password", placeholder="Create strong password")
        
        confirm_password = st.text_input("Confirm Password*", type="password")
        
        # Terms and conditions
        terms_accepted = st.checkbox("I agree to the Terms and Conditions and Privacy Policy*")
        
        submit_button = st.form_submit_button("Register Account", type="primary")
        
        if submit_button:
            # Validation
            errors = []
            
            if not name.strip():
                errors.append("Full name is required")
            elif len(name.strip()) < 2:
                errors.append("Full name must be at least 2 characters")
            
            if not email:
                errors.append("Email is required")
            elif not validate_email(email):
                errors.append("Invalid email format")
            
            if not phone:
                errors.append("Phone number is required")
            elif not validate_phone(phone):
                errors.append("Invalid phone number format (must be 10 digits starting with 6-9)")
            
            if not password:
                errors.append("Password is required")
            else:
                is_valid, msg = validate_password(password)
                if not is_valid:
                    errors.append(msg)
            
            if password != confirm_password:
                errors.append("Passwords do not match")
            
            if not terms_accepted:
                errors.append("You must accept the terms and conditions")
            
            # Display errors or process registration
            if errors:
                for error in errors:
                    st.error(f"❌ {error}")
            else:
                # Process registration
                with st.spinner("Creating your account..."):
                    result = auth_service.register_customer(name, email, phone, password)
                    
                    if result['success']:
                        # Store registration success data
                        st.session_state.registration_success = True
                        st.session_state.new_customer_id = result['customer_id']
                        st.session_state.new_customer_email = email
                        st.session_state.new_customer_name = name
                        
                        # Show success and switch to login tab
                        st.balloons()
                        st.success("🎉 Registration completed successfully!")
                        st.success(f"✅ Welcome to Banking KYC, {name}!")
                        
                        # Create prominent success box
                        st.markdown("""
                        <div style='background-color: #d4edda; border: 2px solid #28a745; 
                                    border-radius: 10px; padding: 20px; margin: 20px 0; text-align: center;'>
                            <h3 style='color: #155724; margin: 0;'>🎉 Account Created Successfully!</h3>
                            <p style='color: #155724; font-size: 16px; margin: 10px 0;'>
                                <strong>Customer ID:</strong> {customer_id}
                            </p>
                            <p style='color: #155724; font-size: 14px; margin: 5px 0;'>
                                Your account has been created. Please login to continue with KYC verification.
                            </p>
                        </div>
                        """.format(customer_id=result['customer_id']), unsafe_allow_html=True)
                        
                        # Prominent login button
                        if st.button("🚀 Continue to Login", type="primary", use_container_width=True):
                            st.session_state.auth_tab = 'login'
                            st.rerun()
                        
                        st.info("💡 **Next Steps:** Login with your email and password to start KYC verification")
                        
                    else:
                        st.error(f"❌ {result['message']}")

def show_login_form():
    """Display customer login form"""
    st.subheader("🔐 Customer Login")
    st.write("Access your KYC dashboard")
    
    auth_service = AuthService()
    
    with st.form("login_form"):
        email = st.text_input("Email Address", placeholder="Enter your registered email")
        password = st.text_input("Password", type="password", placeholder="Enter your password")
        
        col1, col2 = st.columns(2)
        with col1:
            login_button = st.form_submit_button("Login", type="primary")
        with col2:
            forgot_password = st.form_submit_button("Forgot Password?")
        
        if login_button:
            if not email or not password:
                st.error("❌ Please enter both email and password")
            else:
                with st.spinner("Authenticating..."):
                    result = auth_service.authenticate_customer(email, password)
                    
                    if result['success']:
                        st.success("✅ Login successful!")
                        
                        # Store user session
                        st.session_state.authenticated = True
                        st.session_state.customer_data = result['customer_data']
                        st.session_state.current_page = 'dashboard'
                        
                        st.rerun()
                    else:
                        st.error(f"❌ {result['message']}")
        
        if forgot_password:
            st.info("📧 Forgot password functionality would send reset link to your email")

def show_otp_verification(customer_id, purpose="verification"):
    """Display OTP verification form"""
    st.subheader("📱 OTP Verification")
    st.write(f"Enter the 6-digit OTP sent to your registered mobile number")
    
    otp_service = OTPService()
    
    # Generate and display OTP for demo
    if 'otp_generated' not in st.session_state:
        with st.spinner("Sending OTP..."):
            otp_result = otp_service.send_otp(customer_id, purpose)
            
            if otp_result['success']:
                st.session_state.otp_generated = True
                st.session_state.demo_otp = otp_result['otp']  # For demo purposes
                st.success("✅ OTP sent successfully!")
                
                # Show demo OTP (remove in production)
                st.info(f"🔢 **Demo OTP:** {otp_result['otp']} (This would be sent via SMS in production)")
            else:
                st.error(f"❌ {otp_result['message']}")
                return False
    
    with st.form("otp_form"):
        otp_input = st.text_input("Enter OTP", max_chars=6, placeholder="000000")
        
        col1, col2 = st.columns(2)
        with col1:
            verify_button = st.form_submit_button("Verify OTP", type="primary")
        with col2:
            resend_button = st.form_submit_button("Resend OTP")
        
        if verify_button:
            if len(otp_input) != 6 or not otp_input.isdigit():
                st.error("❌ Please enter a valid 6-digit OTP")
            else:
                with st.spinner("Verifying OTP..."):
                    result = otp_service.verify_otp(customer_id, otp_input, purpose)
                    
                    if result['success']:
                        st.success("✅ OTP verified successfully!")
                        st.session_state.otp_verified = True
                        
                        # Clear OTP session
                        if 'otp_generated' in st.session_state:
                            del st.session_state.otp_generated
                        if 'demo_otp' in st.session_state:
                            del st.session_state.demo_otp
                        
                        return True
                    else:
                        st.error(f"❌ {result['message']}")
        
        if resend_button:
            # Clear current OTP and generate new one
            if 'otp_generated' in st.session_state:
                del st.session_state.otp_generated
            if 'demo_otp' in st.session_state:
                del st.session_state.demo_otp
            st.rerun()
    
    return False

def show_authentication_page():
    """Main authentication page"""
    st.title("🏦 Banking KYC Portal")
    st.write("Secure document upload and verification system")
    
    # Check if already authenticated
    if st.session_state.get('authenticated', False):
        st.success("✅ You are already logged in!")
        if st.button("Go to Dashboard", key="goto_dashboard_auth"):
            st.session_state.current_page = 'dashboard'
            st.rerun()
        return
    
    # Check for registration success message
    if st.session_state.get('registration_success', False):
        st.success("🎉 **Registration Successful!** Please login below to continue.")
        st.info(f"👤 **Customer ID:** {st.session_state.get('new_customer_id', 'N/A')}")
        
        # Clear the registration success flag after showing
        if st.button("✅ I understand, proceed to login", type="primary"):
            st.session_state.registration_success = False
            st.session_state.auth_tab = 'login'
            st.rerun()
    
    # Determine which tab to show
    default_tab = 0  # Login tab
    if st.session_state.get('auth_tab') == 'register':
        default_tab = 1
    elif st.session_state.get('registration_success', False):
        default_tab = 0  # Force login tab after registration
    
    # Authentication tabs
    tab1, tab2 = st.tabs(["🔐 Login", "📝 Register"])
    
    with tab1:
        # Show welcome message for new users
        if st.session_state.get('registration_success', False):
            st.info(f"👋 Welcome {st.session_state.get('new_customer_name', '')}! Please login with your new account.")
        
        show_login_form()
    
    with tab2:
        show_registration_form()
    
    # Footer
    st.markdown("---")
    st.markdown("""
    <div style='text-align: center; color: gray;'>
        🔒 Secure Banking Portal | 📞 24/7 Support: 1800-XXX-XXXX | 💡 AI-Powered KYC Verification
    </div>
    """, unsafe_allow_html=True)