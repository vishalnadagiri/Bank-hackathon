#!/usr/bin/env python3
"""
Advanced Image Preprocessing Service for Enhanced OCR Accuracy
Implements ML-based image enhancement techniques for better document extraction
"""

import cv2
import numpy as np
import logging
from typing import Tuple, Dict, Any, Optional
from PIL import Image, ImageEnhance, ImageFilter
import pytesseract
from scipy import ndimage
import os

class ImagePreprocessingService:
    """
    Advanced image preprocessing for OCR enhancement
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # OCR configuration for better accuracy
        self.tesseract_config = {
            'standard': '--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz /',
            'digits_only': '--oem 3 --psm 8 -c tessedit_char_whitelist=0123456789 ',
            'alpha_only': '--oem 3 --psm 8 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ',
            'aadhaar_id': '--oem 3 --psm 8 -c tessedit_char_whitelist=0123456789 ',
            'date': '--oem 3 --psm 8 -c tessedit_char_whitelist=0123456789/',
            'name': '--oem 3 --psm 8 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz .'
        }
        
        # Preprocessing parameters
        self.enhancement_params = {
            'contrast_factor': 1.5,
            'brightness_factor': 1.2,
            'sharpness_factor': 2.0,
            'noise_reduction_kernel': 3,
            'morphology_kernel': (2, 2),
            'gaussian_blur_sigma': 0.5
        }

    def preprocess_for_ocr(self, image_path: str, field_type: str = 'standard') -> Dict[str, Any]:
        """
        Main preprocessing function optimized for specific field types
        
        Args:
            image_path: Path to the input image
            field_type: Type of field being extracted (name, id_number, date_of_birth, etc.)
            
        Returns:
            Dictionary containing processed images and metadata
        """
        result = {
            'original_image': None,
            'processed_image': None,
            'enhancement_applied': [],
            'quality_metrics': {},
            'suggested_config': self.tesseract_config.get(field_type, self.tesseract_config['standard']),
            'success': False
        }
        
        try:
            # Load image
            original_image = cv2.imread(image_path)
            if original_image is None:
                raise ValueError(f"Could not load image: {image_path}")
            
            result['original_image'] = original_image
            
            # Apply preprocessing pipeline
            processed_image = self._apply_preprocessing_pipeline(original_image, field_type)
            result['processed_image'] = processed_image
            
            # Calculate quality metrics
            result['quality_metrics'] = self._calculate_image_quality(original_image, processed_image)
            
            # Determine best OCR configuration
            result['suggested_config'] = self._optimize_ocr_config(processed_image, field_type)
            
            result['success'] = True
            
        except Exception as e:
            self.logger.error(f"Error in image preprocessing: {str(e)}")
            result['error'] = str(e)
            
        return result

    def _apply_preprocessing_pipeline(self, image: np.ndarray, field_type: str) -> np.ndarray:
        """
        Apply comprehensive preprocessing pipeline
        """
        # Convert to RGB if needed
        if len(image.shape) == 3:
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        else:
            image_rgb = image
            
        # Step 1: Rotation correction
        corrected_image = self._correct_rotation(image_rgb)
        
        # Step 2: Noise reduction
        denoised_image = self._reduce_noise(corrected_image)
        
        # Step 3: Contrast and brightness enhancement
        enhanced_image = self._enhance_contrast_brightness(denoised_image)
        
        # Step 4: Sharpening
        sharpened_image = self._apply_sharpening(enhanced_image)
        
        # Step 5: Binarization (convert to black and white)
        binary_image = self._apply_adaptive_binarization(sharpened_image)
        
        # Step 6: Morphological operations
        morphed_image = self._apply_morphological_operations(binary_image, field_type)
        
        # Step 7: Final cleanup
        final_image = self._final_cleanup(morphed_image)
        
        return final_image

    def _correct_rotation(self, image: np.ndarray) -> np.ndarray:
        """
        Detect and correct image rotation using Hough transform
        """
        try:
            # Convert to grayscale
            gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY) if len(image.shape) == 3 else image
            
            # Edge detection
            edges = cv2.Canny(gray, 50, 150, apertureSize=3)
            
            # Hough line detection
            lines = cv2.HoughLines(edges, 1, np.pi/180, threshold=100)
            
            if lines is not None:
                angles = []
                for line in lines[:10]:  # Use only first 10 lines
                    rho, theta = line[0]
                    angle = theta * 180 / np.pi
                    # Convert to rotation angle
                    if angle > 90:
                        angle = angle - 180
                    angles.append(angle)
                
                # Calculate median angle for rotation
                if angles:
                    rotation_angle = np.median(angles)
                    if abs(rotation_angle) > 0.5:  # Only rotate if significant
                        # Rotate image
                        (h, w) = image.shape[:2]
                        center = (w // 2, h // 2)
                        rotation_matrix = cv2.getRotationMatrix2D(center, rotation_angle, 1.0)
                        rotated = cv2.warpAffine(image, rotation_matrix, (w, h), 
                                               flags=cv2.INTER_CUBIC, 
                                               borderMode=cv2.BORDER_REPLICATE)
                        return rotated
                        
        except Exception as e:
            self.logger.warning(f"Rotation correction failed: {str(e)}")
            
        return image

    def _reduce_noise(self, image: np.ndarray) -> np.ndarray:
        """
        Apply noise reduction techniques
        """
        # Convert to PIL for better filtering
        pil_image = Image.fromarray(image)
        
        # Apply Gaussian blur for noise reduction
        blurred = pil_image.filter(ImageFilter.GaussianBlur(radius=0.5))
        
        # Apply median filter for salt-and-pepper noise
        median_filtered = cv2.medianBlur(np.array(blurred), 3)
        
        # Non-local means denoising for better quality
        if len(image.shape) == 3:
            denoised = cv2.fastNlMeansDenoisingColored(median_filtered, None, 10, 10, 7, 21)
        else:
            denoised = cv2.fastNlMeansDenoising(median_filtered, None, 10, 7, 21)
            
        return denoised

    def _enhance_contrast_brightness(self, image: np.ndarray) -> np.ndarray:
        """
        Enhance contrast and brightness using adaptive methods
        """
        # Convert to PIL for enhancement
        pil_image = Image.fromarray(image)
        
        # Auto-contrast enhancement
        enhancer = ImageEnhance.Contrast(pil_image)
        contrasted = enhancer.enhance(self.enhancement_params['contrast_factor'])
        
        # Brightness enhancement
        enhancer = ImageEnhance.Brightness(contrasted)
        brightened = enhancer.enhance(self.enhancement_params['brightness_factor'])
        
        # Convert back to numpy array
        enhanced_array = np.array(brightened)
        
        # Apply CLAHE (Contrast Limited Adaptive Histogram Equalization)
        if len(enhanced_array.shape) == 3:
            # Convert to LAB color space
            lab = cv2.cvtColor(enhanced_array, cv2.COLOR_RGB2LAB)
            l, a, b = cv2.split(lab)
            
            # Apply CLAHE to L channel
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
            l = clahe.apply(l)
            
            # Merge channels back
            enhanced_array = cv2.merge([l, a, b])
            enhanced_array = cv2.cvtColor(enhanced_array, cv2.COLOR_LAB2RGB)
        else:
            # Apply CLAHE directly to grayscale
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
            enhanced_array = clahe.apply(enhanced_array)
            
        return enhanced_array

    def _apply_sharpening(self, image: np.ndarray) -> np.ndarray:
        """
        Apply sharpening filter to enhance text edges
        """
        # Convert to PIL for sharpening
        pil_image = Image.fromarray(image)
        enhancer = ImageEnhance.Sharpness(pil_image)
        sharpened = enhancer.enhance(self.enhancement_params['sharpness_factor'])
        
        # Convert back to numpy and apply unsharp masking
        sharpened_array = np.array(sharpened)
        
        # Create unsharp mask
        if len(sharpened_array.shape) == 3:
            blurred = cv2.GaussianBlur(sharpened_array, (0, 0), 2)
        else:
            blurred = cv2.GaussianBlur(sharpened_array, (0, 0), 2)
            
        unsharp_mask = cv2.addWeighted(sharpened_array, 1.5, blurred, -0.5, 0)
        
        return unsharp_mask

    def _apply_adaptive_binarization(self, image: np.ndarray) -> np.ndarray:
        """
        Apply adaptive binarization for better text extraction
        """
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        else:
            gray = image
            
        # Try multiple binarization methods and choose the best
        methods = []
        
        # Method 1: Adaptive threshold (Gaussian)
        adaptive_gaussian = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
        )
        methods.append(('adaptive_gaussian', adaptive_gaussian))
        
        # Method 2: Adaptive threshold (Mean)
        adaptive_mean = cv2.adaptiveThreshold(
            gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 11, 2
        )
        methods.append(('adaptive_mean', adaptive_mean))
        
        # Method 3: Otsu's threshold
        _, otsu = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        methods.append(('otsu', otsu))
        
        # Method 4: Triangle threshold
        _, triangle = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_TRIANGLE)
        methods.append(('triangle', triangle))
        
        # Choose the best method based on edge preservation
        best_method = self._select_best_binarization(methods, gray)
        
        return best_method

    def _select_best_binarization(self, methods, original_gray):
        """
        Select the best binarization method based on edge preservation
        """
        best_score = 0
        best_image = methods[0][1]
        
        # Calculate Canny edges in original
        original_edges = cv2.Canny(original_gray, 50, 150)
        original_edge_count = np.sum(original_edges > 0)
        
        for method_name, binary_image in methods:
            # Calculate edges in binary image
            binary_edges = cv2.Canny(binary_image, 50, 150)
            binary_edge_count = np.sum(binary_edges > 0)
            
            # Score based on edge preservation
            if original_edge_count > 0:
                edge_ratio = binary_edge_count / original_edge_count
                # Prefer methods that preserve 60-120% of original edges
                if 0.6 <= edge_ratio <= 1.2:
                    score = 1.0 - abs(edge_ratio - 1.0)
                else:
                    score = 0.1
            else:
                score = 0.5
                
            if score > best_score:
                best_score = score
                best_image = binary_image
                
        return best_image

    def _apply_morphological_operations(self, image: np.ndarray, field_type: str) -> np.ndarray:
        """
        Apply morphological operations based on field type
        """
        # Define kernels for different operations
        kernel_small = np.ones((2, 2), np.uint8)
        kernel_medium = np.ones((3, 3), np.uint8)
        
        if field_type in ['name', 'address']:
            # For text fields, use closing to connect broken characters
            processed = cv2.morphologyEx(image, cv2.MORPH_CLOSE, kernel_small)
            # Remove small noise
            processed = cv2.morphologyEx(processed, cv2.MORPH_OPEN, kernel_small)
            
        elif field_type in ['id_number', 'date_of_birth']:
            # For ID and date fields, emphasize on cleaning
            processed = cv2.morphologyEx(image, cv2.MORPH_OPEN, kernel_small)
            processed = cv2.morphologyEx(processed, cv2.MORPH_CLOSE, kernel_medium)
            
        else:
            # Default processing
            processed = cv2.morphologyEx(image, cv2.MORPH_CLOSE, kernel_small)
            
        return processed

    def _final_cleanup(self, image: np.ndarray) -> np.ndarray:
        """
        Final cleanup and optimization
        """
        # Remove very small components (noise)
        num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(image, connectivity=8)
        
        # Create mask for components to keep (remove very small ones)
        min_size = 20  # Minimum component size
        mask = np.zeros(labels.shape, dtype=np.uint8)
        
        for i in range(1, num_labels):  # Skip background (label 0)
            if stats[i, cv2.CC_STAT_AREA] >= min_size:
                mask[labels == i] = 255
                
        # Apply the mask
        cleaned = cv2.bitwise_and(image, mask)
        
        # Final smoothing
        cleaned = cv2.medianBlur(cleaned, 3)
        
        return cleaned

    def _calculate_image_quality(self, original: np.ndarray, processed: np.ndarray) -> Dict[str, float]:
        """
        Calculate various image quality metrics
        """
        metrics = {}
        
        try:
            # Convert to grayscale if needed
            if len(original.shape) == 3:
                orig_gray = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
            else:
                orig_gray = original
                
            if len(processed.shape) == 3:
                proc_gray = cv2.cvtColor(processed, cv2.COLOR_BGR2GRAY)
            else:
                proc_gray = processed
            
            # Contrast measure (standard deviation of pixel intensities)
            metrics['original_contrast'] = float(np.std(orig_gray))
            metrics['processed_contrast'] = float(np.std(proc_gray))
            metrics['contrast_improvement'] = metrics['processed_contrast'] / metrics['original_contrast'] if metrics['original_contrast'] > 0 else 1.0
            
            # Sharpness measure (variance of Laplacian)
            orig_laplacian = cv2.Laplacian(orig_gray, cv2.CV_64F)
            proc_laplacian = cv2.Laplacian(proc_gray, cv2.CV_64F)
            metrics['original_sharpness'] = float(orig_laplacian.var())
            metrics['processed_sharpness'] = float(proc_laplacian.var())
            metrics['sharpness_improvement'] = metrics['processed_sharpness'] / metrics['original_sharpness'] if metrics['original_sharpness'] > 0 else 1.0
            
            # Edge density
            orig_edges = cv2.Canny(orig_gray, 50, 150)
            proc_edges = cv2.Canny(proc_gray, 50, 150)
            metrics['original_edge_density'] = float(np.sum(orig_edges > 0) / orig_edges.size)
            metrics['processed_edge_density'] = float(np.sum(proc_edges > 0) / proc_edges.size)
            
            # Overall quality score (0-100)
            contrast_score = min(metrics['contrast_improvement'] * 25, 40)
            sharpness_score = min(metrics['sharpness_improvement'] * 25, 40)
            edge_score = metrics['processed_edge_density'] * 100 * 0.2
            metrics['overall_quality_score'] = contrast_score + sharpness_score + edge_score
            
        except Exception as e:
            self.logger.error(f"Error calculating quality metrics: {str(e)}")
            metrics['error'] = str(e)
            
        return metrics

    def _optimize_ocr_config(self, image: np.ndarray, field_type: str) -> str:
        """
        Dynamically optimize OCR configuration based on image characteristics
        """
        base_config = self.tesseract_config.get(field_type, self.tesseract_config['standard'])
        
        # Analyze image characteristics
        height, width = image.shape[:2]
        
        # For small images, use different PSM
        if height < 50 or width < 100:
            base_config = base_config.replace('--psm 6', '--psm 8')
            base_config = base_config.replace('--psm 3', '--psm 8')
            
        # For very wide images (likely single line), use PSM 7
        if width > height * 4:
            base_config = base_config.replace('--psm 6', '--psm 7')
            base_config = base_config.replace('--psm 3', '--psm 7')
            
        return base_config

    def extract_text_with_preprocessing(self, image_path: str, field_type: str = 'standard') -> Dict[str, Any]:
        """
        Complete pipeline: preprocess image and extract text
        """
        result = {
            'extracted_text': '',
            'confidence': 0.0,
            'preprocessing_success': False,
            'extraction_success': False,
            'quality_metrics': {},
            'used_config': ''
        }
        
        try:
            # Preprocess image
            preprocess_result = self.preprocess_for_ocr(image_path, field_type)
            
            if preprocess_result['success']:
                result['preprocessing_success'] = True
                result['quality_metrics'] = preprocess_result['quality_metrics']
                result['used_config'] = preprocess_result['suggested_config']
                
                # Extract text using optimized image
                processed_image = preprocess_result['processed_image']
                
                # Save processed image temporarily for Tesseract
                temp_path = f"tmp_processed_{os.path.basename(image_path)}"
                cv2.imwrite(temp_path, processed_image)
                
                try:
                    # Extract text with confidence
                    data = pytesseract.image_to_data(temp_path, config=result['used_config'], output_type=pytesseract.Output.DICT)
                    
                    # Combine text and calculate average confidence
                    words = []
                    confidences = []
                    
                    for i in range(len(data['text'])):
                        if int(data['conf'][i]) > 30:  # Filter low confidence words
                            text = data['text'][i].strip()
                            if text:
                                words.append(text)
                                confidences.append(int(data['conf'][i]))
                    
                    if words:
                        result['extracted_text'] = ' '.join(words)
                        result['confidence'] = sum(confidences) / len(confidences)
                        result['extraction_success'] = True
                        
                finally:
                    # Clean up temporary file
                    if os.path.exists(temp_path):
                        os.remove(temp_path)
                        
        except Exception as e:
            self.logger.error(f"Error in text extraction pipeline: {str(e)}")
            result['error'] = str(e)
            
        return result

# Example usage and testing
# Note: safe for production packaging; requires explicit image path.

def test_preprocessing_service(image_path: str):
    """Test the preprocessing service with a provided image path."""
    preprocessor = ImagePreprocessingService()

    if os.path.exists(image_path):
        field_types = ['name', 'id_number', 'date_of_birth', 'standard']

        for field_type in field_types:
            print(f"\n=== Testing {field_type} field ===")
            result = preprocessor.extract_text_with_preprocessing(image_path, field_type)

            print(f"Extraction Success: {result['extraction_success']}")
            print(f"Extracted Text: '{result['extracted_text']}'")
            print(f"Confidence: {result['confidence']:.1f}%")
            print(f"Quality Score: {result['quality_metrics'].get('overall_quality_score', 0):.1f}")
    else:
        print(f"Test image not found: {image_path}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python -m services.image_preprocessing_service <path-to-image>")
        raise SystemExit(2)

    test_preprocessing_service(sys.argv[1])