#!/usr/bin/env python3
"""
Admin Access Script - Enables admin panel access
Run this to enable admin features in the application
"""

import streamlit as st

def enable_admin_access():
    """Enable admin access in the session"""
    if 'show_admin_access' not in st.session_state:
        st.session_state.show_admin_access = False
    
    st.title("🔑 Admin Access")
    
    if not st.session_state.show_admin_access:
        st.info("Enter admin credentials to enable admin panel access")
        
        with st.form("admin_enable"):
            username = st.text_input("Username:")
            password = st.text_input("Password:", type="password")
            enable = st.form_submit_button("Enable Admin Access")
            
            if enable and username == "admin" and password == "kyc_admin_2024":
                st.session_state.show_admin_access = True
                st.success("✅ Admin access enabled! Admin Panel button now available in sidebar.")
                st.info("Go back to the main application to access admin features.")
            elif enable:
                st.error("❌ Invalid credentials")
    else:
        st.success("✅ Admin access is already enabled!")
        st.info("Admin Panel button is available in the main application sidebar.")
        
        if st.button("🔒 Disable Admin Access"):
            st.session_state.show_admin_access = False
            st.info("Admin access disabled.")

if __name__ == "__main__":
    enable_admin_access()