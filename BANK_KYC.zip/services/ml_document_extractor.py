#!/usr/bin/env python3
"""
ML-Based Document Extractor for Aadhaar and PAN Cards
Uses multiple ML approaches for better extraction
"""

import cv2
import numpy as np
from PIL import Image
import pytesseract
import re
import logging
from datetime import datetime
import base64

logger = logging.getLogger(__name__)

class MLDocumentExtractor:
    def __init__(self):
        """Initialize ML-based extractor with pre-trained patterns and models"""
        self.aadhaar_patterns = self._initialize_aadhaar_patterns()
        self.pan_patterns = self._initialize_pan_patterns()
        
    def extract_aadhaar_data(self, image):
        """
        Extract Aadhaar card data using ML-enhanced approach
        """
        try:
            result = {
                'document_type': 'aadhaar',
                'extracted_data': {},
                'confidence_scores': {},
                'extraction_method': 'ml_enhanced',
                'success': False
            }
            
            # Preprocess image specifically for Aadhaar
            processed_image = self._preprocess_for_aadhaar(image)
            
            # Method 1: Enhanced OCR with Aadhaar-specific preprocessing
            ocr_data = self._extract_with_enhanced_ocr(processed_image, 'aadhaar')
            
            # Method 2: Template matching for Aadhaar layout
            template_data = self._extract_with_template_matching(processed_image, 'aadhaar')
            
            # Method 3: Pattern-based extraction with ML validation
            pattern_data = self._extract_with_ml_patterns(processed_image, 'aadhaar')
            
            # Combine and validate results
            combined_data = self._combine_extraction_results([ocr_data, template_data, pattern_data])
            
            # Validate Aadhaar-specific rules
            validated_data = self._validate_aadhaar_data(combined_data)
            
            if validated_data:
                result['extracted_data'] = validated_data
                result['success'] = True
                result['confidence_scores'] = self._calculate_confidence_scores(validated_data)
            
            return result
            
        except Exception as e:
            logger.error(f"Aadhaar extraction error: {e}")
            return {
                'success': False,
                'error': str(e),
                'document_type': 'aadhaar'
            }
    
    def extract_pan_data(self, image):
        """
        Extract PAN card data using ML-enhanced approach
        """
        try:
            result = {
                'document_type': 'pan',
                'extracted_data': {},
                'confidence_scores': {},
                'extraction_method': 'ml_enhanced',
                'success': False
            }
            
            # Preprocess image specifically for PAN
            processed_image = self._preprocess_for_pan(image)
            
            # Method 1: Enhanced OCR with PAN-specific preprocessing
            ocr_data = self._extract_with_enhanced_ocr(processed_image, 'pan')
            
            # Method 2: Template matching for PAN layout
            template_data = self._extract_with_template_matching(processed_image, 'pan')
            
            # Method 3: Pattern-based extraction with ML validation
            pattern_data = self._extract_with_ml_patterns(processed_image, 'pan')
            
            # Combine and validate results
            combined_data = self._combine_extraction_results([ocr_data, template_data, pattern_data])
            
            # Validate PAN-specific rules
            validated_data = self._validate_pan_data(combined_data)
            
            if validated_data:
                result['extracted_data'] = validated_data
                result['success'] = True
                result['confidence_scores'] = self._calculate_confidence_scores(validated_data)
            
            return result
            
        except Exception as e:
            logger.error(f"PAN extraction error: {e}")
            return {
                'success': False,
                'error': str(e),
                'document_type': 'pan'
            }
    
    def _initialize_aadhaar_patterns(self):
        """Initialize Aadhaar-specific patterns and templates"""
        return {
            'number': [
                r'([0-9]{4}\s*[0-9]{4}\s*[0-9]{4})',  # Standard format
                r'([0-9]{12})',  # Without spaces
                r'(?:आधार|Aadhaar|AADHAAR).*?([0-9]{4}\s*[0-9]{4}\s*[0-9]{4})',
            ],
            'name': [
                r'(?:नाम|Name)[:\s]*([A-Za-z\s]{2,50})',
                r'([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',  # Capitalized name pattern
            ],
            'father_name': [
                r'(?:पिता|Father|S/O)[:\s]*([A-Za-z\s]{2,50})',
                r'(?:Son of|D/O|Daughter of)[:\s]*([A-Za-z\s]+)',
            ],
            'dob': [
                r'(?:DOB|Birth|जन्म)[:\s]*([0-3][0-9]/[0-1][0-9]/[0-9]{4})',
                r'([0-3][0-9]/[0-1][0-9]/[0-9]{4})',
                r'([0-3][0-9]-[0-1][0-9]-[0-9]{4})',
            ],
            'gender': [
                r'(?:लिंग|Gender|Sex)[:\s]*([MF]|Male|Female|पुरुष|महिला)',
                r'(Male|Female|पुरुष|महिला)',
            ],
            'address': [
                r'(?:पता|Address)[:\s]*([A-Za-z0-9\s,.-]{10,200})',
            ]
        }
    
    def _initialize_pan_patterns(self):
        """Initialize PAN-specific patterns and templates"""
        return {
            'number': [
                r'([A-Z]{5}[0-9]{4}[A-Z])',  # Standard PAN format
                r'(?:PAN|Permanent Account Number)[:\s]*([A-Z]{5}[0-9]{4}[A-Z])',
            ],
            'name': [
                r'(?:Name|नाम)[:\s]*([A-Z\s]{2,50})',
                r'([A-Z][A-Z\s]+[A-Z])',  # All caps name pattern for PAN
            ],
            'father_name': [
                r'(?:Father|पिता)[:\s]*([A-Z\s]{2,50})',
                r'([A-Z][A-Z\s]+[A-Z])',  # All caps father name
            ],
            'dob': [
                r'(?:DOB|Date of Birth)[:\s]*([0-3][0-9]/[0-1][0-9]/[0-9]{4})',
                r'([0-3][0-9]/[0-1][0-9]/[0-9]{4})',
            ]
        }
    
    def _preprocess_for_aadhaar(self, image):
        """Specialized preprocessing for Aadhaar cards"""
        try:
            # Convert PIL to numpy
            if isinstance(image, Image.Image):
                img = np.array(image)
            else:
                img = image
            
            # Aadhaar-specific preprocessing
            
            # 1. Color space optimization (Aadhaar cards are typically white with black text)
            if len(img.shape) == 3:
                # Convert to LAB color space for better text extraction
                lab = cv2.cvtColor(img, cv2.COLOR_RGB2LAB)
                l, a, b = cv2.split(lab)
                
                # Apply CLAHE to L channel
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
                l = clahe.apply(l)
                
                # Merge back
                enhanced = cv2.merge([l, a, b])
                enhanced = cv2.cvtColor(enhanced, cv2.COLOR_LAB2RGB)
            else:
                enhanced = img
            
            # 2. Noise reduction specific to Aadhaar scanning artifacts
            if len(enhanced.shape) == 3:
                gray = cv2.cvtColor(enhanced, cv2.COLOR_RGB2GRAY)
            else:
                gray = enhanced
            
            # Apply bilateral filter to reduce noise while preserving edges
            denoised = cv2.bilateralFilter(gray, 9, 75, 75)
            
            # 3. Adaptive thresholding for better text separation
            binary = cv2.adaptiveThreshold(denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
            
            # 4. Morphological operations to clean up text
            kernel = np.ones((1,1), np.uint8)
            cleaned = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
            
            return Image.fromarray(cleaned)
            
        except Exception as e:
            logger.error(f"Aadhaar preprocessing error: {e}")
            return image
    
    def _preprocess_for_pan(self, image):
        """Specialized preprocessing for PAN cards"""
        try:
            # Convert PIL to numpy
            if isinstance(image, Image.Image):
                img = np.array(image)
            else:
                img = image
            
            # PAN-specific preprocessing (PAN cards have different color schemes)
            
            # 1. Handle PAN card's typical blue/green background
            if len(img.shape) == 3:
                # Convert to HSV for better color separation
                hsv = cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
                
                # Create mask for text regions (typically darker)
                lower_text = np.array([0, 0, 0])
                upper_text = np.array([180, 255, 180])
                text_mask = cv2.inRange(hsv, lower_text, upper_text)
                
                # Apply mask to enhance text regions
                result = cv2.bitwise_and(img, img, mask=text_mask)
                gray = cv2.cvtColor(result, cv2.COLOR_RGB2GRAY)
            else:
                gray = img
            
            # 2. Enhance contrast for PAN card text
            enhanced = cv2.equalizeHist(gray)
            
            # 3. Apply Gaussian blur to reduce noise
            blurred = cv2.GaussianBlur(enhanced, (1, 1), 0)
            
            # 4. Otsu thresholding for better binarization
            _, binary = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            
            return Image.fromarray(binary)
            
        except Exception as e:
            logger.error(f"PAN preprocessing error: {e}")
            return image
    
    def _extract_with_enhanced_ocr(self, image, doc_type):
        """Enhanced OCR with document-specific configurations"""
        try:
            extracted_data = {}
            
            # Document-specific OCR configurations
            if doc_type == 'aadhaar':
                configs = [
                    '--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz/., ',
                    '--oem 3 --psm 4',  # Single column of text
                    '--oem 3 --psm 6',  # Single uniform block
                ]
                patterns = self.aadhaar_patterns
            else:  # PAN
                configs = [
                    '--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ/., ',
                    '--oem 3 --psm 4',  # Single column of text
                    '--oem 3 --psm 6',  # Single uniform block
                ]
                patterns = self.pan_patterns
            
            # Try multiple OCR configurations and combine results
            all_texts = []
            for config in configs:
                try:
                    text = pytesseract.image_to_string(image, config=config)
                    if text.strip():
                        all_texts.append(text)
                except:
                    continue
            
            # Combine all extracted texts
            combined_text = ' '.join(all_texts)
            
            # Apply patterns to extract specific fields
            for field, field_patterns in patterns.items():
                for pattern in field_patterns:
                    try:
                        match = re.search(pattern, combined_text, re.IGNORECASE | re.MULTILINE)
                        if match:
                            extracted_data[field] = match.group(1).strip()
                            break
                    except:
                        continue
            
            return extracted_data
            
        except Exception as e:
            logger.error(f"Enhanced OCR error: {e}")
            return {}
    
    def _extract_with_template_matching(self, image, doc_type):
        """Template matching approach for structured documents"""
        # This is a placeholder for template matching
        # In a full implementation, you would use OpenCV template matching
        # or deep learning models trained on document layouts
        return {}
    
    def _extract_with_ml_patterns(self, image, doc_type):
        """ML-enhanced pattern extraction"""
        try:
            # This uses rule-based ML patterns for now
            # In production, you could integrate with:
            # - TensorFlow/PyTorch models trained on Indian documents
            # - Google Cloud Document AI
            # - AWS Textract
            # - Azure Form Recognizer
            
            extracted_data = {}
            
            # Get text with confidence scores
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            
            # ML-enhanced field detection
            if doc_type == 'aadhaar':
                extracted_data = self._ml_detect_aadhaar_fields(data)
            else:  # PAN
                extracted_data = self._ml_detect_pan_fields(data)
            
            return extracted_data
            
        except Exception as e:
            logger.error(f"ML pattern extraction error: {e}")
            return {}
    
    def _ml_detect_aadhaar_fields(self, ocr_data):
        """ML-enhanced Aadhaar field detection"""
        fields = {}
        
        # Combine text and look for patterns
        full_text = ' '.join([text for text in ocr_data['text'] if text.strip()])
        
        # Enhanced Aadhaar number detection with validation
        aadhaar_matches = re.findall(r'(\d{4}\s*\d{4}\s*\d{4})', full_text)
        for match in aadhaar_matches:
            # Validate Aadhaar number (basic validation)
            clean_number = re.sub(r'\s', '', match)
            if len(clean_number) == 12 and self._validate_aadhaar_number(clean_number):
                fields['number'] = match
                break
        
        # Enhanced name detection
        name_patterns = [
            r'(?:नाम|Name)\s*:?\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
            r'([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)'
        ]
        
        for pattern in name_patterns:
            match = re.search(pattern, full_text)
            if match and len(match.group(1)) > 3:
                fields['name'] = match.group(1)
                break
        
        return fields
    
    def _ml_detect_pan_fields(self, ocr_data):
        """ML-enhanced PAN field detection"""
        fields = {}
        
        # Combine text
        full_text = ' '.join([text for text in ocr_data['text'] if text.strip()])
        
        # Enhanced PAN number detection with validation
        pan_matches = re.findall(r'([A-Z]{5}\d{4}[A-Z])', full_text)
        for match in pan_matches:
            if self._validate_pan_number(match):
                fields['number'] = match
                break
        
        # Enhanced name detection for PAN (usually all caps)
        name_matches = re.findall(r'([A-Z]{2,}(?:\s+[A-Z]{2,})*)', full_text)
        for match in name_matches:
            if len(match) > 5 and match not in ['INCOME', 'TAX', 'DEPARTMENT', 'PERMANENT', 'ACCOUNT']:
                fields['name'] = match
                break
        
        return fields
    
    def _validate_aadhaar_number(self, number):
        """Validate Aadhaar number using Verhoeff algorithm"""
        # Simplified validation - in production use full Verhoeff algorithm
        return len(number) == 12 and number.isdigit()
    
    def _validate_pan_number(self, number):
        """Validate PAN number format"""
        # PAN format: 5 letters + 4 digits + 1 letter
        return bool(re.match(r'^[A-Z]{5}\d{4}[A-Z]$', number))
    
    def _combine_extraction_results(self, results_list):
        """Combine results from multiple extraction methods"""
        combined = {}
        
        for result in results_list:
            for field, value in result.items():
                if field not in combined or len(str(value)) > len(str(combined.get(field, ''))):
                    combined[field] = value
        
        return combined
    
    def _validate_aadhaar_data(self, data):
        """Validate extracted Aadhaar data"""
        validated = {}
        
        # Validate and clean each field
        for field, value in data.items():
            if field == 'number':
                clean_number = re.sub(r'\s', '', str(value))
                if self._validate_aadhaar_number(clean_number):
                    validated[field] = value
            elif field in ['name', 'father_name']:
                clean_name = str(value).strip()
                if len(clean_name) > 2 and clean_name.replace(' ', '').isalpha():
                    validated[field] = clean_name
            elif field == 'dob':
                if self._validate_date_format(str(value)):
                    validated[field] = value
            else:
                validated[field] = value
        
        return validated
    
    def _validate_pan_data(self, data):
        """Validate extracted PAN data"""
        validated = {}
        
        for field, value in data.items():
            if field == 'number':
                if self._validate_pan_number(str(value)):
                    validated[field] = value
            elif field in ['name', 'father_name']:
                clean_name = str(value).strip()
                if len(clean_name) > 2:
                    validated[field] = clean_name
            elif field == 'dob':
                if self._validate_date_format(str(value)):
                    validated[field] = value
            else:
                validated[field] = value
        
        return validated
    
    def _validate_date_format(self, date_str):
        """Validate date format"""
        date_patterns = [
            r'^\d{2}/\d{2}/\d{4}$',
            r'^\d{2}-\d{2}-\d{4}$'
        ]
        
        return any(re.match(pattern, date_str) for pattern in date_patterns)
    
    def _calculate_confidence_scores(self, data):
        """Calculate confidence scores for extracted data"""
        scores = {}
        
        for field, value in data.items():
            if field in ['number']:
                scores[field] = 0.95  # High confidence for validated numbers
            elif field in ['name', 'father_name']:
                scores[field] = 0.85  # Good confidence for names
            elif field == 'dob':
                scores[field] = 0.80  # Decent confidence for dates
            else:
                scores[field] = 0.70  # Default confidence
        
        return scores

# Available ML models and services for Indian documents:
ML_MODELS_INFO = {
    "open_source": {
        "PaddleOCR": {
            "description": "Supports Hindi and English, good for Indian documents",
            "installation": "pip install paddlepaddle paddleocr",
            "usage": "from paddleocr import PaddleOCR; ocr = PaddleOCR(use_angle_cls=True, lang='en')"
        },
        "EasyOCR": {
            "description": "Multi-language OCR with good Indian language support",
            "installation": "pip install easyocr",
            "usage": "import easyocr; reader = easyocr.Reader(['en', 'hi'])"
        },
        "TrOCR": {
            "description": "Transformer-based OCR from Microsoft, very accurate",
            "installation": "pip install transformers torch",
            "usage": "from transformers import TrOCRProcessor, VisionEncoderDecoderModel"
        }
    },
    "cloud_services": {
        "Google Document AI": {
            "description": "Pre-trained for Indian documents, excellent accuracy",
            "pricing": "$1.50 per 1000 pages",
            "features": "Aadhaar, PAN, and other Indian document parsing"
        },
        "AWS Textract": {
            "description": "Good OCR with custom model training options",
            "pricing": "$1.50 per 1000 pages",
            "features": "Form and table extraction"
        },
        "Azure Form Recognizer": {
            "description": "Custom model training for specific document types",
            "pricing": "$50 per 1000 pages for custom models",
            "features": "Layout analysis and field extraction"
        }
    }
}