#!/usr/bin/env python3
"""
True Interactive Image Annotation with Click-and-Drag
"""

import streamlit as st
from streamlit_drawable_canvas import st_canvas
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import pytesseract
import json
import pandas as pd

class InteractiveAnnotator:
    def __init__(self):
        self.colors = ['red', 'blue', 'green', 'orange', 'purple', 'brown', 'pink', 'cyan']
    
    def annotate_document_interactive(self, image, fields_to_extract, session_key="interactive"):
        """
        True interactive annotation with drawable canvas
        """
        st.subheader("🎯 Interactive Document Annotation")
        st.markdown("**Draw rectangles around fields you want to extract**")
        
        # Initialize session state
        if f"{session_key}_annotations" not in st.session_state:
            st.session_state[f"{session_key}_annotations"] = []
        
        # Convert PIL image to numpy array
        if isinstance(image, Image.Image):
            img_array = np.array(image)
        else:
            img_array = image
            image = Image.fromarray(img_array)
        
        col1, col2 = st.columns([2, 1])
        
        with col2:
            st.subheader("📋 Field Selection")
            
            # Field selection
            selected_field = st.selectbox(
                "Select field to annotate:",
                ["Select field..."] + fields_to_extract,
                key=f"{session_key}_field_select"
            )
            
            # Drawing controls
            drawing_mode = st.selectbox(
                "Drawing tool:",
                ["rect", "freedraw"],
                index=0,
                key=f"{session_key}_drawing_mode"
            )
            
            stroke_width = st.slider("Stroke width:", 1, 10, 3, key=f"{session_key}_stroke_width")
            
            # Current field color
            field_color = self.colors[len(st.session_state[f"{session_key}_annotations"]) % len(self.colors)]
            st.write(f"**Drawing color:** {field_color}")
            
            # Instructions
            st.info("""
            **How to annotate:**
            1. Select a field type
            2. Draw a rectangle around that field in the document
            3. Click 'Process Annotations' when done
            """)
            
            # Annotation management
            if st.button("🗑️ Clear All", key=f"{session_key}_clear"):
                st.session_state[f"{session_key}_annotations"] = []
                st.rerun()
            
            # Show current annotations
            if st.session_state[f"{session_key}_annotations"]:
                st.subheader("📍 Annotations")
                for i, ann in enumerate(st.session_state[f"{session_key}_annotations"]):
                    with st.expander(f"{ann['field']} - {ann['text'][:20]}..."):
                        st.write(f"**Field:** {ann['field']}")
                        st.write(f"**Text:** {ann['text']}")
                        st.write(f"**Coordinates:** ({ann['x1']}, {ann['y1']}) to ({ann['x2']}, {ann['y2']})")
                        if st.button("Delete", key=f"del_{i}_{session_key}"):
                            st.session_state[f"{session_key}_annotations"].pop(i)
                            st.rerun()
        
        with col1:
            st.subheader("📄 Document - Draw Rectangles")
            
            # Check if streamlit-drawable-canvas is available
            try:
                from streamlit_drawable_canvas import st_canvas
                # Create drawable canvas
                canvas_result = st_canvas(
                    fill_color="rgba(255, 0, 0, 0.1)",  # Transparent red
                    stroke_width=stroke_width,
                    stroke_color=field_color,
                    background_image=image,
                    update_streamlit=True,
                    height=min(image.height, 600),
                    width=min(image.width, 800),
                    drawing_mode=drawing_mode,
                    point_display_radius=0,
                    key=f"{session_key}_canvas",
                )
                
                # Process drawn rectangles
                if canvas_result.json_data is not None and selected_field != "Select field...":
                    objects = canvas_result.json_data["objects"]
                    
                    # Process new rectangles
                    for obj in objects:
                        if obj["type"] == "rect":
                            # Extract rectangle coordinates
                            x1 = int(obj["left"])
                            y1 = int(obj["top"])
                            x2 = int(x1 + obj["width"])
                            y2 = int(y1 + obj["height"])
                            
                            # Check if this annotation already exists
                            exists = any(
                                ann["x1"] == x1 and ann["y1"] == y1 and ann["x2"] == x2 and ann["y2"] == y2
                                for ann in st.session_state[f"{session_key}_annotations"]
                            )
                            
                            if not exists:
                                # Extract text from the selected region
                                extracted_text = self._extract_text_from_region(image, x1, y1, x2, y2)
                                
                                # Add annotation
                                annotation = {
                                    'field': selected_field,
                                    'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                                    'text': extracted_text,
                                    'confidence': 0.9
                                }
                                
                                st.session_state[f"{session_key}_annotations"].append(annotation)
                                st.rerun()
            
            except ImportError:
                st.error("📦 streamlit-drawable-canvas not installed!")
                st.markdown("**Install it with:** `pip install streamlit-drawable-canvas`")
                st.markdown("**Or use the fallback method below:**")
                
                # Fallback to coordinate input method
                self._fallback_annotation_method(image, fields_to_extract, session_key)
        
        # Process and return annotations
        if st.button("✅ Process All Annotations", type="primary", key=f"{session_key}_process"):
            if st.session_state[f"{session_key}_annotations"]:
                return self._process_annotations(st.session_state[f"{session_key}_annotations"])
            else:
                st.error("No annotations to process!")
        
        return None
    
    def _fallback_annotation_method(self, image, fields_to_extract, session_key):
        """Fallback annotation method using coordinate inputs"""
        st.subheader("📍 Manual Coordinate Selection")
        st.image(image, use_column_width=True)
        
        # Field and coordinate inputs
        selected_field = st.selectbox(
            "Field to annotate:",
            ["Select field..."] + fields_to_extract,
            key=f"{session_key}_fallback_field"
        )
        
        if selected_field != "Select field...":
            col_coord1, col_coord2 = st.columns(2)
            
            with col_coord1:
                x1 = st.number_input("Top-left X", min_value=0, max_value=image.width, value=0, key=f"fb_x1_{session_key}")
                y1 = st.number_input("Top-left Y", min_value=0, max_value=image.height, value=0, key=f"fb_y1_{session_key}")
            
            with col_coord2:
                x2 = st.number_input("Bottom-right X", min_value=0, max_value=image.width, value=100, key=f"fb_x2_{session_key}")
                y2 = st.number_input("Bottom-right Y", min_value=0, max_value=image.height, value=30, key=f"fb_y2_{session_key}")
            
            if st.button(f"📍 Add {selected_field}", key=f"fb_add_{session_key}"):
                extracted_text = self._extract_text_from_region(image, x1, y1, x2, y2)
                
                annotation = {
                    'field': selected_field,
                    'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                    'text': extracted_text,
                    'confidence': 0.8
                }
                
                st.session_state[f"{session_key}_annotations"].append(annotation)
                st.success(f"Added {selected_field}: '{extracted_text}'")
                st.rerun()
    
    def smart_auto_annotate(self, image, fields_to_extract):
        """Smart auto-annotation that finds and annotates fields automatically"""
        st.subheader("🤖 Smart Auto-Annotation")
        
        if st.button("🔍 Auto-Detect All Fields", type="secondary"):
            with st.spinner("Detecting fields automatically..."):
                auto_annotations = self._smart_field_detection(image, fields_to_extract)
                
                if auto_annotations:
                    # Display results in a nice format
                    st.success(f"✅ Found {len(auto_annotations)} fields!")
                    
                    # Create a DataFrame for better display
                    df_data = []
                    for ann in auto_annotations:
                        df_data.append({
                            'Field': ann['field'],
                            'Text': ann['text'][:30] + "..." if len(ann['text']) > 30 else ann['text'],
                            'Confidence': f"{ann['confidence']*100:.0f}%",
                            'Position': f"({ann['x1']}, {ann['y1']})"
                        })
                    
                    df = pd.DataFrame(df_data)
                    st.dataframe(df, use_container_width=True)
                    
                    # Option to accept auto-annotations
                    if st.button("✅ Accept Auto-Annotations", type="primary"):
                        return self._process_annotations(auto_annotations)
                
                else:
                    st.warning("⚠️ No fields detected automatically. Try manual annotation.")
        
        return None
    
    def _extract_text_from_region(self, image, x1, y1, x2, y2):
        """Extract text from a specific region of the image"""
        try:
            # Convert PIL to numpy if needed
            if isinstance(image, Image.Image):
                img_array = np.array(image)
            else:
                img_array = image
            
            # Ensure coordinates are within bounds
            h, w = img_array.shape[:2]
            x1, y1, x2, y2 = max(0, x1), max(0, y1), min(w, x2), min(h, y2)
            
            # Crop region
            region = img_array[y1:y2, x1:x2]
            
            if region.size == 0:
                return "Invalid region"
            
            # Convert back to PIL for OCR
            region_pil = Image.fromarray(region)
            
            # Extract text with different configurations
            configs = [
                '--psm 8',  # Single word
                '--psm 7',  # Single text line
                '--psm 6',  # Single uniform block
                '--psm 13'  # Raw line
            ]
            
            best_text = ""
            for config in configs:
                try:
                    text = pytesseract.image_to_string(region_pil, config=config).strip()
                    if len(text) > len(best_text):
                        best_text = text
                except:
                    continue
            
            return best_text if best_text else "No text detected"
            
        except Exception as e:
            return f"Extraction error: {str(e)}"
    
    def _smart_field_detection(self, image, fields_to_extract):
        """Smart detection of fields using enhanced OCR and pattern matching"""
        try:
            # Extract text with bounding boxes
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            
            # Enhanced field patterns
            patterns = {
                'name': [
                    r'(?:Name|NAME)[:\s]*([A-Za-z\s\.]{3,40})',
                    r'([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)'
                ],
                'employee_id': [
                    r'(?:Employee|EMP)[:\s]*(?:ID|No)[:\s]*([A-Z0-9]{3,15})',
                    r'(EMP[0-9]{3,10})'
                ],
                'id_number': [
                    r'(?:ID|Card)[:\s]*(?:No|Number)[:\s]*([A-Z0-9]{6,20})',
                    r'([A-Z]{5}[0-9]{4}[A-Z])',
                    r'([0-9]{12})'
                ],
                'department': [
                    r'(?:Department|Dept)[:\s]*([A-Za-z\s]{3,25})',
                    r'(ENGINEERING|MARKETING|FINANCE|HR|SALES|IT)'
                ],
                'designation': [
                    r'(?:Designation|Position)[:\s]*([A-Za-z\s]{3,30})',
                    r'(MANAGER|ENGINEER|ANALYST|EXECUTIVE|DIRECTOR)'
                ],
                'date_of_birth': [
                    r'(?:DOB|Birth)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})'
                ],
                'gender': [
                    r'(?:Gender|Sex)[:\s]*([MF]|Male|Female)'
                ]
            }
            
            full_text = pytesseract.image_to_string(image)
            annotations = []
            
            for field in fields_to_extract:
                if field in patterns:
                    for pattern in patterns[field]:
                        import re
                        match = re.search(pattern, full_text, re.IGNORECASE)
                        if match:
                            matched_text = match.group(1) if len(match.groups()) > 0 else match.group(0)
                            
                            # Find location using OCR data
                            location = self._find_text_location_enhanced(matched_text, data, image.size)
                            
                            if location:
                                annotations.append({
                                    'field': field,
                                    'text': matched_text.strip(),
                                    'x1': location['x1'],
                                    'y1': location['y1'],
                                    'x2': location['x2'],
                                    'y2': location['y2'],
                                    'confidence': 0.8
                                })
                                break
            
            return annotations
            
        except Exception as e:
            st.error(f"Auto-detection error: {e}")
            return []
    
    def _find_text_location_enhanced(self, text, ocr_data, image_size):
        """Find text location with improved accuracy"""
        try:
            text_words = text.lower().split()
            if not text_words:
                return None
            
            target_word = text_words[0]
            
            # Find matching words in OCR data
            for i, word in enumerate(ocr_data['text']):
                if word.lower().strip() == target_word and int(ocr_data['conf'][i]) > 30:
                    x = int(ocr_data['left'][i])
                    y = int(ocr_data['top'][i])
                    w = int(ocr_data['width'][i])
                    h = int(ocr_data['height'][i])
                    
                    # Expand region for full text
                    expansion_factor = len(' '.join(text_words)) / len(target_word)
                    expanded_w = int(w * expansion_factor * 1.2)
                    
                    return {
                        'x1': max(0, x - 10),
                        'y1': max(0, y - 5),
                        'x2': min(image_size[0], x + expanded_w + 10),
                        'y2': min(image_size[1], y + h + 5)
                    }
            
            return None
            
        except Exception as e:
            return None
    
    def _process_annotations(self, annotations):
        """Process and return annotation data"""
        if not annotations:
            return None
        
        training_data = {}
        for annotation in annotations:
            field_name = annotation['field']
            training_data[field_name] = {
                'value': annotation['text'],
                'coordinates': {
                    'x1': annotation['x1'],
                    'y1': annotation['y1'],
                    'x2': annotation['x2'],
                    'y2': annotation['y2']
                },
                'confidence': annotation['confidence']
            }
        
        return {
            'success': True,
            'training_data': training_data,
            'annotation_count': len(annotations)
        }