#!/usr/bin/env python3
"""
Simple Annotation System - No External Dependencies
Works with any Streamlit version
"""

import streamlit as st
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import pytesseract
import json
import pandas as pd

class SimpleAnnotator:
    def __init__(self):
        self.colors = ['red', 'blue', 'green', 'orange', 'purple', 'brown', 'pink', 'cyan']
    
    def annotate_document_simple(self, image, fields_to_extract, session_key="simple"):
        """
        Simple annotation system using coordinate inputs and smart detection
        """
        st.subheader("🎯 Document Field Annotation")
        
        # Initialize session state
        if f"{session_key}_annotations" not in st.session_state:
            st.session_state[f"{session_key}_annotations"] = []
        
        # Convert image if needed
        if isinstance(image, Image.Image):
            display_image = image.copy()
        else:
            display_image = Image.fromarray(image)
            image = Image.fromarray(image)
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.subheader("📄 Document Image")
            
            # Draw existing annotations
            annotated_image = self._draw_annotations_on_image(display_image, st.session_state[f"{session_key}_annotations"])
            st.image(annotated_image, use_column_width=True)
            
            # Image info
            st.info(f"📏 **Image Size:** {image.size[0]} x {image.size[1]} pixels")
        
        with col2:
            st.subheader("🎛️ Annotation Tools")
            
            # Method selection
            annotation_method = st.radio(
                "Choose annotation method:",
                ["🤖 Smart Auto-Detect", "📍 Manual Selection", "🔍 Click & Extract"],
                key=f"{session_key}_method"
            )
            
            if annotation_method == "🤖 Smart Auto-Detect":
                if st.button("🚀 Auto-Detect All Fields", type="primary", key=f"{session_key}_auto"):
                    with st.spinner("Detecting fields automatically..."):
                        auto_annotations = self._smart_auto_detect(image, fields_to_extract)
                        
                        if auto_annotations:
                            st.session_state[f"{session_key}_annotations"].extend(auto_annotations)
                            st.success(f"✅ Found {len(auto_annotations)} fields!")
                            st.rerun()
                        else:
                            st.warning("No fields auto-detected. Try manual selection.")
            
            elif annotation_method == "📍 Manual Selection":
                selected_field = st.selectbox(
                    "Field to annotate:",
                    ["Select field..."] + fields_to_extract,
                    key=f"{session_key}_manual_field"
                )
                
                if selected_field != "Select field...":
                    st.write(f"**Annotating:** {selected_field}")
                    
                    col_coord1, col_coord2 = st.columns(2)
                    
                    with col_coord1:
                        x1 = st.number_input("Top-left X", min_value=0, max_value=image.size[0], value=0, key=f"x1_{session_key}")
                        y1 = st.number_input("Top-left Y", min_value=0, max_value=image.size[1], value=0, key=f"y1_{session_key}")
                    
                    with col_coord2:
                        x2 = st.number_input("Bottom-right X", min_value=0, max_value=image.size[0], value=100, key=f"x2_{session_key}")
                        y2 = st.number_input("Bottom-right Y", min_value=0, max_value=image.size[1], value=30, key=f"y2_{session_key}")
                    
                    if st.button(f"📍 Add {selected_field}", key=f"add_manual_{session_key}"):
                        extracted_text = self._extract_text_from_region(image, x1, y1, x2, y2)
                        
                        annotation = {
                            'field': selected_field,
                            'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                            'text': extracted_text,
                            'confidence': 0.85
                        }
                        
                        st.session_state[f"{session_key}_annotations"].append(annotation)
                        st.success(f"Added {selected_field}: '{extracted_text}'")
                        st.rerun()
            
            elif annotation_method == "🔍 Click & Extract":
                st.markdown("**Smart Click Detection:**")
                
                # Grid-based clicking system
                grid_size = st.slider("Detection Grid Size", 3, 8, 4, key=f"{session_key}_grid")
                
                if st.button("📋 Show Clickable Grid", key=f"{session_key}_show_grid_btn"):
                    st.info("Grid functionality temporarily disabled. Use Auto-Detect or Manual Selection instead.")
                    
                # Removed problematic grid functionality to prevent session state errors
            
            # Annotation management
            st.subheader("📋 Current Annotations")
            
            if st.session_state[f"{session_key}_annotations"]:
                for i, ann in enumerate(st.session_state[f"{session_key}_annotations"]):
                    with st.expander(f"{ann['field']} - {ann['text'][:20]}..."):
                        st.write(f"**Text:** {ann['text']}")
                        st.write(f"**Position:** ({ann['x1']}, {ann['y1']}) → ({ann['x2']}, {ann['y2']})")
                        st.write(f"**Confidence:** {ann['confidence']*100:.0f}%")
                        
                        if st.button("🗑️ Delete", key=f"del_{i}_{session_key}"):
                            st.session_state[f"{session_key}_annotations"].pop(i)
                            st.rerun()
                
                col_clear, col_process = st.columns(2)
                
                with col_clear:
                    if st.button("🗑️ Clear All", key=f"{session_key}_clear"):
                        st.session_state[f"{session_key}_annotations"] = []
                        if f"{session_key}_grid_active" in st.session_state:
                            del st.session_state[f"{session_key}_grid_active"]
                        st.rerun()
                
                with col_process:
                    if st.button("✅ Process All", type="primary", key=f"{session_key}_process"):
                        return self._process_annotations(st.session_state[f"{session_key}_annotations"])
            
            else:
                st.info("No annotations yet. Use one of the methods above to annotate fields.")
        
        return None
    
    def _show_clickable_grid(self, image, fields_to_extract, grid_size, session_key):
        """Show a clickable grid for easy field selection"""
        st.subheader("🎯 Click on Grid to Extract Fields")
        
        # Create grid
        width, height = image.size
        grid_width = width // grid_size
        grid_height = height // grid_size
        
        # Show grid with buttons
        for row in range(grid_size):
            cols = st.columns(grid_size)
            for col in range(grid_size):
                x1 = col * grid_width
                y1 = row * grid_height
                x2 = min((col + 1) * grid_width, width)
                y2 = min((row + 1) * grid_height, height)
                
                with cols[col]:
                    # Extract text from this grid cell
                    cell_text = self._extract_text_from_region(image, x1, y1, x2, y2)
                    
                    if cell_text and len(cell_text.strip()) > 1:
                        # Show button with extracted text
                        button_text = cell_text[:10] + "..." if len(cell_text) > 10 else cell_text
                        
                        cell_clicked = st.button(f"📍 {button_text}", key=f"grid_{row}_{col}_{session_key}")
                        
                        if cell_clicked:
                            # Let user select field type for this text
                            st.session_state[f"{session_key}_selected_cell"] = {
                                'text': cell_text,
                                'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2
                            }
                            st.rerun()
        
        # Field selection for clicked cell
        if f"{session_key}_selected_cell" in st.session_state:
            cell_data = st.session_state[f"{session_key}_selected_cell"]
            
            st.success(f"Selected text: '{cell_data['text']}'")
            
            selected_field = st.selectbox(
                "What field is this?",
                ["Select field type..."] + fields_to_extract,
                key=f"{session_key}_cell_field"
            )
            
            if selected_field != "Select field type...":
                add_annotation = st.button("✅ Add This Annotation", key=f"{session_key}_add_cell")
                
                if add_annotation:
                    annotation = {
                        'field': selected_field,
                        'text': cell_data['text'],
                        'x1': cell_data['x1'], 'y1': cell_data['y1'],
                        'x2': cell_data['x2'], 'y2': cell_data['y2'],
                        'confidence': 0.8
                    }
                    
                    st.session_state[f"{session_key}_annotations"].append(annotation)
                    if f"{session_key}_selected_cell" in st.session_state:
                        del st.session_state[f"{session_key}_selected_cell"]
                    st.success(f"Added {selected_field}!")
                    st.rerun()
    
    def _smart_auto_detect(self, image, fields_to_extract):
        """Enhanced smart auto-detection"""
        try:
            # Enhanced field patterns
            patterns = {
                'name': [
                    r'(?:Name|NAME|नाम)[:\s]*([A-Za-z\s\.]{3,40})',
                    r'([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)'
                ],
                'employee_id': [
                    r'(?:Employee|EMP)[:\s]*(?:ID|No)[:\s]*([A-Z0-9]{3,15})',
                    r'(EMP[0-9]{3,10})',
                    r'([A-Z]{2,4}[0-9]{3,8})'
                ],
                'id_number': [
                    r'(?:ID|Card)[:\s]*(?:No|Number)[:\s]*([A-Z0-9]{6,20})',
                    r'([A-Z]{5}[0-9]{4}[A-Z])',
                    r'([0-9]{12})',
                    r'([A-Z]{3}[0-9]{7})'
                ],
                'department': [
                    r'(?:Department|Dept)[:\s]*([A-Za-z\s]{3,25})',
                    r'(ENGINEERING|MARKETING|FINANCE|HR|HUMAN\s+RESOURCES|SALES|IT|OPERATIONS|ADMIN)'
                ],
                'designation': [
                    r'(?:Designation|Position|Title)[:\s]*([A-Za-z\s]{3,30})',
                    r'(MANAGER|ENGINEER|ANALYST|EXECUTIVE|DIRECTOR|OFFICER|ASSISTANT|SUPERVISOR)'
                ],
                'date_of_birth': [
                    r'(?:DOB|Date of Birth|Birth)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})',
                    r'([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})'
                ],
                'issue_date': [
                    r'(?:Issue|Issued|Date of Issue)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})',
                ],
                'gender': [
                    r'(?:Gender|Sex)[:\s]*([MF]|Male|Female)',
                    r'(Male|Female|M|F)'
                ]
            }
            
            # Get OCR data with positions
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            full_text = pytesseract.image_to_string(image)
            
            annotations = []
            found_fields = set()
            
            for field in fields_to_extract:
                if field in patterns and field not in found_fields:
                    for pattern in patterns[field]:
                        import re
                        match = re.search(pattern, full_text, re.IGNORECASE)
                        if match:
                            matched_text = match.group(1) if len(match.groups()) > 0 else match.group(0)
                            
                            # Find location
                            location = self._find_text_location_advanced(matched_text, data, image.size)
                            
                            if location:
                                annotations.append({
                                    'field': field,
                                    'text': matched_text.strip(),
                                    'x1': location['x1'],
                                    'y1': location['y1'],
                                    'x2': location['x2'],
                                    'y2': location['y2'],
                                    'confidence': 0.85
                                })
                                found_fields.add(field)
                                break
            
            return annotations
            
        except Exception as e:
            st.error(f"Auto-detection error: {e}")
            return []
    
    def _find_text_location_advanced(self, text, ocr_data, image_size):
        """Advanced text location finding"""
        try:
            text_words = text.lower().split()
            if not text_words:
                return None
            
            target_word = text_words[0]
            
            # Find all occurrences and choose best one
            candidates = []
            
            for i, word in enumerate(ocr_data['text']):
                word_clean = word.lower().strip()
                if target_word in word_clean and int(ocr_data['conf'][i]) > 25:
                    x = int(ocr_data['left'][i])
                    y = int(ocr_data['top'][i])
                    w = int(ocr_data['width'][i])
                    h = int(ocr_data['height'][i])
                    conf = int(ocr_data['conf'][i])
                    
                    candidates.append({
                        'x': x, 'y': y, 'w': w, 'h': h, 'conf': conf
                    })
            
            if candidates:
                # Choose best candidate (highest confidence)
                best = max(candidates, key=lambda c: c['conf'])
                
                # Expand region for full text
                expansion = len(' '.join(text_words)) * 8  # Approximate character width
                
                return {
                    'x1': max(0, best['x'] - 5),
                    'y1': max(0, best['y'] - 3),
                    'x2': min(image_size[0], best['x'] + best['w'] + expansion),
                    'y2': min(image_size[1], best['y'] + best['h'] + 3)
                }
            
            return None
            
        except Exception as e:
            return None
    
    def _extract_text_from_region(self, image, x1, y1, x2, y2):
        """Extract text from image region"""
        try:
            if isinstance(image, Image.Image):
                img_array = np.array(image)
            else:
                img_array = image
            
            # Ensure coordinates are valid
            h, w = img_array.shape[:2]
            x1, y1, x2, y2 = max(0, x1), max(0, y1), min(w, x2), min(h, y2)
            
            if x2 <= x1 or y2 <= y1:
                return "Invalid region"
            
            # Crop region
            region = img_array[y1:y2, x1:x2]
            
            # Convert to PIL
            region_pil = Image.fromarray(region)
            
            # Try different OCR configs
            configs = ['--psm 8', '--psm 7', '--psm 6', '--psm 13']
            
            best_text = ""
            for config in configs:
                try:
                    text = pytesseract.image_to_string(region_pil, config=config).strip()
                    if len(text) > len(best_text):
                        best_text = text
                except:
                    continue
            
            return best_text if best_text else "No text detected"
            
        except Exception as e:
            return f"Error: {str(e)}"
    
    def _draw_annotations_on_image(self, image, annotations):
        """Draw annotation boxes on image"""
        if not annotations:
            return image
        
        draw_image = image.copy()
        draw = ImageDraw.Draw(draw_image)
        
        for i, ann in enumerate(annotations):
            color = self.colors[i % len(self.colors)]
            
            # Draw rectangle
            draw.rectangle(
                [ann['x1'], ann['y1'], ann['x2'], ann['y2']],
                outline=color,
                width=2
            )
            
            # Draw label
            try:
                font = ImageFont.truetype("arial.ttf", 12)
            except:
                font = ImageFont.load_default()
            
            draw.text(
                (ann['x1'], ann['y1'] - 15),
                ann['field'],
                fill=color,
                font=font
            )
        
        return draw_image
    
    def _process_annotations(self, annotations):
        """Process annotations into training data format"""
        if not annotations:
            return None
        
        training_data = {}
        for annotation in annotations:
            field_name = annotation['field']
            training_data[field_name] = {
                'value': annotation['text'],
                'coordinates': {
                    'x1': annotation['x1'],
                    'y1': annotation['y1'],
                    'x2': annotation['x2'],
                    'y2': annotation['y2']
                },
                'confidence': annotation['confidence']
            }
        
        return {
            'success': True,
            'training_data': training_data,
            'annotation_count': len(annotations)
        }