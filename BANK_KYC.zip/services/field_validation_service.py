#!/usr/bin/env python3
"""
Enhanced Field Validation Service for KYC Document Processing
Provides standardization, validation, and ML-enhanced accuracy for extracted fields
"""

import re
import logging
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime, date
import pandas as pd
from fuzzywuzzy import fuzz, process
from difflib import SequenceMatcher
import json

class FieldValidationService:
    """
    Comprehensive field validation and standardization service
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Confidence thresholds for different field types
        self.confidence_thresholds = {
            'name': 85,
            'id_number': 90,
            'date_of_birth': 80,
            'gender': 70,
            'address': 75,
            'default': 80
        }
        
        # Validation patterns
        self.patterns = {
            'aadhaar_number': re.compile(r'^[0-9]{4}\s?[0-9]{4}\s?[0-9]{4}$'),
            'pan_number': re.compile(r'^[A-Z]{5}[0-9]{4}[A-Z]{1}$'),
            'employee_id': re.compile(r'^[A-Z0-9]{6,12}$'),
            'phone': re.compile(r'^[6-9]\d{9}$'),
            'email': re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'),
            'pincode': re.compile(r'^[1-9][0-9]{5}$'),
            'name': re.compile(r'^[A-Za-z\s\.]{2,50}$'),
            'date_ddmmyyyy': re.compile(r'^(?:0[1-9]|[12][0-9]|3[01])[\/\-](?:0[1-9]|1[0-2])[\/\-](?:19|20)\d{2}$'),
            'date_yyyy': re.compile(r'^(?:19|20)\d{2}$')
        }
        
        # Gender standardization mapping
        self.gender_mapping = {
            'male': 'Male',
            'female': 'Female',
            'other': 'Other',
            'm': 'Male',
            'f': 'Female',
            'o': 'Other',
            'transgender': 'Other',
            'trans': 'Other'
        }
        
        # Common OCR errors and corrections
        self.ocr_corrections = {
            '0': 'O',
            'O': '0',
            '1': 'I',
            'I': '1',
            '5': 'S',
            'S': '5',
            '8': 'B',
            'B': '8',
            '6': 'G',
            'G': '6'
        }

    def validate_and_standardize(self, extracted_data: Dict[str, Any], 
                                document_type: str = 'aadhaar') -> Dict[str, Any]:
        """
        Main validation and standardization function
        
        Args:
            extracted_data: Raw extracted data from OCR/ML
            document_type: Type of document (aadhaar, pan, employee_id)
            
        Returns:
            Dictionary with validated and standardized data
        """
        result = {
            'validated_fields': {},
            'validation_errors': [],
            'confidence_scores': {},
            'suggestions': [],
            'is_valid': True,
            'quality_score': 0.0
        }
        
        try:
            # Validate each field
            for field_name, field_value in extracted_data.get('field_values', {}).items():
                validation_result = self._validate_field(
                    field_name, field_value, document_type, 
                    extracted_data.get('text_boxes', [])
                )
                
                result['validated_fields'][field_name] = validation_result['value']
                result['confidence_scores'][field_name] = validation_result['confidence']
                
                if validation_result['errors']:
                    result['validation_errors'].extend(validation_result['errors'])
                    result['is_valid'] = False
                    
                if validation_result['suggestions']:
                    result['suggestions'].extend(validation_result['suggestions'])
            
            # Calculate overall quality score
            result['quality_score'] = self._calculate_quality_score(
                result['confidence_scores'], result['validation_errors']
            )
            
            # Add document-specific validation
            self._validate_document_specific(result, document_type)
            
        except Exception as e:
            self.logger.error(f"Error in validation: {str(e)}")
            result['validation_errors'].append(f"Validation service error: {str(e)}")
            result['is_valid'] = False
            
        return result

    def _validate_field(self, field_name: str, field_value: str, 
                       document_type: str, text_boxes: List[Dict]) -> Dict[str, Any]:
        """
        Validate individual field
        """
        result = {
            'value': field_value,
            'confidence': 0.0,
            'errors': [],
            'suggestions': []
        }
        
        if not field_value or not field_value.strip():
            result['errors'].append(f"{field_name} is empty or missing")
            return result
            
        # Get confidence from text boxes
        result['confidence'] = self._get_field_confidence(field_value, text_boxes)
        
        # Apply field-specific validation
        if field_name == 'name':
            result = self._validate_name(field_value, result)
        elif field_name == 'id_number':
            result = self._validate_id_number(field_value, document_type, result)
        elif field_name == 'date_of_birth':
            result = self._validate_date_of_birth(field_value, result)
        elif field_name == 'gender':
            result = self._validate_gender(field_value, result)
        elif field_name == 'address':
            result = self._validate_address(field_value, result)
        elif field_name == 'phone':
            result = self._validate_phone(field_value, result)
        elif field_name == 'email':
            result = self._validate_email(field_value, result)
            
        # Check confidence threshold
        threshold = self.confidence_thresholds.get(field_name, 
                                                 self.confidence_thresholds['default'])
        if result['confidence'] < threshold:
            result['errors'].append(
                f"{field_name} confidence ({result['confidence']:.1f}%) below threshold ({threshold}%)"
            )
            
        return result

    def _validate_name(self, name: str, result: Dict) -> Dict:
        """Validate and standardize name field"""
        # Clean and standardize
        cleaned_name = re.sub(r'[^A-Za-z\s\.]', '', name)
        cleaned_name = ' '.join(cleaned_name.split())  # Remove extra spaces
        cleaned_name = cleaned_name.title()  # Proper case
        
        result['value'] = cleaned_name
        
        # Validation checks
        if not self.patterns['name'].match(cleaned_name):
            result['errors'].append(f"Name contains invalid characters: {name}")
            
        if len(cleaned_name.split()) < 2:
            result['suggestions'].append("Name should contain at least first and last name")
            
        if len(cleaned_name) < 2:
            result['errors'].append("Name is too short")
            
        return result

    def _validate_id_number(self, id_number: str, document_type: str, result: Dict) -> Dict:
        """Validate ID number based on document type"""
        cleaned_id = re.sub(r'[^\d\sA-Z]', '', id_number.upper())
        
        if document_type.lower() == 'aadhaar':
            # Standardize Aadhaar format: XXXX XXXX XXXX
            digits_only = re.sub(r'\D', '', cleaned_id)
            if len(digits_only) == 12:
                formatted_id = f"{digits_only[:4]} {digits_only[4:8]} {digits_only[8:]}"
                result['value'] = formatted_id
                
                if not self.patterns['aadhaar_number'].match(formatted_id):
                    result['errors'].append(f"Invalid Aadhaar format: {id_number}")
            else:
                result['errors'].append(f"Aadhaar should be 12 digits: {id_number}")
                
        elif document_type.lower() == 'pan':
            if self.patterns['pan_number'].match(cleaned_id):
                result['value'] = cleaned_id
            else:
                result['errors'].append(f"Invalid PAN format: {id_number}")
                
        elif document_type.lower() == 'employee_id':
            if self.patterns['employee_id'].match(cleaned_id):
                result['value'] = cleaned_id
            else:
                result['errors'].append(f"Invalid Employee ID format: {id_number}")
                
        return result

    def _validate_date_of_birth(self, dob: str, result: Dict) -> Dict:
        """Validate and standardize date of birth"""
        cleaned_dob = dob.strip()
        
        # Try different date formats
        date_formats = [
            '%d/%m/%Y', '%d-%m-%Y', '%d.%m.%Y',
            '%m/%d/%Y', '%m-%d-%Y', '%m.%d.%Y',
            '%Y-%m-%d', '%Y/%m/%d',
            '%d %m %Y', '%d %b %Y', '%d %B %Y'
        ]
        
        parsed_date = None
        
        # If only year is provided
        if self.patterns['date_yyyy'].match(cleaned_dob):
            try:
                year = int(cleaned_dob)
                if 1900 <= year <= datetime.now().year:
                    result['value'] = f"01/01/{year}"  # Standardize to DD/MM/YYYY
                    result['suggestions'].append("Only birth year provided, using 01/01 as default")
                    return result
                else:
                    result['errors'].append(f"Invalid birth year: {year}")
                    return result
            except ValueError:
                pass
        
        # Try to parse full date
        for fmt in date_formats:
            try:
                parsed_date = datetime.strptime(cleaned_dob, fmt)
                break
            except ValueError:
                continue
                
        if parsed_date:
            # Validate age (should be between 0 and 120 years)
            today = datetime.now()
            age = today.year - parsed_date.year
            
            if age < 0 or age > 120:
                result['errors'].append(f"Invalid age calculated: {age} years")
            else:
                # Standardize to DD/MM/YYYY format
                result['value'] = parsed_date.strftime('%d/%m/%Y')
        else:
            result['errors'].append(f"Could not parse date: {dob}")
            result['suggestions'].append("Expected formats: DD/MM/YYYY, DD-MM-YYYY, or YYYY")
            
        return result

    def _validate_gender(self, gender: str, result: Dict) -> Dict:
        """Validate and standardize gender field"""
        cleaned_gender = gender.lower().strip()
        
        # Use fuzzy matching for gender standardization
        gender_options = list(self.gender_mapping.keys())
        best_match = process.extractOne(cleaned_gender, gender_options, score_cutoff=70)
        
        if best_match:
            standardized_gender = self.gender_mapping[best_match[0]]
            result['value'] = standardized_gender
            
            if best_match[1] < 90:  # If match confidence is low
                result['suggestions'].append(f"Gender '{gender}' matched to '{standardized_gender}' with {best_match[1]}% confidence")
        else:
            result['errors'].append(f"Could not standardize gender: {gender}")
            result['suggestions'].append("Expected: Male, Female, or Other")
            
        return result

    def _validate_address(self, address: str, result: Dict) -> Dict:
        """Validate address field"""
        if len(address.strip()) < 10:
            result['suggestions'].append("Address seems too short")
            
        # Check for pincode
        pincode_match = re.search(r'\b[1-9][0-9]{5}\b', address)
        if not pincode_match:
            result['suggestions'].append("No valid pincode found in address")
            
        # Clean up extra spaces and normalize
        cleaned_address = ' '.join(address.split())
        result['value'] = cleaned_address
        
        return result

    def _validate_phone(self, phone: str, result: Dict) -> Dict:
        """Validate phone number"""
        digits_only = re.sub(r'\D', '', phone)
        
        if len(digits_only) == 10 and self.patterns['phone'].match(digits_only):
            result['value'] = digits_only
        elif len(digits_only) == 11 and digits_only.startswith('0'):
            # Remove leading 0
            cleaned_phone = digits_only[1:]
            if self.patterns['phone'].match(cleaned_phone):
                result['value'] = cleaned_phone
        elif len(digits_only) == 12 and digits_only.startswith('91'):
            # Remove country code
            cleaned_phone = digits_only[2:]
            if self.patterns['phone'].match(cleaned_phone):
                result['value'] = cleaned_phone
        else:
            result['errors'].append(f"Invalid phone number format: {phone}")
            
        return result

    def _validate_email(self, email: str, result: Dict) -> Dict:
        """Validate email address"""
        cleaned_email = email.lower().strip()
        
        if self.patterns['email'].match(cleaned_email):
            result['value'] = cleaned_email
        else:
            result['errors'].append(f"Invalid email format: {email}")
            
        return result

    def _get_field_confidence(self, field_value: str, text_boxes: List[Dict]) -> float:
        """
        Calculate confidence score for field based on OCR text boxes
        """
        if not text_boxes:
            return 50.0  # Default confidence if no text boxes
            
        # Find text boxes that match the field value
        field_words = field_value.lower().split()
        confidences = []
        
        for word in field_words:
            best_confidence = 0
            for text_box in text_boxes:
                text = text_box.get('text', '').lower()
                confidence = text_box.get('confidence', 0)
                
                # Use fuzzy matching to find similar text
                similarity = fuzz.ratio(word, text)
                if similarity > 80:  # Good match
                    best_confidence = max(best_confidence, confidence * (similarity / 100))
                    
            if best_confidence > 0:
                confidences.append(best_confidence)
                
        return sum(confidences) / len(confidences) if confidences else 50.0

    def _calculate_quality_score(self, confidence_scores: Dict, errors: List[str]) -> float:
        """
        Calculate overall document quality score
        """
        if not confidence_scores:
            return 0.0
            
        avg_confidence = sum(confidence_scores.values()) / len(confidence_scores)
        error_penalty = min(len(errors) * 10, 50)  # Max 50% penalty for errors
        
        quality_score = max(0, avg_confidence - error_penalty)
        return round(quality_score, 1)

    def _validate_document_specific(self, result: Dict, document_type: str):
        """
        Apply document-specific validation rules
        """
        validated_fields = result['validated_fields']
        
        if document_type.lower() == 'aadhaar':
            # Aadhaar-specific checks
            required_fields = ['name', 'id_number', 'date_of_birth', 'gender']
            for field in required_fields:
                if field not in validated_fields or not validated_fields[field]:
                    result['validation_errors'].append(f"Required Aadhaar field missing: {field}")
                    result['is_valid'] = False
                    
        elif document_type.lower() == 'pan':
            # PAN-specific checks
            if 'id_number' in validated_fields:
                pan = validated_fields['id_number']
                if len(pan) != 10:
                    result['validation_errors'].append("PAN must be 10 characters")
                    result['is_valid'] = False

    def enhance_extraction_with_ml(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Use ML techniques to enhance extraction accuracy
        """
        enhanced_data = raw_data.copy()
        
        try:
            # Apply OCR error corrections
            if 'field_values' in enhanced_data:
                for field_name, field_value in enhanced_data['field_values'].items():
                    corrected_value = self._apply_ocr_corrections(field_value)
                    enhanced_data['field_values'][field_name] = corrected_value
                    
            # Apply contextual improvements
            enhanced_data = self._apply_contextual_improvements(enhanced_data)
            
        except Exception as e:
            self.logger.error(f"Error in ML enhancement: {str(e)}")
            
        return enhanced_data

    def _apply_ocr_corrections(self, text: str) -> str:
        """
        Apply common OCR error corrections
        """
        if not text:
            return text
            
        corrected = text
        
        # Apply character-level corrections based on context
        # For numeric fields, prefer digits
        if re.match(r'^[\dOIlS\s]+$', text):
            corrected = corrected.replace('O', '0').replace('I', '1').replace('l', '1').replace('S', '5')
            
        # For text fields, prefer letters
        elif re.match(r'^[A-Za-z0-9\s]+$', text):
            # Context-aware corrections (you can expand this)
            pass
            
        return corrected

    def _apply_contextual_improvements(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Apply contextual improvements using field relationships
        """
        if 'field_values' not in data:
            return data
            
        fields = data['field_values']
        
        # If we have a name field, ensure proper capitalization
        if 'name' in fields and fields['name']:
            fields['name'] = self._improve_name_extraction(fields['name'])
            
        # If we have date field, try to infer missing parts
        if 'date_of_birth' in fields and fields['date_of_birth']:
            fields['date_of_birth'] = self._improve_date_extraction(fields['date_of_birth'])
            
        return data

    def _improve_name_extraction(self, name: str) -> str:
        """
        Improve name extraction using contextual clues
        """
        # Remove common OCR artifacts
        cleaned = re.sub(r'[^\w\s\.]', '', name)
        cleaned = ' '.join(cleaned.split())  # Remove extra spaces
        
        # Apply title case but preserve common prefixes/suffixes
        words = cleaned.split()
        improved_words = []
        
        for word in words:
            if word.lower() in ['dr', 'mr', 'mrs', 'ms', 'prof']:
                improved_words.append(word.title())
            elif len(word) > 1:
                improved_words.append(word.title())
            else:
                improved_words.append(word.upper() if word.isalpha() else word)
                
        return ' '.join(improved_words)

    def _improve_date_extraction(self, date_str: str) -> str:
        """
        Improve date extraction with common corrections
        """
        # Common OCR date errors
        corrections = {
            'O': '0',
            'I': '1',
            'l': '1',
            'S': '5',
            'Z': '2'
        }
        
        improved = date_str
        for wrong, correct in corrections.items():
            improved = improved.replace(wrong, correct)
            
        return improved

# Example usage and testing function
def test_validation_service():
    """
    Test the validation service with sample data
    """
    validator = FieldValidationService()
    
    # Test data similar to what we saw in the training files
    test_data = {
        'field_values': {
            'name': 'Vishal Nadagiri',
            'id_number': '4015 0996 1518',
            'date_of_birth': '1993',
            'gender': 'Male'
        },
        'text_boxes': [
            {'text': 'Vishal', 'confidence': 93},
            {'text': 'Nadagiri', 'confidence': 89},
            {'text': '1993', 'confidence': 87},
            {'text': 'Male', 'confidence': 93},
            {'text': '4015', 'confidence': 95},
            {'text': '0996', 'confidence': 92},
            {'text': '1518', 'confidence': 88}
        ]
    }
    
    result = validator.validate_and_standardize(test_data, 'aadhaar')
    print(json.dumps(result, indent=2))
    
if __name__ == "__main__":
    test_validation_service()