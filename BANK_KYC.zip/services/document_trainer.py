#!/usr/bin/env python3
"""
Custom Document Training System for KYC Application
Allows users to train the system on their own documents with custom field extraction
"""

import os
import json
import cv2
import numpy as np
from PIL import Image
import pytesseract
import re
import logging
from pathlib import Path
from datetime import datetime
import pickle

logger = logging.getLogger(__name__)

class DocumentTrainer:
    def __init__(self):
        self.training_data_dir = Path("data/training")
        self.patterns_file = Path("data/custom_patterns.json")
        self.templates_file = Path("data/document_templates.pkl")
        
        # Create directories if they don't exist
        self.training_data_dir.mkdir(parents=True, exist_ok=True)
        
        # Load existing patterns and templates
        self.custom_patterns = self.load_custom_patterns()
        self.document_templates = self.load_document_templates()
        
    def load_custom_patterns(self):
        """Load existing custom patterns"""
        try:
            if self.patterns_file.exists():
                with open(self.patterns_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            else:
                return {
                    'document_types': {},
                    'field_patterns': {},
                    'training_history': []
                }
        except Exception as e:
            logger.error(f"Error loading custom patterns: {e}")
            return {'document_types': {}, 'field_patterns': {}, 'training_history': []}
    
    def save_custom_patterns(self):
        """Save custom patterns to file"""
        try:
            with open(self.patterns_file, 'w', encoding='utf-8') as f:
                json.dump(self.custom_patterns, f, indent=2, ensure_ascii=False)
            logger.info("Custom patterns saved successfully")
        except Exception as e:
            logger.error(f"Error saving custom patterns: {e}")
    
    def load_document_templates(self):
        """Load document templates for matching"""
        try:
            if self.templates_file.exists():
                with open(self.templates_file, 'rb') as f:
                    return pickle.load(f)
            else:
                return {}
        except Exception as e:
            logger.error(f"Error loading document templates: {e}")
            return {}
    
    def save_document_templates(self):
        """Save document templates"""
        try:
            with open(self.templates_file, 'wb') as f:
                pickle.dump(self.document_templates, f)
            logger.info("Document templates saved successfully")
        except Exception as e:
            logger.error(f"Error saving document templates: {e}")
    
    def start_training_session(self, document_type_name, fields_to_extract):
        """
        Start a new training session for a specific document type
        
        Args:
            document_type_name: Name for the document type (e.g., "company_id", "custom_license")
            fields_to_extract: List of field names to extract (e.g., ["employee_id", "name", "department"])
        """
        session_id = f"{document_type_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        training_session = {
            'session_id': session_id,
            'document_type': document_type_name,
            'fields_to_extract': fields_to_extract,
            'training_samples': [],
            'learned_patterns': {},
            'created_at': datetime.now().isoformat(),
            'status': 'active'
        }
        
        # Create session directory
        session_dir = self.training_data_dir / session_id
        session_dir.mkdir(exist_ok=True)
        
        logger.info(f"Started training session: {session_id}")
        return session_id, training_session
    
    def add_training_document(self, session_id, image_path, field_values):
        """
        Add a training document with labeled field values (supports both text and annotation data)
        
        Args:
            session_id: Training session ID
            image_path: Path to the document image
            field_values: Dictionary mapping field names to their values (can be string or dict with coordinates)
        """
        try:
            # Load and process the image
            image = Image.open(image_path)
            
            # Extract raw text
            raw_text = self._extract_text_with_coordinates(image)
            
            # Process field values to handle both annotation and text input formats
            processed_field_values = {}
            field_coordinates = {}
            
            for field_name, field_data in field_values.items():
                if isinstance(field_data, dict) and 'value' in field_data:
                    # Annotation data with coordinates
                    processed_field_values[field_name] = field_data['value']
                    if 'coordinates' in field_data:
                        field_coordinates[field_name] = field_data['coordinates']
                else:
                    # Simple text value
                    processed_field_values[field_name] = str(field_data)
            
            # Store training sample with enhanced data
            training_sample = {
                'image_path': str(image_path),
                'field_values': processed_field_values,
                'field_coordinates': field_coordinates,  # New: coordinate information
                'raw_text': raw_text['text'],
                'text_boxes': raw_text['boxes'],
                'training_method': 'annotation' if field_coordinates else 'manual',
                'processed_at': datetime.now().isoformat()
            }
            
            # Save sample data
            session_dir = self.training_data_dir / session_id
            sample_file = session_dir / f"sample_{len(os.listdir(session_dir))}.json"
            
            with open(sample_file, 'w', encoding='utf-8') as f:
                json.dump(training_sample, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Added training document to session {session_id} using {training_sample['training_method']} method")
            return True
            
        except Exception as e:
            logger.error(f"Error adding training document: {e}")
            return False
    
    def _extract_text_with_coordinates(self, image):
        """Extract text with bounding box coordinates"""
        try:
            # Convert PIL to opencv format
            if isinstance(image, Image.Image):
                image_array = np.array(image)
            else:
                image_array = image
            
            # Use Tesseract to get text with bounding boxes
            data = pytesseract.image_to_data(image_array, output_type=pytesseract.Output.DICT)
            
            text_boxes = []
            full_text = ""
            
            for i in range(len(data['text'])):
                if int(data['conf'][i]) > 30:  # Filter low confidence text
                    text = data['text'][i].strip()
                    if text:
                        text_boxes.append({
                            'text': text,
                            'confidence': int(data['conf'][i]),
                            'x': int(data['left'][i]),
                            'y': int(data['top'][i]),
                            'width': int(data['width'][i]),
                            'height': int(data['height'][i])
                        })
                        full_text += text + " "
            
            return {
                'text': full_text.strip(),
                'boxes': text_boxes
            }
            
        except Exception as e:
            logger.error(f"Error extracting text with coordinates: {e}")
            return {'text': '', 'boxes': []}
    
    def learn_patterns_from_samples(self, session_id):
        """
        Analyze training samples and learn extraction patterns
        """
        try:
            session_dir = self.training_data_dir / session_id
            sample_files = list(session_dir.glob("sample_*.json"))
            
            if len(sample_files) < 2:
                return {
                    'success': False,
                    'message': 'Need at least 2 training samples to learn patterns'
                }
            
            learned_patterns = {}
            field_positions = {}
            
            # Load all training samples
            samples = []
            for sample_file in sample_files:
                with open(sample_file, 'r', encoding='utf-8') as f:
                    samples.append(json.load(f))
            
            # Learn patterns for each field with enhanced coordinate-based learning
            for sample in samples:
                field_values = sample['field_values']
                field_coordinates = sample.get('field_coordinates', {})
                text_boxes = sample['text_boxes']
                training_method = sample.get('training_method', 'manual')
                
                for field_name, field_value in field_values.items():
                    if field_value and field_value.strip():
                        if field_name not in learned_patterns:
                            learned_patterns[field_name] = {
                                'regex_patterns': [],
                                'position_patterns': [],
                                'context_patterns': [],
                                'coordinate_patterns': [],  # New: coordinate-based patterns
                                'training_quality': 'high' if training_method == 'annotation' else 'medium'
                            }
                        
                        # Learn regex patterns
                        regex_pattern = self._generate_regex_pattern(field_value)
                        if regex_pattern not in learned_patterns[field_name]['regex_patterns']:
                            learned_patterns[field_name]['regex_patterns'].append(regex_pattern)
                        
                        # Enhanced position learning based on method
                        if field_name in field_coordinates:
                            # High-quality coordinate-based learning
                            coords = field_coordinates[field_name]
                            position_info = {
                                'x_ratio': coords['x1'] / 800,  # Normalize to standard size
                                'y_ratio': coords['y1'] / 600,
                                'width_ratio': (coords['x2'] - coords['x1']) / 800,
                                'height_ratio': (coords['y2'] - coords['y1']) / 600,
                                'confidence': 0.9,  # High confidence for annotated data
                                'source': 'annotation'
                            }
                            learned_patterns[field_name]['coordinate_patterns'].append(position_info)
                        else:
                            # Fallback to OCR-based position detection
                            matching_boxes = self._find_field_in_text_boxes(field_value, text_boxes)
                            if matching_boxes:
                                position_info = {
                                    'x_ratio': matching_boxes[0]['x'] / 800,
                                    'y_ratio': matching_boxes[0]['y'] / 600,
                                    'confidence': matching_boxes[0]['confidence'] / 100,
                                    'source': 'ocr_detection'
                                }
                                learned_patterns[field_name]['position_patterns'].append(position_info)
                        
                        # Learn enhanced context patterns
                        context = self._extract_enhanced_context_patterns(field_value, sample['raw_text'], field_coordinates.get(field_name))
                        learned_patterns[field_name]['context_patterns'].extend(context)
            
            # Refine and consolidate patterns
            refined_patterns = self._refine_patterns(learned_patterns)
            
            # Save learned patterns
            document_type = samples[0]['field_values'].get('document_type', session_id.split('_')[0])
            self.custom_patterns['document_types'][document_type] = refined_patterns
            self.custom_patterns['training_history'].append({
                'session_id': session_id,
                'document_type': document_type,
                'samples_count': len(samples),
                'learned_at': datetime.now().isoformat()
            })
            
            self.save_custom_patterns()
            
            return {
                'success': True,
                'document_type': document_type,
                'learned_patterns': refined_patterns,
                'samples_processed': len(samples)
            }
            
        except Exception as e:
            logger.error(f"Error learning patterns: {e}")
            return {
                'success': False,
                'message': f'Pattern learning failed: {str(e)}'
            }
    
    def _find_field_in_text_boxes(self, field_value, text_boxes):
        """Find field value in OCR text boxes"""
        field_value_clean = re.sub(r'[^a-zA-Z0-9]', '', field_value.lower())
        
        for box in text_boxes:
            box_text_clean = re.sub(r'[^a-zA-Z0-9]', '', box['text'].lower())
            if field_value_clean in box_text_clean or box_text_clean in field_value_clean:
                if len(box_text_clean) >= len(field_value_clean) * 0.7:  # Similarity threshold
                    return [box]
        
        return []
    
    def _generate_regex_pattern(self, field_value):
        """Generate regex pattern based on field value"""
        # Replace digits with \d, letters with appropriate character classes
        pattern = field_value
        
        # Replace sequences of digits
        pattern = re.sub(r'\d+', r'\\d+', pattern)
        
        # Replace sequences of letters
        pattern = re.sub(r'[A-Z]+', r'[A-Z]+', pattern)
        pattern = re.sub(r'[a-z]+', r'[a-z]+', pattern)
        
        # Handle mixed case
        pattern = re.sub(r'[A-Za-z]+', r'[A-Za-z]+', pattern)
        
        # Escape special characters
        pattern = re.escape(pattern)
        
        # Restore regex parts
        pattern = pattern.replace(r'\\d\+', r'\d+')
        pattern = pattern.replace(r'\[A-Z\]\+', r'[A-Z]+')
        pattern = pattern.replace(r'\[a-z\]\+', r'[a-z]+')
        pattern = pattern.replace(r'\[A-Za-z\]\+', r'[A-Za-z]+')
        
        return pattern
    
    def _extract_context_patterns(self, field_value, full_text):
        """Extract context patterns around field values"""
        patterns = []
        
        # Find field value in text
        field_pos = full_text.lower().find(field_value.lower())
        if field_pos != -1:
            # Extract words before and after
            words = full_text.split()
            field_words = field_value.split()
            
            for i, word in enumerate(words):
                if word.lower() in field_value.lower():
                    # Context before
                    if i > 0:
                        patterns.append(f"{words[i-1]} {field_value}")
                    
                    # Context after
                    if i < len(words) - len(field_words):
                        patterns.append(f"{field_value} {words[i+len(field_words)]}")
                    
                    break
        
        return patterns
    
    def _extract_enhanced_context_patterns(self, field_value, full_text, coordinates=None):
        """Extract enhanced context patterns with coordinate information"""
        patterns = []
        
        # Get basic context patterns
        basic_patterns = self._extract_context_patterns(field_value, full_text)
        patterns.extend(basic_patterns)
        
        # If we have coordinates, extract more precise context
        if coordinates:
            # Extract label patterns (text that typically appears before field values)
            label_patterns = [
                f"Name.*{field_value}",
                f"ID.*{field_value}",
                f"Employee.*{field_value}",
                f"Department.*{field_value}",
                f"DOB.*{field_value}",
                f"Gender.*{field_value}"
            ]
            
            for pattern in label_patterns:
                if re.search(pattern, full_text, re.IGNORECASE):
                    patterns.append(pattern)
        
        # Add field-specific context patterns
        field_contexts = {
            'name': [f"Name[:\s]*{re.escape(field_value)}", f"{re.escape(field_value)}.*Employee"],
            'id_number': [f"(?:ID|Number)[:\s]*{re.escape(field_value)}", f"{re.escape(field_value)}.*Card"],
            'employee_id': [f"(?:Employee|EMP)[:\s]*{re.escape(field_value)}"],
            'department': [f"Department[:\s]*{re.escape(field_value)}"],
            'gender': [f"(?:Gender|Sex)[:\s]*{re.escape(field_value)}"]
        }
        
        # Try to identify field type from context
        for field_type, context_patterns in field_contexts.items():
            for context_pattern in context_patterns:
                if re.search(context_pattern, full_text, re.IGNORECASE):
                    patterns.append(context_pattern)
        
        return list(set(patterns))  # Remove duplicates
    
    def _refine_patterns(self, learned_patterns):
        """Refine and consolidate learned patterns"""
        refined = {}
        
        for field_name, patterns in learned_patterns.items():
            refined[field_name] = {
                'regex_patterns': list(set(patterns['regex_patterns'])),  # Remove duplicates
                'position_patterns': patterns['position_patterns'],
                'context_patterns': list(set(patterns['context_patterns']))
            }
        
        return refined
    
    def extract_using_custom_patterns(self, image, document_type):
        """Extract data using learned custom patterns + enhanced fallback patterns"""
        try:
            # First try custom trained patterns if available
            if document_type in self.custom_patterns['document_types']:
                custom_result = self._extract_with_trained_patterns(image, document_type)
                if custom_result['success'] and custom_result['extracted_data']:
                    return custom_result
            
            # Fallback to enhanced standard patterns (same as debugger uses)
            enhanced_result = self._extract_with_enhanced_patterns(image, document_type)
            return enhanced_result
            
        except Exception as e:
            logger.error(f"Custom extraction error: {e}")
            return {
                'success': False,
                'message': f'Custom extraction failed: {str(e)}'
            }
    
    def _extract_with_trained_patterns(self, image, document_type):
        """Extract using only the trained custom patterns"""
        try:
            patterns = self.custom_patterns['document_types'][document_type]
            
            # Extract text with coordinates
            text_data = self._extract_text_with_coordinates(image)
            
            extracted_data = {}
            confidence_scores = {}
            
            # Extract each field using learned patterns
            for field_name, field_patterns in patterns.items():
                best_match = None
                best_score = 0
                
                # Try regex patterns
                for regex_pattern in field_patterns['regex_patterns']:
                    try:
                        match = re.search(regex_pattern, text_data['text'], re.IGNORECASE)
                        if match:
                            if len(match.group(0)) > len(best_match or ""):
                                best_match = match.group(0)
                                best_score = 0.8
                    except Exception as e:
                        logger.debug(f"Regex pattern error: {e}")
                        continue
                
                # Try context patterns
                for context_pattern in field_patterns['context_patterns']:
                    try:
                        context_match = re.search(context_pattern, text_data['text'], re.IGNORECASE)
                        if context_match:
                            # Extract the field part from context
                            context_text = context_match.group(0)
                            if len(context_text) > len(best_match or ""):
                                best_match = context_text
                                best_score = 0.6
                    except Exception as e:
                        logger.debug(f"Context pattern error: {e}")
                        continue
                
                if best_match:
                    extracted_data[field_name] = best_match.strip()
                    confidence_scores[field_name] = best_score
            
            # Calculate overall confidence
            overall_confidence = (sum(confidence_scores.values()) / len(confidence_scores)) * 100 if confidence_scores else 0
            
            return {
                'success': len(extracted_data) > 0,
                'extracted_data': extracted_data,
                'confidence_score': overall_confidence,
                'field_scores': confidence_scores,
                'document_type': document_type
            }
            
        except Exception as e:
            logger.error(f"Trained pattern extraction error: {e}")
            return {'success': False, 'extracted_data': {}}
    
    def _extract_with_enhanced_patterns(self, image, document_type):
        """Extract using enhanced patterns (same as OCR debugger uses)"""
        try:
            # Extract text using multiple OCR configurations (like debugger does)
            text = self._extract_text_enhanced(image)
            
            # Use the same comprehensive patterns as OCR debugger
            enhanced_patterns = {
                'name': [
                    r'(?:Name|NAME|नाम)[:\s]*([A-Za-z\s\.]{2,50})',
                    r'([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
                    r'(?:श्री|श्रीमती)\s+([A-Za-z\s]+)'
                ],
                'id_number': [
                    r'(?:ID|Identity|Card|आईडी).*?(?:No|Number|संख्या)[:\s]*([A-Z0-9]{6,20})',
                    r'([A-Z]{5}[0-9]{4}[A-Z])',  # PAN
                    r'([0-9]{4}\s*[0-9]{4}\s*[0-9]{4})',  # Aadhaar
                    r'([A-Z]{2}[0-9]{13})',  # DL
                    r'([A-Z]{3}[0-9]{7})',  # Voter ID
                ],
                'employee_id': [
                    r'(?:Employee|EMP|Staff)[:\s]*(?:ID|No|Number)[:\s]*([A-Z0-9]{3,15})',
                    r'(?:EMP)[0-9]{3,10}',
                    r'([A-Z]{2,4}[0-9]{3,8})'
                ],
                'date_of_birth': [
                    r'([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})',
                    r'([0-3][0-9][/-][0-1][0-9][/-][0-9]{2})',
                    r'(?:DOB|Birth|जन्म)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})'
                ],
                'issue_date': [
                    r'(?:Issue|Issued|Date of Issue)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})',
                    r'([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})'
                ],
                'expiry_date': [
                    r'(?:Expiry|Expires|Valid until)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})',
                    r'([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})'
                ],
                'department': [
                    r'(?:Department|Dept|Division)[:\s]*([A-Za-z\s]{2,30})',
                    r'(ENGINEERING|MARKETING|FINANCE|HR|SALES|ADMIN|IT|OPERATIONS)'
                ],
                'designation': [
                    r'(?:Designation|Position|Title)[:\s]*([A-Za-z\s]{2,40})',
                    r'(MANAGER|ENGINEER|ANALYST|EXECUTIVE|DIRECTOR|ASSISTANT|OFFICER)'
                ],
                'gender': [
                    r'(?:Sex|Gender|लिंग)[:\s]*([MF]|Male|Female|पुरुष|महिला)',
                    r'(Male|Female|M|F)'
                ],
                'phone': [
                    r'(?:Phone|Mobile|Tel|फोन)[:\s]*([0-9\s\-\+]{10,15})',
                    r'([0-9]{10})',
                    r'(\+91[0-9]{10})'
                ],
                'email': [
                    r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})'
                ],
                'pincode': [
                    r'(?:PIN|Pincode|पिन)[:\s]*([0-9]{6})',
                    r'([0-9]{6})'
                ],
                'address': [
                    r'(?:Address|पता)[:\s]*([A-Za-z0-9\s,.-]{10,100})',
                    r'(?:Permanent|Current)\s*Address[:\s]*([A-Za-z0-9\s,.-]+)'
                ]
            }
            
            extracted_data = {}
            confidence_scores = {}
            
            # Extract each field using enhanced patterns
            for field_name, field_patterns in enhanced_patterns.items():
                best_match = None
                best_score = 0
                
                for pattern in field_patterns:
                    try:
                        matches = re.findall(pattern, text, re.IGNORECASE | re.MULTILINE)
                        if matches:
                            # Take the longest/best match
                            match = max(matches, key=len) if isinstance(matches[0], str) else matches[0]
                            if len(str(match)) > len(str(best_match) if best_match else ""):
                                best_match = str(match).strip()
                                best_score = 0.8
                    except Exception as e:
                        logger.debug(f"Enhanced pattern error for {field_name}: {e}")
                        continue
                
                if best_match and len(best_match) > 1:
                    extracted_data[field_name] = best_match
                    confidence_scores[field_name] = best_score
            
            # Calculate overall confidence
            overall_confidence = (sum(confidence_scores.values()) / len(confidence_scores)) * 100 if confidence_scores else 0
            
            return {
                'success': len(extracted_data) > 0,
                'extracted_data': extracted_data,
                'confidence_score': overall_confidence,
                'field_scores': confidence_scores,
                'document_type': document_type,
                'extraction_method': 'enhanced_patterns'
            }
            
        except Exception as e:
            logger.error(f"Enhanced pattern extraction error: {e}")
            return {
                'success': False,
                'message': f'Enhanced pattern extraction failed: {str(e)}',
                'extracted_data': {}
            }
    
    def _extract_text_enhanced(self, image):
        """Enhanced text extraction using multiple OCR configurations"""
        try:
            # Convert PIL to numpy if needed
            if isinstance(image, Image.Image):
                img_array = np.array(image)
            else:
                img_array = image
            
            # Try multiple OCR configurations (same as debugger)
            configs = [
                '--psm 6 --oem 3',  # Default
                '--psm 4 --oem 3',  # Single column
                '--psm 7 --oem 3',  # Single text line
                '--psm 8 --oem 3',  # Single word
                '--psm 11 --oem 3', # Sparse text
            ]
            
            all_texts = []
            
            for config in configs:
                try:
                    text = pytesseract.image_to_string(image, config=config)
                    if text.strip():
                        all_texts.append(text.strip())
                except:
                    continue
            
            # Combine all extracted texts
            if all_texts:
                # Use the longest extraction as primary, but combine unique parts
                combined_text = " ".join(all_texts)
                return combined_text
            else:
                return ""
                
        except Exception as e:
            logger.error(f"Enhanced text extraction error: {e}")
            return ""
    
    def get_training_status(self):
        """Get current training status and available document types"""
        return {
            'available_document_types': list(self.custom_patterns['document_types'].keys()),
            'training_history': self.custom_patterns['training_history'][-10:],  # Last 10 sessions
            'total_trained_types': len(self.custom_patterns['document_types'])
        }