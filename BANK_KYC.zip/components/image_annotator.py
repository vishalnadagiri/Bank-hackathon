#!/usr/bin/env python3
"""
Interactive Image Annotation Component for Field Selection
"""

import streamlit as st
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import pytesseract
import json
import logging

logger = logging.getLogger(__name__)

class ImageAnnotator:
    def __init__(self):
        self.annotations = []
        self.current_field = None
    
    def annotate_document(self, image, fields_to_extract, session_key="annotator"):
        """
        Interactive annotation interface for document fields
        """
        st.subheader("🎯 Interactive Field Annotation")
        st.markdown("**Instructions:** Select a field type, then click and drag to highlight that field in the image")
        
        # Initialize session state
        if f"{session_key}_annotations" not in st.session_state:
            st.session_state[f"{session_key}_annotations"] = []
        if f"{session_key}_current_image" not in st.session_state:
            st.session_state[f"{session_key}_current_image"] = None
        
        # Field selection
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.subheader("📋 Field Selection")
            
            selected_field = st.selectbox(
                "Select field to annotate:",
                ["Select field..."] + fields_to_extract,
                key=f"{session_key}_field_select"
            )
            
            if selected_field != "Select field...":
                st.success(f"Ready to annotate: **{selected_field}**")
                st.info("Now click on the image to select the region for this field")
            
            # Annotation controls
            st.subheader("🎛️ Controls")
            
            if st.button("🗑️ Clear All Annotations", key=f"{session_key}_clear"):
                st.session_state[f"{session_key}_annotations"] = []
                st.rerun()
            
            if st.button("💾 Save Annotations", key=f"{session_key}_save"):
                if st.session_state[f"{session_key}_annotations"]:
                    return self._process_annotations(image, st.session_state[f"{session_key}_annotations"])
                else:
                    st.error("No annotations to save!")
            
            # Show current annotations
            if st.session_state[f"{session_key}_annotations"]:
                st.subheader("📍 Current Annotations")
                for i, annotation in enumerate(st.session_state[f"{session_key}_annotations"]):
                    col_field, col_action = st.columns([3, 1])
                    with col_field:
                        st.write(f"**{annotation['field']}:** {annotation['text'][:30]}...")
                    with col_action:
                        if st.button("❌", key=f"delete_{i}_{session_key}"):
                            st.session_state[f"{session_key}_annotations"].pop(i)
                            st.rerun()
        
        with col2:
            st.subheader("📄 Document Image")
            
            # Convert image for display
            if isinstance(image, Image.Image):
                display_image = image.copy()
            else:
                display_image = Image.fromarray(image)
            
            # Draw existing annotations on image
            display_image = self._draw_annotations(display_image, st.session_state[f"{session_key}_annotations"])
            
            # Display image with click handling
            self._display_clickable_image(display_image, image, selected_field, session_key)
        
        return None
    
    def _display_clickable_image(self, display_image, original_image, selected_field, session_key):
        """Display image with click-to-annotate functionality"""
        
        # For now, we'll use a simpler coordinate input method
        # Since Streamlit doesn't have native click-and-drag for images
        st.image(display_image, use_column_width=True)
        
        st.markdown("**Manual Coordinate Selection:**")
        st.info("Use the coordinate inputs below to select regions, or use the automatic field detection")
        
        # Coordinate input method
        if selected_field != "Select field...":
            with st.expander(f"📍 Manual Region Selection for {selected_field}"):
                col_coords1, col_coords2 = st.columns(2)
                
                with col_coords1:
                    x1 = st.number_input("Top-left X", min_value=0, max_value=display_image.width, value=0, key=f"x1_{session_key}")
                    y1 = st.number_input("Top-left Y", min_value=0, max_value=display_image.height, value=0, key=f"y1_{session_key}")
                
                with col_coords2:
                    x2 = st.number_input("Bottom-right X", min_value=0, max_value=display_image.width, value=100, key=f"x2_{session_key}")
                    y2 = st.number_input("Bottom-right Y", min_value=0, max_value=display_image.height, value=30, key=f"y2_{session_key}")
                
                if st.button(f"📍 Add {selected_field} Annotation", key=f"add_manual_{session_key}"):
                    # Extract text from selected region
                    region_text = self._extract_text_from_region(original_image, x1, y1, x2, y2)
                    
                    annotation = {
                        'field': selected_field,
                        'coordinates': {'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2},
                        'text': region_text,
                        'confidence': 0.9  # Manual selection gets high confidence
                    }
                    
                    st.session_state[f"{session_key}_annotations"].append(annotation)
                    st.success(f"Added annotation for {selected_field}: '{region_text}'")
                    st.rerun()
        
        # Automatic field detection
        st.markdown("**Or use Automatic Field Detection:**")
        if st.button("🤖 Auto-detect All Fields", key=f"auto_detect_{session_key}"):
            auto_annotations = self._auto_detect_fields(original_image, ["name", "id_number", "employee_id", "date_of_birth", "department", "gender"])
            
            if auto_annotations:
                st.session_state[f"{session_key}_annotations"].extend(auto_annotations)
                st.success(f"Auto-detected {len(auto_annotations)} fields!")
                st.rerun()
            else:
                st.warning("No fields auto-detected. Try manual selection.")
    
    def _extract_text_from_region(self, image, x1, y1, x2, y2):
        """Extract text from a specific region of the image"""
        try:
            # Convert PIL to numpy if needed
            if isinstance(image, Image.Image):
                img_array = np.array(image)
            else:
                img_array = image
            
            # Crop region
            region = img_array[y1:y2, x1:x2]
            
            # Convert back to PIL for OCR
            region_pil = Image.fromarray(region)
            
            # Extract text
            text = pytesseract.image_to_string(region_pil, config='--psm 7').strip()
            
            return text if text else "No text detected"
            
        except Exception as e:
            logger.error(f"Region text extraction error: {e}")
            return "Extraction failed"
    
    def _auto_detect_fields(self, image, field_types):
        """Automatically detect and locate fields in the image"""
        try:
            # Get text with bounding boxes
            if isinstance(image, Image.Image):
                img_array = np.array(image)
            else:
                img_array = image
                image = Image.fromarray(img_array)
            
            # Use pytesseract to get word-level data
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            
            auto_annotations = []
            
            # Enhanced field patterns for auto-detection
            field_patterns = {
                'name': [
                    r'(?:Name|NAME|नाम)[:\s]*([A-Za-z\s\.]{3,50})',
                    r'([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)'
                ],
                'id_number': [
                    r'(?:ID|Identity|Card)[:\s]*([A-Z0-9]{6,20})',
                    r'([A-Z]{5}[0-9]{4}[A-Z])',
                    r'([0-9]{12})',
                    r'([A-Z]{2}[0-9]{13})'
                ],
                'employee_id': [
                    r'(?:Employee|EMP)[:\s]*(?:ID|No)[:\s]*([A-Z0-9]{3,15})',
                    r'(EMP[0-9]{3,10})'
                ],
                'date_of_birth': [
                    r'(?:DOB|Birth)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})'
                ],
                'department': [
                    r'(?:Department|Dept)[:\s]*([A-Za-z\s]{3,30})'
                ],
                'gender': [
                    r'(?:Gender|Sex)[:\s]*([MF]|Male|Female)'
                ]
            }
            
            # Get full text
            full_text = pytesseract.image_to_string(image)
            
            # Find patterns and their approximate locations
            for field_type in field_types:
                if field_type in field_patterns:
                    for pattern in field_patterns[field_type]:
                        import re
                        match = re.search(pattern, full_text, re.IGNORECASE)
                        if match:
                            matched_text = match.group(1) if len(match.groups()) > 0 else match.group(0)
                            
                            # Find approximate location using OCR word data
                            location = self._find_text_location(matched_text, data)
                            
                            if location:
                                annotation = {
                                    'field': field_type,
                                    'coordinates': location,
                                    'text': matched_text.strip(),
                                    'confidence': 0.8
                                }
                                auto_annotations.append(annotation)
                                break  # Found one match for this field type
            
            return auto_annotations
            
        except Exception as e:
            logger.error(f"Auto-detection error: {e}")
            return []
    
    def _find_text_location(self, text, ocr_data):
        """Find the approximate location of text in OCR data"""
        try:
            text_words = text.lower().split()
            if not text_words:
                return None
            
            # Look for the first word of the text in OCR data
            target_word = text_words[0]
            
            for i, word in enumerate(ocr_data['text']):
                if word.lower().strip() == target_word and int(ocr_data['conf'][i]) > 30:
                    x = int(ocr_data['left'][i])
                    y = int(ocr_data['top'][i])
                    w = int(ocr_data['width'][i])
                    h = int(ocr_data['height'][i])
                    
                    # Expand region to include full text
                    expanded_w = w * len(text_words) + 50
                    
                    return {
                        'x1': x,
                        'y1': y,
                        'x2': x + expanded_w,
                        'y2': y + h
                    }
            
            return None
            
        except Exception as e:
            logger.error(f"Text location finding error: {e}")
            return None
    
    def _draw_annotations(self, image, annotations):
        """Draw annotation boxes on the image"""
        if not annotations:
            return image
        
        # Convert to drawable format
        draw_image = image.copy()
        draw = ImageDraw.Draw(draw_image)
        
        # Different colors for different fields
        colors = ['red', 'blue', 'green', 'orange', 'purple', 'brown', 'pink', 'gray']
        
        for i, annotation in enumerate(annotations):
            coords = annotation['coordinates']
            color = colors[i % len(colors)]
            
            # Draw rectangle
            draw.rectangle(
                [coords['x1'], coords['y1'], coords['x2'], coords['y2']],
                outline=color,
                width=3
            )
            
            # Draw label
            try:
                font = ImageFont.truetype("arial.ttf", 16)
            except:
                font = ImageFont.load_default()
            
            draw.text(
                (coords['x1'], coords['y1'] - 20),
                annotation['field'],
                fill=color,
                font=font
            )
        
        return draw_image
    
    def _process_annotations(self, image, annotations):
        """Process annotations and return structured training data"""
        try:
            training_data = {}
            
            for annotation in annotations:
                field_name = annotation['field']
                text_value = annotation['text']
                coordinates = annotation['coordinates']
                
                # Store both text and location info
                training_data[field_name] = {
                    'value': text_value,
                    'coordinates': coordinates,
                    'confidence': annotation['confidence']
                }
            
            return {
                'success': True,
                'training_data': training_data,
                'annotation_count': len(annotations)
            }
            
        except Exception as e:
            logger.error(f"Annotation processing error: {e}")
            return {
                'success': False,
                'error': str(e)
            }