# AI-powered Banking KYC Upload & Verification

Run with `docker compose up --build`.