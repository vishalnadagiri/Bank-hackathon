
import streamlit as st
from services.auth_service import login_user
from services.kyc_service import is_kyc_done, update_kyc
import os

def login_tab():
    st.subheader("Login & KYC")

    reg = st.text_input("Registered Number")
    mobile = st.text_input("Mobile Number")

    if st.button("Login"):
        user = login_user(reg, mobile)
        if user:
            st.success("Welcome to the bank")
        else:
            st.error("Invalid credentials")

    st.divider()
    st.write("Do KYC")
    doc = st.file_uploader("Upload KYC Document")

    if st.button("Submit KYC") and doc:
        if is_kyc_done(reg):
            st.warning("KYC already done")
        else:
            os.makedirs("uploads/kyc_docs", exist_ok=True)
            path = f"uploads/kyc_docs/{doc.name}"
            with open(path, "wb") as f:
                f.write(doc.read())
            update_kyc(reg, path)
            st.success("KYC completed")
