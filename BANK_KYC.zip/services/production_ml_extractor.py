#!/usr/bin/env python3
"""
Production-Ready ML Document Extractor
Combines multiple ML models with fallback mechanisms
"""

import cv2
import numpy as np
from PIL import Image
import pytesseract
import re
import logging
from datetime import datetime
import time
import json
from pathlib import Path

logger = logging.getLogger(__name__)

class ProductionMLExtractor:
    def __init__(self):
        """Initialize production ML extractor with multiple models"""
        self.extraction_attempts = 0
        self.max_attempts = 5
        self.models_available = self._check_available_models()
        self.extraction_history = []
        
    def _check_available_models(self):
        """Check which ML models are available"""
        available = {
            'enhanced_ocr': True,  # Always available
            'paddleocr': False,
            'easyocr': False,
            'transformers': False
        }
        
        try:
            from paddleocr import PaddleOCR
            available['paddleocr'] = True
            logger.info("PaddleOCR available")
        except ImportError:
            logger.warning("PaddleOCR not available")
        
        try:
            import easyocr
            available['easyocr'] = True
            logger.info("EasyOCR available")
        except ImportError:
            logger.warning("EasyOCR not available")
        
        try:
            from transformers import TrOCRProcessor
            available['transformers'] = True
            logger.info("Transformers available")
        except ImportError:
            logger.warning("Transformers not available")
        
        return available
    
    def extract_document_with_retry(self, image, document_type="auto", user_session_id=None):
        """
        Main extraction method with 5-attempt retry logic
        """
        session_id = user_session_id or f"session_{int(time.time())}"
        
        result = {
            'success': False,
            'extracted_data': {},
            'confidence_score': 0,
            'attempts_used': 0,
            'extraction_methods_tried': [],
            'session_id': session_id,
            'final_recommendation': None
        }
        
        # Reset attempt counter for new session
        self.extraction_attempts = 0
        
        # Try different extraction methods
        extraction_methods = self._get_extraction_methods()
        
        for attempt in range(self.max_attempts):
            self.extraction_attempts += 1
            result['attempts_used'] = self.extraction_attempts
            
            logger.info(f"Attempt {self.extraction_attempts}/{self.max_attempts} for session {session_id}")
            
            # Try each available method
            for method_name, method_func in extraction_methods:
                try:
                    method_result = method_func(image, document_type)
                    
                    result['extraction_methods_tried'].append({
                        'method': method_name,
                        'attempt': self.extraction_attempts,
                        'success': method_result.get('success', False),
                        'confidence': method_result.get('confidence_score', 0)
                    })
                    
                    # Check if extraction was successful
                    if (method_result.get('success', False) and 
                        method_result.get('confidence_score', 0) > 70 and
                        len(method_result.get('extracted_data', {})) >= 2):
                        
                        result['success'] = True
                        result['extracted_data'] = method_result['extracted_data']
                        result['confidence_score'] = method_result['confidence_score']
                        result['winning_method'] = method_name
                        
                        logger.info(f"Successful extraction with {method_name} on attempt {self.extraction_attempts}")
                        self._log_extraction_success(session_id, method_name, result)
                        return result
                
                except Exception as e:
                    logger.error(f"Error in {method_name}: {e}")
                    continue
            
            # If we reach here, this attempt failed
            logger.warning(f"Attempt {self.extraction_attempts} failed, trying enhanced preprocessing...")
            
            # Try with enhanced preprocessing for next attempt
            image = self._apply_progressive_enhancement(image, attempt)
        
        # All attempts failed
        result['final_recommendation'] = self._generate_failure_recommendation(result)
        self._log_extraction_failure(session_id, result)
        
        return result
    
    def _get_extraction_methods(self):
        """Get available extraction methods in order of preference"""
        methods = []
        
        # Method 1: PaddleOCR (Best for Indian documents)
        if self.models_available['paddleocr']:
            methods.append(('PaddleOCR', self._extract_with_paddleocr))
        
        # Method 2: Enhanced OCR (Always available)
        methods.append(('Enhanced_OCR', self._extract_with_enhanced_ocr))
        
        # Method 3: EasyOCR (Good multilingual)
        if self.models_available['easyocr']:
            methods.append(('EasyOCR', self._extract_with_easyocr))
        
        # Method 4: Specialized pattern matching
        methods.append(('Pattern_Matching', self._extract_with_patterns))
        
        return methods
    
    def _extract_with_paddleocr(self, image, document_type):
        """Extract using PaddleOCR"""
        try:
            from paddleocr import PaddleOCR
            
            # Initialize PaddleOCR
            ocr = PaddleOCR(use_angle_cls=True, lang='en', show_log=False)
            
            # Convert PIL to numpy if needed
            if isinstance(image, Image.Image):
                img_array = np.array(image)
            else:
                img_array = image
            
            # Extract text with PaddleOCR
            results = ocr.ocr(img_array, cls=True)
            
            # Process results
            extracted_text = ""
            for line in results[0] if results[0] else []:
                text = line[1][0]  # Extract text
                confidence = line[1][1]  # Extract confidence
                if confidence > 0.5:  # Only use high confidence text
                    extracted_text += text + " "
            
            # Apply document-specific patterns
            extracted_data = self._apply_document_patterns(extracted_text, document_type)
            
            # Calculate confidence score
            confidence_score = self._calculate_paddleocr_confidence(results, extracted_data)
            
            return {
                'success': len(extracted_data) > 0,
                'extracted_data': extracted_data,
                'confidence_score': confidence_score,
                'method': 'PaddleOCR',
                'raw_text': extracted_text.strip()
            }
            
        except Exception as e:
            logger.error(f"PaddleOCR extraction error: {e}")
            return {'success': False, 'error': str(e)}
    
    def _extract_with_enhanced_ocr(self, image, document_type):
        """Extract using enhanced Tesseract OCR"""
        try:
            # Apply document-specific preprocessing
            processed_image = self._preprocess_for_document_type(image, document_type)
            
            # Try multiple OCR configurations
            configs = [
                '--oem 3 --psm 6',
                '--oem 3 --psm 4',
                '--oem 3 --psm 11',
                '--oem 3 --psm 13'
            ]
            
            best_result = {'text': '', 'confidence': 0}
            
            for config in configs:
                try:
                    text = pytesseract.image_to_string(processed_image, config=config)
                    # Simple confidence estimation based on text length and readability
                    confidence = min(len(text.strip()) / 100, 1.0) * 80
                    
                    if confidence > best_result['confidence']:
                        best_result = {'text': text, 'confidence': confidence}
                except:
                    continue
            
            # Apply patterns
            extracted_data = self._apply_document_patterns(best_result['text'], document_type)
            
            return {
                'success': len(extracted_data) > 0,
                'extracted_data': extracted_data,
                'confidence_score': best_result['confidence'],
                'method': 'Enhanced_OCR',
                'raw_text': best_result['text']
            }
            
        except Exception as e:
            logger.error(f"Enhanced OCR error: {e}")
            return {'success': False, 'error': str(e)}
    
    def _extract_with_easyocr(self, image, document_type):
        """Extract using EasyOCR"""
        try:
            import easyocr
            
            # Initialize EasyOCR
            reader = easyocr.Reader(['en', 'hi'])
            
            # Convert PIL to numpy if needed
            if isinstance(image, Image.Image):
                img_array = np.array(image)
            else:
                img_array = image
            
            # Extract text
            results = reader.readtext(img_array)
            
            # Process results
            extracted_text = ""
            total_confidence = 0
            
            for (bbox, text, confidence) in results:
                if confidence > 0.5:
                    extracted_text += text + " "
                    total_confidence += confidence
            
            avg_confidence = (total_confidence / len(results)) * 100 if results else 0
            
            # Apply patterns
            extracted_data = self._apply_document_patterns(extracted_text, document_type)
            
            return {
                'success': len(extracted_data) > 0,
                'extracted_data': extracted_data,
                'confidence_score': avg_confidence,
                'method': 'EasyOCR',
                'raw_text': extracted_text.strip()
            }
            
        except Exception as e:
            logger.error(f"EasyOCR extraction error: {e}")
            return {'success': False, 'error': str(e)}
    
    def _extract_with_patterns(self, image, document_type):
        """Extract using pure pattern matching on basic OCR"""
        try:
            # Basic OCR extraction
            text = pytesseract.image_to_string(image)
            
            # Apply aggressive pattern matching
            extracted_data = self._apply_aggressive_patterns(text, document_type)
            
            # Calculate confidence based on pattern matches
            confidence = len(extracted_data) * 15  # Simple scoring
            
            return {
                'success': len(extracted_data) > 0,
                'extracted_data': extracted_data,
                'confidence_score': min(confidence, 90),
                'method': 'Pattern_Matching',
                'raw_text': text
            }
            
        except Exception as e:
            logger.error(f"Pattern matching error: {e}")
            return {'success': False, 'error': str(e)}
    
    def _apply_document_patterns(self, text, document_type):
        """Apply document-specific extraction patterns"""
        extracted_data = {}
        
        # Auto-detect document type if needed
        if document_type == "auto":
            document_type = self._detect_document_type(text)
        
        if document_type in ['aadhaar', 'auto']:
            # Aadhaar patterns
            patterns = {
                'aadhaar_number': [
                    r'([0-9]{4}\s*[0-9]{4}\s*[0-9]{4})',
                    r'([0-9]{12})'
                ],
                'name': [
                    r'(?:नाम|Name)[:\s]*([A-Za-z\s\.]{2,50})',
                    r'([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)'
                ],
                'father_name': [
                    r'(?:पिता|Father|S/O)[:\s]*([A-Za-z\s]{2,50})'
                ],
                'dob': [
                    r'(?:DOB|Birth|जन्म)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][0-9]{4})'
                ],
                'gender': [
                    r'(?:लिंग|Gender)[:\s]*([MF]|Male|Female|पुरुष|महिला)'
                ]
            }
            
            for field, field_patterns in patterns.items():
                for pattern in field_patterns:
                    try:
                        match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
                        if match:
                            extracted_data[field] = match.group(1).strip()
                            break
                    except:
                        continue
        
        if document_type in ['pan', 'auto']:
            # PAN patterns
            pan_patterns = {
                'pan_number': [
                    r'([A-Z]{5}[0-9]{4}[A-Z])',
                    r'(?:PAN)[:\s]*([A-Z]{5}[0-9]{4}[A-Z])'
                ],
                'name': [
                    r'(?:Name)[:\s]*([A-Z\s]{2,50})',
                    r'([A-Z][A-Z\s]+[A-Z])'
                ],
                'father_name': [
                    r'(?:Father)[:\s]*([A-Z\s]{2,50})'
                ],
                'dob': [
                    r'(?:DOB)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][0-9]{4})'
                ]
            }
            
            for field, field_patterns in pan_patterns.items():
                for pattern in field_patterns:
                    try:
                        match = re.search(pattern, text, re.IGNORECASE)
                        if match:
                            extracted_data[field] = match.group(1).strip()
                            break
                    except:
                        continue
        
        return extracted_data
    
    def _apply_aggressive_patterns(self, text, document_type):
        """Apply more aggressive pattern matching for difficult cases"""
        extracted_data = {}
        
        # Find all numbers and categorize them
        numbers = re.findall(r'\d+', text)
        
        # Look for 12-digit numbers (potential Aadhaar)
        for num in numbers:
            if len(num) == 12:
                extracted_data['aadhaar_number'] = num
                break
        
        # Look for PAN pattern
        pan_match = re.search(r'[A-Z]{5}\d{4}[A-Z]', text)
        if pan_match:
            extracted_data['pan_number'] = pan_match.group(0)
        
        # Look for names (capitalize words)
        name_candidates = re.findall(r'[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*', text)
        for candidate in name_candidates:
            if len(candidate) > 5 and candidate not in ['Date', 'Birth', 'Government', 'India']:
                extracted_data['name'] = candidate
                break
        
        # Look for dates
        date_match = re.search(r'\d{2}[/-]\d{2}[/-]\d{4}', text)
        if date_match:
            extracted_data['dob'] = date_match.group(0)
        
        return extracted_data
    
    def _detect_document_type(self, text):
        """Auto-detect document type from text content"""
        text_lower = text.lower()
        
        if any(keyword in text_lower for keyword in ['aadhaar', 'आधार', 'uid', 'unique identification']):
            return 'aadhaar'
        elif any(keyword in text_lower for keyword in ['pan', 'permanent account', 'income tax']):
            return 'pan'
        else:
            return 'unknown'
    
    def _preprocess_for_document_type(self, image, document_type):
        """Apply document-specific preprocessing"""
        try:
            if isinstance(image, Image.Image):
                img_array = np.array(image)
            else:
                img_array = image
            
            # Common preprocessing
            if len(img_array.shape) == 3:
                gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
            else:
                gray = img_array
            
            # Document-specific enhancements
            if document_type == 'aadhaar':
                # Aadhaar-specific preprocessing
                clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
                enhanced = clahe.apply(gray)
                denoised = cv2.bilateralFilter(enhanced, 9, 75, 75)
                binary = cv2.adaptiveThreshold(denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
                
            elif document_type == 'pan':
                # PAN-specific preprocessing
                enhanced = cv2.equalizeHist(gray)
                blurred = cv2.GaussianBlur(enhanced, (1, 1), 0)
                _, binary = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
                
            else:
                # Generic preprocessing
                binary = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
            
            return Image.fromarray(binary)
            
        except Exception as e:
            logger.error(f"Preprocessing error: {e}")
            return image
    
    def _apply_progressive_enhancement(self, image, attempt_number):
        """Apply progressive image enhancement based on attempt number"""
        try:
            if isinstance(image, Image.Image):
                img_array = np.array(image)
            else:
                img_array = image
            
            # Progressive enhancement based on attempt
            if attempt_number == 0:
                # First attempt - basic enhancement
                enhanced = img_array
                
            elif attempt_number == 1:
                # Second attempt - contrast enhancement
                if len(img_array.shape) == 3:
                    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
                else:
                    gray = img_array
                enhanced = cv2.equalizeHist(gray)
                
            elif attempt_number == 2:
                # Third attempt - noise reduction
                if len(img_array.shape) == 3:
                    enhanced = cv2.bilateralFilter(img_array, 9, 75, 75)
                else:
                    enhanced = cv2.bilateralFilter(img_array, 9, 75, 75)
                
            elif attempt_number == 3:
                # Fourth attempt - morphological operations
                if len(img_array.shape) == 3:
                    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
                else:
                    gray = img_array
                kernel = np.ones((2,2), np.uint8)
                enhanced = cv2.morphologyEx(gray, cv2.MORPH_CLOSE, kernel)
                
            else:
                # Fifth attempt - aggressive preprocessing
                if len(img_array.shape) == 3:
                    gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
                else:
                    gray = img_array
                
                # Apply all techniques
                clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
                enhanced = clahe.apply(gray)
                enhanced = cv2.bilateralFilter(enhanced, 9, 75, 75)
                kernel = np.ones((1,1), np.uint8)
                enhanced = cv2.morphologyEx(enhanced, cv2.MORPH_CLOSE, kernel)
            
            return Image.fromarray(enhanced)
            
        except Exception as e:
            logger.error(f"Progressive enhancement error: {e}")
            return image
    
    def _calculate_paddleocr_confidence(self, results, extracted_data):
        """Calculate confidence score for PaddleOCR results"""
        if not results or not results[0]:
            return 0
        
        total_confidence = 0
        text_count = 0
        
        for line in results[0]:
            confidence = line[1][1]
            total_confidence += confidence
            text_count += 1
        
        base_confidence = (total_confidence / text_count * 100) if text_count > 0 else 0
        
        # Boost confidence if we extracted expected fields
        field_boost = len(extracted_data) * 5
        
        return min(base_confidence + field_boost, 95)
    
    def _generate_failure_recommendation(self, result):
        """Generate recommendations when extraction fails"""
        methods_tried = [m['method'] for m in result['extraction_methods_tried']]
        
        recommendations = {
            'message': 'Document extraction failed after 5 attempts',
            'suggestions': [
                '📸 Take a clearer, well-lit photo',
                '📐 Ensure document is straight and fills the frame',
                '🔍 Check that all text is clearly visible',
                '💡 Try better lighting or avoid shadows',
                '📱 Use higher camera resolution if possible'
            ],
            'next_steps': [
                '👨‍💼 Contact admin for manual processing',
                '🔄 Try uploading a different photo of the same document',
                '📞 Call support for assistance'
            ],
            'methods_tried': methods_tried,
            'technical_info': 'Multiple ML models and preprocessing techniques were attempted'
        }
        
        return recommendations
    
    def _log_extraction_success(self, session_id, method, result):
        """Log successful extraction for analytics"""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'session_id': session_id,
            'success': True,
            'winning_method': method,
            'attempts_used': result['attempts_used'],
            'confidence_score': result['confidence_score'],
            'fields_extracted': list(result['extracted_data'].keys())
        }
        
        self.extraction_history.append(log_entry)
        logger.info(f"Extraction success logged: {session_id}")
    
    def _log_extraction_failure(self, session_id, result):
        """Log failed extraction for analytics"""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'session_id': session_id,
            'success': False,
            'attempts_used': result['attempts_used'],
            'methods_tried': [m['method'] for m in result['extraction_methods_tried']],
            'failure_reason': 'All extraction methods failed'
        }
        
        self.extraction_history.append(log_entry)
        logger.warning(f"Extraction failure logged: {session_id}")
    
    def get_system_stats(self):
        """Get system statistics for admin panel"""
        if not self.extraction_history:
            return {'total_extractions': 0, 'success_rate': 0, 'avg_attempts': 0}
        
        total = len(self.extraction_history)
        successful = sum(1 for entry in self.extraction_history if entry['success'])
        
        success_rate = (successful / total * 100) if total > 0 else 0
        
        successful_entries = [entry for entry in self.extraction_history if entry['success']]
        avg_attempts = (sum(entry['attempts_used'] for entry in successful_entries) / len(successful_entries)) if successful_entries else 0
        
        return {
            'total_extractions': total,
            'success_rate': success_rate,
            'avg_attempts': avg_attempts,
            'available_models': self.models_available
        }