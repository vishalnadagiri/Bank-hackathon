#!/usr/bin/env python3
"""
OCR Debugging and Improvement System
Helps diagnose and fix OCR extraction issues
"""

import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
import pytesseract
import re
import logging
import matplotlib.pyplot as plt
from pathlib import Path
import json

logger = logging.getLogger(__name__)

class OCRDebugger:
    def __init__(self):
        self.debug_dir = Path("data/ocr_debug")
        self.debug_dir.mkdir(parents=True, exist_ok=True)
        
    def full_diagnostic(self, image, document_type="unknown"):
        """
        Complete diagnostic of OCR extraction issues
        """
        print("🔍 STARTING OCR DIAGNOSTIC")
        print("=" * 50)
        
        # Convert PIL to numpy if needed
        if isinstance(image, Image.Image):
            img_array = np.array(image)
        else:
            img_array = image
        
        diagnostic_results = {
            'original_image_quality': self._analyze_image_quality(img_array),
            'preprocessing_results': self._test_preprocessing_methods(image),
            'ocr_extraction_tests': self._test_multiple_ocr_configs(image),
            'pattern_matching_tests': self._test_pattern_matching(image),
            'recommendations': []
        }
        
        # Generate recommendations
        diagnostic_results['recommendations'] = self._generate_recommendations(diagnostic_results)
        
        return diagnostic_results
    
    def _analyze_image_quality(self, img_array):
        """Analyze the quality of the input image"""
        print("📊 Analyzing image quality...")
        
        if len(img_array.shape) == 3:
            gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
        else:
            gray = img_array
        
        # Calculate various quality metrics
        height, width = gray.shape
        
        # Sharpness (Laplacian variance)
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        
        # Brightness
        brightness = np.mean(gray)
        
        # Contrast (standard deviation)
        contrast = np.std(gray)
        
        # Resolution check
        resolution_score = min(width * height / 240000, 1.0)  # 800x600 as reference
        
        quality_analysis = {
            'dimensions': {'width': width, 'height': height},
            'sharpness_score': laplacian_var,
            'brightness_score': brightness,
            'contrast_score': contrast,
            'resolution_score': resolution_score,
            'issues': [],
            'overall_quality': 'good'
        }
        
        # Identify issues
        if laplacian_var < 100:
            quality_analysis['issues'].append("Image is blurry or out of focus")
            quality_analysis['overall_quality'] = 'poor'
        
        if brightness < 50:
            quality_analysis['issues'].append("Image too dark")
            quality_analysis['overall_quality'] = 'poor'
        elif brightness > 200:
            quality_analysis['issues'].append("Image too bright/overexposed")
            quality_analysis['overall_quality'] = 'poor'
        
        if contrast < 30:
            quality_analysis['issues'].append("Low contrast")
            quality_analysis['overall_quality'] = 'poor'
        
        if resolution_score < 0.5:
            quality_analysis['issues'].append("Resolution too low")
            quality_analysis['overall_quality'] = 'poor'
        
        print(f"  📏 Dimensions: {width}x{height}")
        print(f"  🔍 Sharpness: {laplacian_var:.1f}")
        print(f"  💡 Brightness: {brightness:.1f}")
        print(f"  🌈 Contrast: {contrast:.1f}")
        print(f"  ⭐ Overall Quality: {quality_analysis['overall_quality']}")
        
        if quality_analysis['issues']:
            print("  ⚠️ Issues found:")
            for issue in quality_analysis['issues']:
                print(f"    - {issue}")
        
        return quality_analysis
    
    def _test_preprocessing_methods(self, image):
        """Test different preprocessing methods"""
        print("\n🔧 Testing preprocessing methods...")
        
        preprocessing_results = {}
        
        # Convert to PIL if needed
        if isinstance(image, np.ndarray):
            pil_image = Image.fromarray(image)
        else:
            pil_image = image
        
        # Test different preprocessing approaches
        methods = {
            'original': pil_image,
            'enhanced_contrast': self._enhance_contrast(pil_image),
            'enhanced_sharpness': self._enhance_sharpness(pil_image),
            'grayscale_optimized': self._optimize_grayscale(pil_image),
            'noise_reduced': self._reduce_noise(pil_image),
            'adaptive_threshold': self._adaptive_threshold(pil_image),
            'morphological_cleaned': self._morphological_clean(pil_image)
        }
        
        for method_name, processed_image in methods.items():
            try:
                # Extract text with basic config
                text = pytesseract.image_to_string(processed_image, config='--psm 6')
                text_length = len(text.strip())
                word_count = len(text.split())
                
                preprocessing_results[method_name] = {
                    'text_length': text_length,
                    'word_count': word_count,
                    'extracted_text': text[:200] + "..." if len(text) > 200 else text,
                    'quality_score': text_length * 0.1 + word_count * 2  # Simple scoring
                }
                
                print(f"  📝 {method_name}: {word_count} words, {text_length} chars")
                
            except Exception as e:
                preprocessing_results[method_name] = {
                    'error': str(e),
                    'quality_score': 0
                }
                print(f"  ❌ {method_name}: Failed - {e}")
        
        # Find best method
        best_method = max(preprocessing_results.keys(), 
                         key=lambda k: preprocessing_results[k].get('quality_score', 0))
        
        print(f"  🏆 Best method: {best_method}")
        
        return {
            'methods': preprocessing_results,
            'best_method': best_method,
            'best_image': methods[best_method]
        }
    
    def _test_multiple_ocr_configs(self, image):
        """Test different OCR configurations"""
        print("\n⚙️ Testing OCR configurations...")
        
        configs = {
            'default': '--psm 6',
            'single_uniform_block': '--psm 6 --oem 3',
            'single_text_line': '--psm 7',
            'single_word': '--psm 8',
            'single_character': '--psm 10',
            'sparse_text': '--psm 11',
            'single_column': '--psm 4',
            'vertical_text': '--psm 5',
            'treat_as_single_char': '--psm 10',
            'raw_line_no_spaces': '--psm 13'
        }
        
        ocr_results = {}
        
        for config_name, config in configs.items():
            try:
                text = pytesseract.image_to_string(image, config=config)
                word_count = len(text.split())
                char_count = len(text.strip())
                
                ocr_results[config_name] = {
                    'text': text,
                    'word_count': word_count,
                    'char_count': char_count,
                    'quality_score': word_count * 2 + char_count * 0.1
                }
                
                print(f"  📄 {config_name}: {word_count} words, {char_count} chars")
                
            except Exception as e:
                ocr_results[config_name] = {
                    'error': str(e),
                    'quality_score': 0
                }
                print(f"  ❌ {config_name}: Failed - {e}")
        
        # Find best configuration
        best_config = max(ocr_results.keys(), 
                         key=lambda k: ocr_results[k].get('quality_score', 0))
        
        print(f"  🏆 Best config: {best_config}")
        
        return {
            'configs': ocr_results,
            'best_config': best_config,
            'best_text': ocr_results[best_config].get('text', '')
        }
    
    def _test_pattern_matching(self, image):
        """Test pattern matching for common document fields"""
        print("\n🎯 Testing pattern matching...")
        
        # Extract text using best method found earlier
        text = pytesseract.image_to_string(image, config='--psm 6')
        
        # Define comprehensive patterns
        patterns = {
            'name': [
                r'(?:Name|NAME|नाम)[:\s]*([A-Za-z\s\.]{2,50})',
                r'([A-Z][a-z]+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)',
                r'(?:श्री|श्रीमती)\s+([A-Za-z\s]+)'
            ],
            'id_number': [
                r'(?:ID|Identity|Card|आईडी).*?(?:No|Number|संख्या)[:\s]*([A-Z0-9]{6,20})',
                r'([A-Z]{5}[0-9]{4}[A-Z])',  # PAN
                r'([0-9]{4}\s*[0-9]{4}\s*[0-9]{4})',  # Aadhaar
                r'([A-Z]{2}[0-9]{13})',  # DL
            ],
            'date': [
                r'([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})',
                r'([0-3][0-9][/-][0-1][0-9][/-][0-9]{2})',
                r'(?:DOB|Birth|जन्म)[:\s]*([0-3][0-9][/-][0-1][0-9][/-][1-2][0-9]{3})'
            ],
            'phone': [
                r'(?:Phone|Mobile|Tel|फोन)[:\s]*([0-9\s\-\+]{10,15})',
                r'([0-9]{10})',
                r'(\+91[0-9]{10})'
            ],
            'email': [
                r'([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})'
            ],
            'pincode': [
                r'(?:PIN|Pincode|पिन)[:\s]*([0-9]{6})',
                r'([0-9]{6})'
            ]
        }
        
        pattern_results = {}
        
        for field, field_patterns in patterns.items():
            matches = []
            for pattern in field_patterns:
                try:
                    found_matches = re.findall(pattern, text, re.IGNORECASE | re.MULTILINE)
                    matches.extend(found_matches)
                except Exception as e:
                    print(f"    ❌ Pattern error for {field}: {e}")
            
            # Clean and deduplicate matches
            clean_matches = list(set([match.strip() for match in matches if match.strip()]))
            
            pattern_results[field] = {
                'matches': clean_matches,
                'match_count': len(clean_matches),
                'confidence': min(len(clean_matches) * 0.3, 1.0)
            }
            
            if clean_matches:
                print(f"  ✅ {field}: Found {len(clean_matches)} matches")
                for match in clean_matches[:3]:  # Show first 3
                    print(f"    - '{match}'")
            else:
                print(f"  ❌ {field}: No matches found")
        
        return pattern_results
    
    def _generate_recommendations(self, diagnostic_results):
        """Generate specific recommendations based on diagnostic results"""
        recommendations = []
        
        # Image quality recommendations
        quality = diagnostic_results['original_image_quality']
        if quality['sharpness_score'] < 100:
            recommendations.append("📸 Take a sharper photo - ensure the document is in focus")
        if quality['brightness_score'] < 50:
            recommendations.append("💡 Increase lighting - the image is too dark")
        if quality['brightness_score'] > 200:
            recommendations.append("🌞 Reduce lighting - the image is overexposed")
        if quality['contrast_score'] < 30:
            recommendations.append("🌈 Improve contrast - try different lighting angles")
        
        # Preprocessing recommendations
        best_method = diagnostic_results['preprocessing_results']['best_method']
        if best_method != 'original':
            recommendations.append(f"🔧 Use {best_method} preprocessing for better results")
        
        # OCR configuration recommendations
        best_config = diagnostic_results['ocr_extraction_tests']['best_config']
        if best_config != 'default':
            recommendations.append(f"⚙️ Use {best_config} OCR configuration")
        
        # Pattern matching recommendations
        pattern_results = diagnostic_results['pattern_matching_tests']
        empty_fields = [field for field, data in pattern_results.items() if data['match_count'] == 0]
        if len(empty_fields) > 2:
            recommendations.append("🎯 Consider training custom patterns for this document type")
        
        return recommendations
    
    # Helper methods for preprocessing
    def _enhance_contrast(self, image):
        enhancer = ImageEnhance.Contrast(image)
        return enhancer.enhance(1.5)
    
    def _enhance_sharpness(self, image):
        enhancer = ImageEnhance.Sharpness(image)
        return enhancer.enhance(2.0)
    
    def _optimize_grayscale(self, image):
        return image.convert('L').convert('RGB')
    
    def _reduce_noise(self, image):
        return image.filter(ImageFilter.MedianFilter(size=3))
    
    def _adaptive_threshold(self, image):
        # Convert to OpenCV format
        img_array = np.array(image)
        if len(img_array.shape) == 3:
            gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
        else:
            gray = img_array
        
        # Apply adaptive threshold
        thresh = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
        
        # Convert back to PIL
        return Image.fromarray(thresh)
    
    def _morphological_clean(self, image):
        # Convert to OpenCV format
        img_array = np.array(image)
        if len(img_array.shape) == 3:
            gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
        else:
            gray = img_array
        
        # Apply morphological operations
        kernel = np.ones((1,1), np.uint8)
        cleaned = cv2.morphologyEx(gray, cv2.MORPH_CLOSE, kernel)
        cleaned = cv2.morphologyEx(cleaned, cv2.MORPH_OPEN, kernel)
        
        # Convert back to PIL
        return Image.fromarray(cleaned)

def quick_ocr_test(image_path):
    """Quick test function to diagnose OCR issues"""
    print("🔧 QUICK OCR DIAGNOSTIC TEST")
    print("=" * 40)
    
    try:
        # Load image
        image = Image.open(image_path)
        print(f"📂 Loaded: {image_path}")
        print(f"📏 Size: {image.size}")
        
        # Run diagnostic
        debugger = OCRDebugger()
        results = debugger.full_diagnostic(image)
        
        print("\n💡 RECOMMENDATIONS:")
        print("-" * 20)
        for rec in results['recommendations']:
            print(f"  {rec}")
        
        # Show best extracted text
        best_text = results['ocr_extraction_tests']['best_text']
        print(f"\n📝 BEST EXTRACTED TEXT:")
        print("-" * 20)
        print(best_text[:300] + "..." if len(best_text) > 300 else best_text)
        
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    # Test with a sample image
    print("OCR Debugger ready for testing!")
    print("Usage: quick_ocr_test('path_to_your_image.jpg')")