#!/usr/bin/env python3
"""
OCR Debugger Interface for Streamlit
"""

import streamlit as st
from PIL import Image
import numpy as np
from services.ocr_debugger import OCRDebugger
from services.document_extractor import DocumentExtractor
import cv2

def ocr_debugger_page():
    """OCR debugging and improvement interface"""
    st.set_page_config(page_title="OCR Debugger", page_icon="🔧", layout="wide")
    
    st.title("🔧 OCR Extraction Debugger")
    st.markdown("Upload your document to diagnose and fix extraction issues")
    
    # File upload
    uploaded_file = st.file_uploader(
        "Upload Document to Debug",
        type=['jpg', 'jpeg', 'png', 'bmp'],
        help="Upload the document that isn't extracting properly"
    )
    
    if uploaded_file is not None:
        # Display original image
        image = Image.open(uploaded_file)
        
        col1, col2 = st.columns([1, 1])
        
        with col1:
            st.subheader("📄 Original Document")
            st.image(image, use_column_width=True)
            
            # Basic image info
            st.info(f"**Image Info:**\n- Size: {image.size}\n- Mode: {image.mode}")
        
        with col2:
            st.subheader("🔍 Quick Extraction Test")
            
            if st.button("🚀 Test Current Extraction", type="primary"):
                with st.spinner("Testing current extraction..."):
                    # Test with current system
                    extractor = DocumentExtractor()
                    result = extractor.extract_document_data(image, 'id_proof')
                    
                    if result['success'] and result['extracted_data']:
                        st.success("✅ Some data extracted!")
                        for field, value in result['extracted_data'].items():
                            st.write(f"**{field}:** {value}")
                        st.write(f"**Confidence:** {result['confidence_score']:.1f}%")
                    else:
                        st.error("❌ No data extracted - needs debugging!")
        
        # Full diagnostic section
        st.markdown("---")
        st.subheader("🔬 Full Diagnostic Analysis")
        
        if st.button("🔍 Run Complete Diagnostic", type="secondary"):
            with st.spinner("Running comprehensive diagnostic..."):
                debugger = OCRDebugger()
                diagnostic = debugger.full_diagnostic(image)
                
                # Display results in tabs
                tab1, tab2, tab3, tab4, tab5 = st.tabs([
                    "📊 Image Quality", "🔧 Preprocessing", "⚙️ OCR Configs", 
                    "🎯 Pattern Matching", "💡 Recommendations"
                ])
                
                with tab1:
                    st.subheader("📊 Image Quality Analysis")
                    quality = diagnostic['original_image_quality']
                    
                    col_q1, col_q2, col_q3 = st.columns(3)
                    with col_q1:
                        st.metric("Sharpness", f"{quality['sharpness_score']:.0f}", 
                                 help="Higher is better (>100 is good)")
                    with col_q2:
                        st.metric("Brightness", f"{quality['brightness_score']:.0f}",
                                 help="50-200 is ideal range")
                    with col_q3:
                        st.metric("Contrast", f"{quality['contrast_score']:.0f}",
                                 help="Higher is better (>40 is good)")
                    
                    if quality['issues']:
                        st.error("⚠️ **Issues Found:**")
                        for issue in quality['issues']:
                            st.write(f"- {issue}")
                    else:
                        st.success("✅ Image quality looks good!")
                
                with tab2:
                    st.subheader("🔧 Preprocessing Methods Test")
                    preprocessing = diagnostic['preprocessing_results']
                    
                    st.info(f"🏆 **Best Method:** {preprocessing['best_method']}")
                    
                    # Show results table
                    methods_data = []
                    for method, data in preprocessing['methods'].items():
                        if 'quality_score' in data:
                            methods_data.append({
                                'Method': method,
                                'Words': data['word_count'],
                                'Characters': data['text_length'],
                                'Score': f"{data['quality_score']:.1f}"
                            })
                    
                    if methods_data:
                        import pandas as pd
                        df = pd.DataFrame(methods_data)
                        st.dataframe(df)
                
                with tab3:
                    st.subheader("⚙️ OCR Configuration Test")
                    ocr_test = diagnostic['ocr_extraction_tests']
                    
                    st.info(f"🏆 **Best Config:** {ocr_test['best_config']}")
                    
                    # Show OCR results
                    configs_data = []
                    for config, data in ocr_test['configs'].items():
                        if 'quality_score' in data:
                            configs_data.append({
                                'Configuration': config,
                                'Words': data['word_count'],
                                'Characters': data['char_count'],
                                'Score': f"{data['quality_score']:.1f}"
                            })
                    
                    if configs_data:
                        import pandas as pd
                        df = pd.DataFrame(configs_data)
                        st.dataframe(df)
                    
                    # Show best extracted text
                    st.subheader("📝 Best Extracted Text")
                    best_text = ocr_test['best_text']
                    st.text_area("Extracted Text", best_text, height=200)
                
                with tab4:
                    st.subheader("🎯 Pattern Matching Results")
                    patterns = diagnostic['pattern_matching_tests']
                    
                    for field, data in patterns.items():
                        with st.expander(f"{field.title()} - {data['match_count']} matches"):
                            if data['matches']:
                                st.success(f"✅ Found {data['match_count']} matches:")
                                for match in data['matches']:
                                    st.code(match)
                            else:
                                st.error("❌ No matches found")
                
                with tab5:
                    st.subheader("💡 Improvement Recommendations")
                    recommendations = diagnostic['recommendations']
                    
                    if recommendations:
                        for i, rec in enumerate(recommendations, 1):
                            st.write(f"{i}. {rec}")
                    else:
                        st.success("✅ No specific recommendations - extraction should work well!")
        
        # Preprocessing comparison tool
        st.markdown("---")
        st.subheader("🔧 Preprocessing Comparison Tool")
        
        if st.button("🔍 Compare Preprocessing Methods"):
            with st.spinner("Testing different preprocessing methods..."):
                debugger = OCRDebugger()
                
                # Test different preprocessing
                methods = {
                    'Original': image,
                    'Enhanced Contrast': debugger._enhance_contrast(image),
                    'Enhanced Sharpness': debugger._enhance_sharpness(image),
                    'Noise Reduced': debugger._reduce_noise(image),
                    'Adaptive Threshold': debugger._adaptive_threshold(image),
                    'Morphological Clean': debugger._morphological_clean(image)
                }
                
                # Display preprocessing results
                cols = st.columns(3)
                for i, (method_name, processed_img) in enumerate(methods.items()):
                    with cols[i % 3]:
                        st.write(f"**{method_name}**")
                        st.image(processed_img, use_column_width=True)
                        
                        # Quick OCR test
                        try:
                            import pytesseract
                            text = pytesseract.image_to_string(processed_img, config='--psm 6')
                            word_count = len(text.split())
                            st.write(f"Words: {word_count}")
                            
                            if st.button(f"Show Text", key=f"show_{method_name}"):
                                st.text_area(f"{method_name} Text", text, height=100)
                        except:
                            st.write("OCR failed")
        
        # Custom pattern testing
        st.markdown("---")
        st.subheader("🎯 Custom Pattern Testing")
        
        custom_pattern = st.text_input(
            "Test Custom Regex Pattern",
            placeholder="Enter regex pattern (e.g., [A-Z]{5}[0-9]{4}[A-Z] for PAN)",
            help="Test your own regex patterns on the extracted text"
        )
        
        if custom_pattern and st.button("🧪 Test Pattern"):
            try:
                import re
                import pytesseract
                
                # Extract text
                text = pytesseract.image_to_string(image, config='--psm 6')
                
                # Test pattern
                matches = re.findall(custom_pattern, text, re.IGNORECASE)
                
                if matches:
                    st.success(f"✅ Found {len(matches)} matches:")
                    for match in matches:
                        st.code(match)
                else:
                    st.error("❌ No matches found")
                    st.info("**Extracted text preview:**")
                    st.text_area("", text[:500] + "..." if len(text) > 500 else text)
                    
            except Exception as e:
                st.error(f"Pattern test failed: {e}")

if __name__ == "__main__":
    ocr_debugger_page()