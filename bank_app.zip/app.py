
import streamlit as st
from database.models import create_tables
from ui.register_tab import register_tab
from ui.login_tab import login_tab
from ui.account_tab import account_tab

st.set_page_config(page_title="Bank App", layout="centered")
create_tables()

st.title("🏦 Bank Application")

tabs = st.tabs(["Register", "Login & KYC", "Open Account"])

with tabs[0]:
    register_tab()

with tabs[1]:
    login_tab()

with tabs[2]:
    account_tab()
