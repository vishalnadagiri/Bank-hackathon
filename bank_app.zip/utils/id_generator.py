
import uuid, random

def generate_registered_no():
    return f"REG-{uuid.uuid4().hex[:8].upper()}"

def generate_account_no():
    return str(random.randint(10**11, 10**12 - 1))

def generate_ifsc():
    return "BANK0001234"

def generate_csn():
    return str(random.randint(100000, 999999))
