#!/usr/bin/env python3
"""
ML-Based Document Extraction Interface
"""

import streamlit as st
from PIL import Image
import pandas as pd
from services.enhanced_ml_extractor import EnhancedMLExtractor, ML_MODELS_INFO

def ml_extractor_page():
    """ML-based document extraction interface"""
    
    # Page config removed - handled by main app
    
    st.title("🤖 ML-Powered Document Extraction")
    st.markdown("**Specialized extraction for Aadhaar and PAN cards using Machine Learning**")
    
    # Initialize extractor
    if 'ml_extractor' not in st.session_state:
        st.session_state.ml_extractor = EnhancedMLExtractor()
    
    extractor = st.session_state.ml_extractor
    
    # Sidebar for ML model information
    with st.sidebar:
        st.subheader("🧠 Available ML Models")
        
        model_category = st.selectbox(
            "Model Type:",
            ["Open Source", "Cloud Services"],
            key="model_category"
        )
        
        if model_category == "Open Source":
            st.subheader("📦 Open Source Models")
            
            for name, info in ML_MODELS_INFO["open_source"].items():
                with st.expander(f"📘 {name}"):
                    st.write(f"**Description:** {info['description']}")
                    st.code(f"# Installation:\n{info['installation']}")
                    st.code(f"# Usage:\n{info['usage']}")
        
        else:
            st.subheader("☁️ Cloud Services")
            
            for name, info in ML_MODELS_INFO["cloud_services"].items():
                with st.expander(f"🌐 {name}"):
                    st.write(f"**Description:** {info['description']}")
                    st.write(f"**Pricing:** {info['pricing']}")
                    st.write(f"**Features:** {info['features']}")
    
    # Main extraction interface
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.subheader("📁 Document Upload")
        
        uploaded_file = st.file_uploader(
            "Upload Aadhaar or PAN card:",
            type=['jpg', 'jpeg', 'png', 'bmp'],
            help="Upload a clear image of your Aadhaar or PAN card"
        )
        
        if uploaded_file:
            image = Image.open(uploaded_file)
            st.image(image, caption="Uploaded Document", use_column_width=True)
            
            # Document type detection/selection
            doc_type = st.radio(
                "Document Type:",
                ["🔍 Auto-Detect", "📋 Aadhaar Card", "💳 PAN Card"],
                help="Choose document type or let the system auto-detect"
            )
            
            # Extraction button
            if st.button("🚀 Extract with ML", type="primary"):
                with st.spinner("Processing with ML models..."):
                    
                    if doc_type == "📋 Aadhaar Card" or doc_type == "🔍 Auto-Detect":
                        # Save image to temp file first
                        import tempfile
                        import os
                        with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp_file:
                            tmp_file.write(uploaded_file.getbuffer())
                            temp_path = tmp_file.name
                        
                        aadhaar_result = extractor.extract_aadhaar_data(temp_path)
                        os.unlink(temp_path)  # Clean up
                        
                        if aadhaar_result['success']:
                            st.session_state.extraction_result = aadhaar_result
                            st.success("✅ Aadhaar data extracted successfully!")
                            
                        elif doc_type == "🔍 Auto-Detect":
                            # Try PAN extraction
                            # Save image to temp file first
                            with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp_file2:
                                tmp_file2.write(uploaded_file.getbuffer())
                                temp_path2 = tmp_file2.name
                            
                            pan_result = extractor.extract_pan_data(temp_path2)
                            os.unlink(temp_path2)  # Clean up
                            if pan_result['success']:
                                st.session_state.extraction_result = pan_result
                                st.success("✅ PAN data extracted successfully!")
                            else:
                                st.error("❌ Could not extract data from document")
                    
                    elif doc_type == "💳 PAN Card":
                        # Save image to temp file first
                        with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp_file3:
                            tmp_file3.write(uploaded_file.getbuffer())
                            temp_path3 = tmp_file3.name
                        
                        pan_result = extractor.extract_pan_data(temp_path3)
                        os.unlink(temp_path3)  # Clean up
                        
                        if pan_result['success']:
                            st.session_state.extraction_result = pan_result
                            st.success("✅ PAN data extracted successfully!")
                        else:
                            st.error("❌ Could not extract PAN data")
    
    with col2:
        st.subheader("📊 Extraction Results")
        
        if 'extraction_result' in st.session_state:
            result = st.session_state.extraction_result
            
            if result['success']:
                # Document type indicator
                doc_type_emoji = "📋" if result['document_type'] == 'aadhaar' else "💳"
                st.write(f"**Document Type:** {doc_type_emoji} {result['document_type'].upper()}")
                
                # Extracted fields
                st.subheader("📝 Extracted Fields")
                
                extracted_data = result.get('extracted_fields', result.get('extracted_data', {}))
                confidence_scores = result.get('confidence_scores', {})
                
                for field, value in extracted_data.items():
                    confidence = confidence_scores.get(field, 0.0) * 100
                    
                    col_field, col_conf = st.columns([3, 1])
                    
                    with col_field:
                        st.write(f"**{field.replace('_', ' ').title()}:** {value}")
                    
                    with col_conf:
                        if confidence >= 90:
                            st.success(f"{confidence:.0f}%")
                        elif confidence >= 70:
                            st.warning(f"{confidence:.0f}%")
                        else:
                            st.error(f"{confidence:.0f}%")
                
                # Download options
                st.subheader("💾 Export Data")
                
                export_format = st.selectbox(
                    "Export Format:",
                    ["JSON", "CSV", "Excel"],
                    key="export_format"
                )
                
                if export_format == "JSON":
                    import json
                    json_data = json.dumps(extracted_data, indent=2)
                    st.download_button(
                        "📥 Download JSON",
                        json_data,
                        f"extracted_{result['document_type']}_data.json",
                        "application/json"
                    )
                
                elif export_format == "CSV":
                    df = pd.DataFrame([extracted_data])
                    csv_data = df.to_csv(index=False)
                    st.download_button(
                        "📥 Download CSV",
                        csv_data,
                        f"extracted_{result['document_type']}_data.csv",
                        "text/csv"
                    )
                
                elif export_format == "Excel":
                    df = pd.DataFrame([extracted_data])
                    excel_buffer = df.to_excel(index=False)
                    st.download_button(
                        "📥 Download Excel",
                        excel_buffer,
                        f"extracted_{result['document_type']}_data.xlsx",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )
            
            else:
                st.error(f"❌ Extraction failed: {result.get('error', 'Unknown error')}")
                
                # Fallback suggestion
                st.subheader("💡 Suggestions")
                st.info("Try these improvements:")
                st.write("• ✨ Use Simple Training for custom documents")
                st.write("• 🔧 Use OCR Debugger to analyze image quality")
                st.write("• 📸 Take a clearer, well-lit photo")
                st.write("• 🖼️ Ensure document fills the image frame")
        
        else:
            st.info("👆 Upload a document and click 'Extract with ML' to see results")
            
            # Show ML capabilities
            st.subheader("🎯 ML Extraction Features")
            
            features = [
                "✅ **Specialized Aadhaar Processing** - Optimized for Indian Aadhaar cards",
                "✅ **Advanced PAN Recognition** - Validates PAN number format",
                "✅ **Multi-method Approach** - Combines OCR, templates, and ML patterns",
                "✅ **Data Validation** - Validates extracted numbers and formats",
                "✅ **High Accuracy** - Uses document-specific preprocessing",
                "✅ **Confidence Scoring** - Shows reliability of each extracted field"
            ]
            
            for feature in features:
                st.markdown(feature)

def show_ml_model_comparison():
    """Show comparison of different ML models"""
    st.subheader("🔍 ML Model Comparison")
    
    # Create comparison table
    comparison_data = {
        "Model": ["Current (Enhanced OCR)", "PaddleOCR", "EasyOCR", "Google Document AI", "AWS Textract"],
        "Type": ["Rule-based + OCR", "Open Source", "Open Source", "Cloud Service", "Cloud Service"],
        "Accuracy": ["75-85%", "85-90%", "80-85%", "95-98%", "90-95%"],
        "Cost": ["Free", "Free", "Free", "$1.50/1000 pages", "$1.50/1000 pages"],
        "Setup": ["Ready", "pip install", "pip install", "API Setup", "API Setup"],
        "Languages": ["English", "100+ languages", "80+ languages", "200+ languages", "English + others"]
    }
    
    df = pd.DataFrame(comparison_data)
    st.dataframe(df, use_container_width=True)
    
    st.subheader("📋 Recommendations")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.info("""
        **🆓 For Free Usage:**
        - Start with current enhanced OCR
        - Upgrade to PaddleOCR for better accuracy
        - Use EasyOCR for multilingual support
        """)
    
    with col2:
        st.warning("""
        **⚡ For High Accuracy:**
        - Google Document AI (best for Indian docs)
        - AWS Textract (good for forms)
        - Azure Form Recognizer (custom models)
        """)
    
    with col3:
        st.success("""
        **🎯 For Production:**
        - Google Document AI + fallback to PaddleOCR
        - Custom trained models
        - Hybrid approach (multiple models)
        """)

if __name__ == "__main__":
    ml_extractor_page()