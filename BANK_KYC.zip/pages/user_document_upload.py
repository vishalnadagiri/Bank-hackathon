#!/usr/bin/env python3
"""
Production User Interface for Document Upload and Extraction
Clean, simple interface for end users
"""

import streamlit as st
from PIL import Image as PILImage
import time
from services.aadhaar_kyc_service import AadhaarKYCService
import json

def user_document_upload_page():
    """Main user interface for document upload and processing"""
    
    # Initialize Aadhaar KYC service
    if 'aadhaar_kyc_service' not in st.session_state:
        st.session_state.aadhaar_kyc_service = AadhaarKYCService()
    
    if 'user_session_id' not in st.session_state:
        st.session_state.user_session_id = f"user_{int(time.time())}"
    
    if 'upload_attempts' not in st.session_state:
        st.session_state.upload_attempts = 0
    
    kyc_service = st.session_state.aadhaar_kyc_service
    
    # Main UI
    st.title("📄 Document Upload & Verification")
    st.markdown("**Upload your Aadhaar card for AI-powered data extraction and verification**")
    
    # Progress indicator
    show_progress_indicator()
    
    # Always show upload section prominently at top
    st.subheader("📁 Upload Your Document")
    
    # Document type selection
    col_type, col_help = st.columns([2, 1])
    with col_type:
        doc_type = st.selectbox(
            "Document Type:",
            ["📋 Aadhaar Card"],
            help="Currently supported: Aadhaar Card"
        )
    with col_help:
        if 'extraction_result' in st.session_state and not st.session_state.extraction_result.get('success', False):
            attempts_used = st.session_state.get('upload_attempts', 0)
            max_attempts = 5
            st.metric("Attempts Used", f"{attempts_used}/{max_attempts}")
    
    # File upload - always visible and prominent
    uploaded_file = st.file_uploader(
        "Choose document image:",
        type=['jpg', 'jpeg', 'png', 'bmp'],
        help="Upload a clear photo of your document",
        key="main_file_upload"
    )
    
    if uploaded_file:
        col_img, col_submit = st.columns([2, 1])
        
        with col_img:
            image = PILImage.open(uploaded_file)
            st.image(image, caption="Uploaded Document", use_column_width=True)
        
        with col_submit:
            # Quick quality check
            quality_check = check_image_quality(image)
            display_quality_feedback(quality_check)
            
            # Submit button
            if st.button("📤 Submit Aadhaar", type="primary", disabled=not quality_check['acceptable']):
                process_document_extraction(image, doc_type, kyc_service)
    else:
        # Show helpful upload message
        attempts = st.session_state.get('upload_attempts', 0)
        if attempts > 0:
            st.info(f"📸 **Ready for attempt {attempts + 1}/5** - Upload a better quality image above")
        else:
            st.info("👆 **Select and upload your document image above to begin**")
    
    # Show results below upload section (if any)
    if 'extraction_result' in st.session_state:
        st.markdown("---")
        st.subheader("📊 Extraction Results")
        display_extraction_results()
    
    # Footer with help
    st.markdown("---")
    show_help_section()

def show_progress_indicator():
    """Show current step in the process"""
    steps = ["📁 Upload", "🔍 Extract", "✅ Verify", "➡️ Next Steps"]
    
    current_step = 0
    if 'extraction_result' in st.session_state:
        if st.session_state.extraction_result.get('success'):
            current_step = 2
        else:
            current_step = 1
    
    col1, col2, col3, col4 = st.columns(4)
    
    for i, (col, step) in enumerate(zip([col1, col2, col3, col4], steps)):
        with col:
            if i <= current_step:
                st.success(step)
            else:
                st.info(step)

def check_image_quality(image):
    """Quick image quality assessment"""
    width, height = image.size
    
    quality = {
        'acceptable': True,
        'issues': [],
        'suggestions': []
    }
    
    # Check resolution
    if width < 400 or height < 300:
        quality['acceptable'] = False
        quality['issues'].append("Resolution too low")
        quality['suggestions'].append("Take a higher resolution photo")
    
    # Check aspect ratio
    aspect_ratio = width / height
    if aspect_ratio < 0.5 or aspect_ratio > 3.0:
        quality['issues'].append("Unusual document orientation")
        quality['suggestions'].append("Ensure document is properly oriented")
    
    # File size check
    if hasattr(image, 'fp') and hasattr(image.fp, 'name'):
        try:
            import os
            file_size = os.path.getsize(image.fp.name)
            if file_size < 50000:  # Less than 50KB
                quality['issues'].append("File size very small")
                quality['suggestions'].append("Use better camera quality")
        except:
            pass
    
    return quality

def display_quality_feedback(quality_check):
    """Display image quality feedback to user"""
    if quality_check['acceptable']:
        st.success("✅ Image quality looks good!")
    else:
        st.error("⚠️ Image quality issues detected:")
        for issue in quality_check['issues']:
            st.write(f"• {issue}")
        
        st.info("💡 Suggestions:")
        for suggestion in quality_check['suggestions']:
            st.write(f"• {suggestion}")

def process_document_extraction(image, doc_type, kyc_service):
    """Process Aadhaar extraction with user attempt tracking"""
    
    # Increment user attempt counter
    st.session_state.upload_attempts += 1
    current_attempt = st.session_state.upload_attempts
    max_attempts = 5
    
    # Aadhaar-only phase
    backend_doc_type = "aadhaar"
    
    # Create progress container
    progress_container = st.empty()
    
    with progress_container:
        st.info("🔄 Processing your document...")
        
        # Initialize progress tracking
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        # Start processing with real-time updates
        try:
            # This would ideally be done with async processing
            # For now, we'll simulate progress updates
            
            status_text.text("Analyzing document...")
            progress_bar.progress(20)
            time.sleep(1)
            
            status_text.text("Extracting information...")
            progress_bar.progress(50)
            
            # Save image temporarily for extraction
            import tempfile
            import os
            
            with tempfile.NamedTemporaryFile(delete=False, suffix='.png') as tmp_file:
                image.save(tmp_file.name, 'PNG')
                temp_path = tmp_file.name
            
            try:
                customer_id = st.session_state.get('customer_data', {}).get('customer_id')
                if not customer_id:
                    raise ValueError('Not logged in. Please login again.')

                # Aadhaar extraction using TrOCR service
                result = kyc_service.extract_aadhaar(customer_id=customer_id, image_path=temp_path)
            finally:
                # Clean up temporary file
                if os.path.exists(temp_path):
                    os.unlink(temp_path)
            
            # Update result with user attempt info
            result['attempts_used'] = current_attempt
            result['max_attempts'] = max_attempts
            
            # Update progress based on success
            if result.get('success', False):
                progress_value = 90
                status_text.text(f"✅ Extraction successful on attempt {current_attempt}!")
                # Reset attempts on success
                st.session_state.upload_attempts = 0
            else:
                progress_value = 70
                if current_attempt >= max_attempts:
                    status_text.text("❌ All attempts exhausted. Contact admin.")
                else:
                    status_text.text(f"⚠️ Attempt {current_attempt}/{max_attempts} failed. Try again with better image.")
            
            progress_bar.progress(progress_value)
            time.sleep(0.5)
            
            # Final result
            progress_bar.progress(100)
            if result.get('success', False):
                status_text.text("🎉 Processing completed successfully!")
            else:
                status_text.text("❌ Processing failed. Please try again.")
            time.sleep(1)
            
            # Store result
            st.session_state.extraction_result = result
            
            # Clear progress and show result
            progress_container.empty()
            
            # Don't auto-rerun, let the display logic handle it
            # st.rerun()  # REMOVED: This was causing immediate display
            
        except Exception as e:
            progress_container.empty()
            st.error(f"❌ Document processing failed: {str(e)}")

def display_extraction_results():
    """Display extraction results - only called when results exist"""
    result = st.session_state.extraction_result
    
    st.subheader("📊 Extraction Results")
    
    # If we extracted at least one field, show it (even if incomplete)
    extracted = result.get('extracted_fields', {})
    has_any = any(v for v in extracted.values())

    if result.get('success', False) or has_any:
        display_successful_extraction(result)
    else:
        display_failed_extraction(result)

def display_successful_extraction(result):
    """Display successful extraction results"""
    st.success("🎉 Aadhaar number extracted successfully!")
    
    # Show extraction details
    col_details, col_confidence = st.columns([3, 1])
    
    with col_details:
        st.write("**Method Used:** Transformer OCR (TrOCR)")
        st.write("**Engine:** microsoft/trocr-base-printed")
        st.write(f"**Attempts Used:** {result.get('attempts_used', 1)}/{result.get('max_attempts', 5)}")
    
    with col_confidence:
        confidence = result.get('confidence_score', 0)
        if confidence >= 85:
            st.success(f"🎯 {confidence:.1f}% Confidence")
        elif confidence >= 70:
            st.warning(f"⚡ {confidence:.1f}% Confidence")
        else:
            st.error(f"⚠️ {confidence:.1f}% Confidence")
    
    # Display extracted data in a clear format
    st.subheader("📋 Extracted Aadhaar Number")
    
    extracted_data = result.get('extracted_fields', {})

    # Debug info (helpful if extraction is empty)
    with st.expander('🧪 TrOCR Debug Output (raw OCR text)', expanded=False):
        raw_text = result.get('raw_text', '')
        st.text_area('Raw OCR Text', raw_text, height=200)
        debug = result.get('debug')
        if debug:
            st.json(debug)
    
    # Normalize key name for UI
    if 'aadhaar_number' in extracted_data and 'id_number' not in extracted_data:
        extracted_data['id_number'] = extracted_data['aadhaar_number']
    if not extracted_data or not extracted_data.get('id_number'):
        st.warning("No Aadhaar number detected. Please try a clearer image.")
        return
    
    # Create a nice display for the extracted fields
    col1, col2 = st.columns(2)
    
    # Aadhaar-number-only display
    id_val = (extracted_data.get('id_number') or '').strip() if isinstance(extracted_data.get('id_number'), str) else extracted_data.get('id_number')
    st.markdown(f"**🆔 Aadhaar Number:** {id_val if id_val else 'Not detected'}")
    st.caption("(Aadhaar-only phase: extracting Aadhaar number only)")
    
    # Show any additional fields
    additional_fields = {k: v for k, v in extracted_data.items() if k not in ['id_number']}
    
    if additional_fields:
        st.markdown("**Additional Information:**")
        for field, value in additional_fields.items():
            st.markdown(f"**{field.title()}:** {value}")
    
    # Show validation results if available
    validation_result = result.get('validation_result', {})
    if validation_result and validation_result.get('suggestions'):
        st.info("💡 **Suggestions:**")
        for suggestion in validation_result['suggestions']:
            st.write(f"• {suggestion}")
    
    # Create editable form for user verification
    with st.form("verify_extraction"):
        st.markdown("**Please verify the extracted Aadhaar number:**")
        
        verified_data = {}
        
        # Ask user to enter details for verification (pre-filled from extraction)
        field_order = ['id_number']
        labels = {
            'id_number': 'Aadhaar Number (XXXX XXXX XXXX)'
        }
        
        for field in field_order:
            value = extracted_data.get(field, '')
            verified_value = st.text_input(
                labels[field],
                value=value,
                key=f"verify_{field}"
            )
            verified_data[field] = verified_value
        
        # Verification buttons
        col_correct, col_incorrect = st.columns(2)
        
        with col_correct:
            if st.form_submit_button("✅ Verify & Save Aadhaar", type="primary"):
                customer_id = st.session_state.get('customer_data', {}).get('customer_id')
                if not customer_id:
                    st.error('Not logged in. Please login again.')
                else:
                    # Run verification and persist
                    # Note: we don't store original upload path in session, so this is a logical record.
                    # The verification record is stored anyway with entered/extracted fields.
                    verification_out = st.session_state.aadhaar_kyc_service.verify_aadhaar(
                        customer_id=customer_id,
                        image_path="(upload)",
                        extracted_fields=extracted_data,
                        entered_fields=verified_data,
                    )
                    
                    if verification_out.get('success'):
                        st.success("✅ Aadhaar verified and saved successfully!")
                        st.session_state.current_page = 'dashboard'
                        st.rerun()
                    else:
                        st.error("❌ Aadhaar verification failed. Please check entered details.")
                        st.json(verification_out.get('verification', {}))
        
        with col_incorrect:
            if st.form_submit_button("❌ Some Information is Wrong"):
                st.session_state.verified_data = verified_data
                st.session_state.verification_status = "needs_correction"
                show_correction_options()
    
    # Download extracted data
    st.subheader("💾 Download Data")
    
    json_data = json.dumps(extracted_data, indent=2)
    st.download_button(
        "📥 Download as JSON",
        json_data,
        f"extracted_data_{st.session_state.user_session_id}.json",
        "application/json"
    )

def display_failed_extraction(result):
    """Display failed extraction with user retry options"""
    attempts_used = result.get('attempts_used', 1)
    max_attempts = result.get('max_attempts', 5)
    # Use confidence_score from TrOCR pipeline as quality score
    quality_score = float(result.get('confidence_score', 0.0))
    
    if attempts_used >= max_attempts:
        st.error(f"❌ Unable to extract data after {attempts_used}/{max_attempts} attempts")
        st.warning("🔧 **Please contact admin for manual processing**")
        st.info("📞 **Support:** Call 1800-XXX-XXXX or email support@bank.com")
        
        # Reset attempts after max reached
        if st.button("🔄 Start Over", type="primary"):
            st.session_state.upload_attempts = 0
            del st.session_state.extraction_result
            st.rerun()
    else:
        st.error(f"❌ Attempt {attempts_used}/{max_attempts} failed - Quality Score: {quality_score}%")
        st.info(f"💡 **You have {max_attempts - attempts_used} attempts remaining**")
        
        # Show try again button
        st.markdown("### 🔄 What would you like to do?")
        col1, col2, col3 = st.columns([2, 2, 1])
        with col1:
            if st.button("📸 Try Again with Better Image", type="primary", key=f"try_again_{attempts_used}"):
                # Clear previous result to allow new upload
                del st.session_state.extraction_result
                st.success("✅ Ready for new upload! Please upload a better quality image above.")
                st.rerun()
        with col2:
            if st.button("🔄 Reset All Attempts", key=f"reset_{attempts_used}"):
                st.session_state.upload_attempts = 0
                del st.session_state.extraction_result
                st.success("✅ All attempts reset! You can start fresh.")
                st.rerun()
        with col3:
            if st.button("ℹ️ Help", key=f"help_{attempts_used}"):
                st.info("📞 Contact Support: 1800-XXX-XXXX")
    
    # Transformer pipeline info
    st.subheader("🔍 Extraction Details")
    st.info(
        "This page uses Transformer OCR (TrOCR). If extraction fails, please try again with a clearer image. "
        "After 5 user attempts, you will be asked to contact admin for manual verification."
    )
    st.markdown("**Pipeline:** Image → TrOCR → Field Parsing → User Verification")
    
    # Show recommendations
    if 'final_recommendation' in result:
        rec = result['final_recommendation']
        
        st.subheader("💡 Recommendations")
        st.info("**To improve extraction quality:**")
        
        for suggestion in rec['suggestions']:
            st.write(f"• {suggestion}")
        
        st.subheader("🔄 Next Steps")
        
        col_retry, col_contact = st.columns(2)
        
        with col_retry:
            if st.button("📸 Upload Better Photo", type="primary"):
                # Clear previous results and reset
                if 'extraction_result' in st.session_state:
                    del st.session_state['extraction_result']
                st.rerun()
        
        with col_contact:
            if st.button("👨‍💼 Contact Admin"):
                show_admin_contact()
        
        # Show technical info for admin
        with st.expander("🔧 Technical Details (for Admin)"):
            st.write(f"**Methods Tried:** {', '.join(rec['methods_tried'])}")
            st.write(f"**Session ID:** {result['session_id']}")
            st.write(f"**Technical Info:** {rec['technical_info']}")

def show_correction_options():
    """Show options when user indicates data is incorrect"""
    st.subheader("🔧 Correction Options")
    
    col_retry, col_manual = st.columns(2)
    
    with col_retry:
        if st.button("🔄 Try Different Photo", type="primary"):
            if 'extraction_result' in st.session_state:
                del st.session_state['extraction_result']
            st.rerun()
    
    with col_manual:
        if st.button("✏️ Continue with Corrections"):
            st.session_state.verification_status = "manual_correction"
            show_next_steps()

def show_next_steps():
    """Show next steps after successful verification"""
    st.balloons()
    
    st.subheader("🎉 Verification Complete!")
    st.success("Your document has been processed successfully.")
    
    # Next steps based on application flow
    st.subheader("➡️ What's Next?")
    
    next_options = [
        "📋 Complete KYC Application",
        "🏦 Open Bank Account", 
        "💳 Apply for Services",
        "📄 Generate Certificate"
    ]
    
    selected_next = st.selectbox("Choose your next step:", next_options)
    
    if st.button(f"Continue to {selected_next}", type="primary"):
        st.success(f"Redirecting to {selected_next}...")
        # Here you would redirect to the appropriate next page/workflow

def show_admin_contact():
    """Show admin contact information"""
    st.subheader("👨‍💼 Contact Admin Support")
    
    st.info("""
    **For manual document processing assistance:**
    
    📧 **Email:** kyc-support@bank.com  
    📞 **Phone:** +91-1800-XXX-XXXX  
    💬 **Live Chat:** Available 9 AM - 6 PM  
    🎫 **Ticket ID:** Submit your issue with session details  
    """)
    
    # Create support ticket
    with st.form("support_ticket"):
        st.markdown("**Create Support Ticket:**")
        
        issue_type = st.selectbox("Issue Type:", [
            "Document extraction failed",
            "Incorrect data extracted", 
            "Image quality issues",
            "Other technical issue"
        ])
        
        description = st.text_area(
            "Describe your issue:",
            placeholder="Please provide details about the problem you're experiencing..."
        )
        
        if st.form_submit_button("📨 Submit Ticket"):
            # Here you would create an actual support ticket
            ticket_id = f"KYC-{int(time.time())}"
            st.success(f"✅ Support ticket created! Ticket ID: {ticket_id}")
            st.info("You will receive a response within 24 hours.")

def show_upload_instructions():
    """Show instructions when no document is uploaded"""
    st.info("👆 Upload your document to get started")
    
    st.subheader("📋 Upload Guidelines")
    
    guidelines = [
        "✅ **Clear Photo:** Ensure text is readable and sharp",
        "✅ **Good Lighting:** Avoid shadows and glare",
        "✅ **Full Document:** Include entire document in frame", 
        "✅ **Straight Orientation:** Keep document aligned",
        "✅ **High Resolution:** Use good camera quality"
    ]
    
    for guideline in guidelines:
        st.markdown(guideline)
    
    st.subheader("📱 Supported Documents")
    st.write("• 📋 **Aadhaar Card** - Instant extraction of personal details")
    st.write("• (Coming next) 💳 PAN Card - PAN extraction and OTP verification")

def show_help_section():
    """Show help and FAQ section"""
    with st.expander("❓ Frequently Asked Questions"):
        st.markdown("""
        **Q: How accurate is the extraction?**  
        A: We use Transformer OCR (TrOCR). Accuracy depends on image quality.
        
        **Q: What if extraction fails?**  
        A: You get up to 5 upload attempts. Try a clearer image (better lighting, less blur). After 5 attempts, contact admin support.
        
        **Q: Is my data secure?**  
        A: Yes, all data is processed securely and deleted after verification.
        
        **Q: What file formats are supported?**  
        A: JPG, PNG, JPEG, and BMP image formats are supported.
        
        **Q: How long does processing take?**  
        A: Typically 10-30 seconds, depending on document quality.
        """)

if __name__ == "__main__":
    user_document_upload_page()