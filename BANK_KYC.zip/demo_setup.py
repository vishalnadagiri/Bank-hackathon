#!/usr/bin/env python3
"""
Banking KYC Application Demo Setup
Creates sample data and demonstrates key features
"""

import os
import sys
import sqlite3
from datetime import datetime, timedelta
import json
import bcrypt

# Add project root to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from config.database import DatabaseManager
from services.auth_service import AuthService

def create_demo_data():
    """Create sample data for demonstration"""
    print("🚀 Setting up Banking KYC Demo Data")
    print("=" * 40)
    
    # Initialize database
    db = DatabaseManager()
    auth_service = AuthService()
    
    # Create demo customer
    demo_customer = {
        'name': 'John Doe',
        'email': 'john.doe@email.com', 
        'phone': '9876543210',
        'password': 'DemoPass123!'
    }
    
    print(f"👤 Creating demo customer: {demo_customer['name']}")
    result = auth_service.register_customer(
        demo_customer['name'],
        demo_customer['email'],
        demo_customer['phone'],
        demo_customer['password']
    )
    
    if result['success']:
        customer_id = result['customer_id']
        print(f"✅ Demo customer created with ID: {customer_id}")
        
        # Add some demo documents and audit logs
        with db.get_connection() as conn:
            cursor = conn.cursor()
            
            # Insert demo document
            cursor.execute("""
                INSERT INTO documents (customer_id, document_type, file_name, file_path, 
                                     extracted_data, verification_status, confidence_score)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (customer_id, 'id_proof', 'demo_aadhaar.jpg', 'uploads/demo/demo_aadhaar.jpg',
                  json.dumps({'name': 'John Doe', 'id_number': 'ABCD1234EFGH', 'date_of_birth': '15-06-1990'}),
                  'verified', 85.5))
            
            # Update KYC status
            cursor.execute("""
                UPDATE kyc_status 
                SET id_proof_status = 'verified', verification_score = 85.5, 
                    completion_percentage = 33.3, overall_status = 'in_progress'
                WHERE customer_id = ?
            """, (customer_id,))
            
            # Add demo audit logs
            demo_logs = [
                ('CUSTOMER_REGISTERED', 'Demo customer registration'),
                ('LOGIN_SUCCESS', 'Demo login successful'),
                ('DOCUMENT_UPLOADED', 'ID proof document uploaded'),
                ('OTP_VERIFIED', 'OTP verified for document verification'),
                ('KYC_STATUS_UPDATED', 'ID proof verification completed')
            ]
            
            for action, details in demo_logs:
                cursor.execute("""
                    INSERT INTO audit_logs (customer_id, action, details, ip_address)
                    VALUES (?, ?, ?, ?)
                """, (customer_id, action, details, '127.0.0.1'))
            
            conn.commit()
        
        print("✅ Demo data created successfully!")
        
        # Print demo credentials
        print("\n📋 Demo Login Credentials:")
        print(f"   Email: {demo_customer['email']}")
        print(f"   Password: {demo_customer['password']}")
        print(f"   Customer ID: {customer_id}")
        
    else:
        print(f"❌ Failed to create demo customer: {result['message']}")

def print_application_info():
    """Print application information"""
    print("\n🏦 Banking KYC Application - Demo Ready!")
    print("=" * 50)
    
    print("\n📚 Application Features:")
    print("✅ Customer Registration & Authentication")
    print("✅ OTP-based Two-Factor Authentication")
    print("✅ AI-Powered Document OCR Extraction")
    print("✅ Smart Document Verification")
    print("✅ Real-time KYC Status Tracking")
    print("✅ Comprehensive Audit Logging")
    print("✅ Compliance-Ready Reports")
    print("✅ Mobile-Responsive Design")
    
    print("\n🔧 Technical Stack:")
    print("• Frontend: Streamlit")
    print("• Backend: Python")
    print("• Database: SQLite")
    print("• OCR: Tesseract + OpenCV")
    print("• ML: FuzzyWuzzy for verification")
    print("• Security: Bcrypt + OTP")
    print("• Reports: ReportLab PDF generation")
    
    print("\n📋 Supported Documents:")
    print("• ID Proof: Aadhaar, PAN, Passport, DL, Voter ID")
    print("• Address Proof: Utility Bills, Bank Statements")
    print("• Photo ID: Passport-size photographs")
    
    print("\n🚀 Quick Start:")
    print("1. Run: python run_app.py")
    print("2. Open: http://localhost:8501")
    print("3. Login with demo credentials above")
    print("4. Upload documents and test verification")
    
    print("\n💡 Demo Workflow:")
    print("1. 🔐 Login with demo credentials")
    print("2. 📊 View dashboard with partial KYC status")
    print("3. 📤 Upload address proof or photo documents")
    print("4. 🤖 Experience AI data extraction")
    print("5. ✅ Complete verification with OTP")
    print("6. 📋 View reports and audit trails")
    
    print("\n⚠️  Production Notes:")
    print("• Replace Tesseract with cloud OCR (AWS Textract, Google Vision)")
    print("• Integrate real SMS/Email providers for OTP")
    print("• Use PostgreSQL/MySQL for production database")
    print("• Implement proper file storage (S3, GCS)")
    print("• Add comprehensive security measures")
    print("• Set up monitoring and logging")

def main():
    """Main demo setup function"""
    try:
        create_demo_data()
        print_application_info()
        
        print("\n🎉 Demo setup completed successfully!")
        print("👆 Use the credentials above to login and test the application")
        
    except Exception as e:
        print(f"\n❌ Demo setup failed: {e}")
        print("Please check your installation and try again")

if __name__ == "__main__":
    main()